<template>
  <div class="account-management">
    <el-card class="main-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon class="header-icon"><Document /></el-icon>
            <span class="header-title">科目管理</span>
            <el-tag type="info" size="small" class="count-tag">
              共 {{ accounts.length }} 項
            </el-tag>
          </div>
          <el-button type="primary" @click="handleAdd" class="add-button">
            <el-icon><Plus /></el-icon>
            新增科目
          </el-button>
        </div>
      </template>

      <!-- 搜索和筛选 -->
      <el-card class="search-card" shadow="never">
        <el-form :inline="true" :model="searchForm" class="search-form">
          <el-form-item label="科目代碼">
            <el-input
              v-model="searchForm.code"
              placeholder="請輸入科目代碼"
              clearable
              class="search-input"
              @keyup.enter="handleSearch"
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          <el-form-item label="科目名稱">
            <el-input
              v-model="searchForm.name"
              placeholder="請輸入科目名稱"
              clearable
              class="search-input"
              @keyup.enter="handleSearch"
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          <el-form-item label="科目類型">
            <el-select
              v-model="searchForm.type"
              placeholder="請選擇類型"
              clearable
              class="search-select"
            >
              <el-option label="資產" value="ASSET" />
              <el-option label="負債" value="LIABILITY" />
              <el-option label="權益" value="EQUITY" />
              <el-option label="收入" value="INCOME" />
              <el-option label="支出" value="EXPENSE" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch" :icon="Search">
              查詢
            </el-button>
            <el-button @click="handleReset" :icon="Refresh">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 科目列表表格 -->
      <el-table
        v-loading="loading"
        :data="filteredAccounts"
        stripe
        class="data-table"
        style="width: 100%"
        :default-sort="{ prop: 'code', order: 'ascending' }"
        :row-class-name="tableRowClassName"
      >
        <el-table-column prop="code" label="科目代碼" width="120" sortable />
        <el-table-column prop="name" label="科目名稱" min-width="150" />
        <el-table-column prop="type" label="科目類型" width="100">
          <template #default="{ row }">
            <el-tag :type="getTypeTagType(row.type)">
              {{ getTypeLabel(row.type) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="parentCode" label="父科目代碼" width="120" />
        <el-table-column prop="parentName" label="父科目名稱" min-width="150" />
        <el-table-column prop="balanceDirection" label="餘額方向" width="100">
          <template #default="{ row }">
            <el-tag
              :type="row.balanceDirection === 'DEBIT' ? 'success' : 'warning'"
            >
              {{ row.balanceDirection === "DEBIT" ? "借方" : "貸方" }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          prop="auxiliaryManagement"
          label="輔助核算"
          width="120"
        />
        <el-table-column prop="isActive" label="狀態" width="80">
          <template #default="{ row }">
            <el-tag :type="row.isActive ? 'success' : 'danger'">
              {{ row.isActive ? "啟用" : "停用" }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right" align="center">
          <template #default="{ row }">
            <el-button
              type="primary"
              link
              size="small"
              @click="handleEdit(row)"
              :icon="Edit"
            >
              編輯
            </el-button>
            <el-button
              type="danger"
              link
              size="small"
              @click="handleDelete(row)"
              :icon="Delete"
            >
              刪除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/編輯對話框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogTitle"
      width="650px"
      class="form-dialog"
      @close="handleDialogClose"
    >
      <el-form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        label-width="120px"
      >
        <el-form-item label="科目代碼" prop="code">
          <el-input v-model="formData.code" placeholder="請輸入科目代碼" />
        </el-form-item>
        <el-form-item label="科目名稱" prop="name">
          <el-input v-model="formData.name" placeholder="請輸入科目名稱" />
        </el-form-item>
        <el-form-item label="科目類型" prop="type">
          <el-select
            v-model="formData.type"
            placeholder="請選擇科目類型"
            style="width: 100%"
          >
            <el-option label="資產" value="ASSET" />
            <el-option label="負債" value="LIABILITY" />
            <el-option label="權益" value="EQUITY" />
            <el-option label="收入" value="INCOME" />
            <el-option label="支出" value="EXPENSE" />
          </el-select>
        </el-form-item>
        <el-form-item label="父科目">
          <el-select
            v-model="formData.parentId"
            placeholder="請選擇父科目（可選）"
            clearable
            filterable
            style="width: 100%"
          >
            <el-option
              v-for="account in parentAccountOptions"
              :key="account.id"
              :label="`${account.code} - ${account.name}`"
              :value="account.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="餘額方向" prop="balanceDirection">
          <el-radio-group v-model="formData.balanceDirection">
            <el-radio label="DEBIT">借方</el-radio>
            <el-radio label="CREDIT">貸方</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="輔助核算">
          <el-input
            v-model="formData.auxiliaryManagement"
            placeholder="請輸入輔助核算（可選）"
          />
        </el-form-item>
        <el-form-item label="狀態">
          <el-switch
            v-model="formData.isActive"
            active-text="啟用"
            inactive-text="停用"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit" :loading="submitting">
          確定
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from "vue";
import { accountApi } from "../api/index";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Plus,
  Document,
  Search,
  Refresh,
  Edit,
  Delete,
} from "@element-plus/icons-vue";

// 數據
const loading = ref(false);
const accounts = ref([]);
const dialogVisible = ref(false);
const dialogTitle = ref("新增科目");
const submitting = ref(false);
const formRef = ref(null);
const isEdit = ref(false);
const currentEditId = ref(null);

// 搜索表單
const searchForm = reactive({
  code: "",
  name: "",
  type: "",
});

// 表單數據
const formData = reactive({
  code: "",
  name: "",
  type: "",
  parentId: null,
  balanceDirection: "DEBIT",
  auxiliaryManagement: "",
  isActive: true,
});

// 表單驗證規則
const formRules = {
  code: [
    { required: true, message: "請輸入科目代碼", trigger: "blur" },
    {
      pattern: /^[0-9]{4}$/,
      message: "科目代碼必須為4位數字",
      trigger: "blur",
    },
  ],
  name: [{ required: true, message: "請輸入科目名稱", trigger: "blur" }],
  type: [{ required: true, message: "請選擇科目類型", trigger: "change" }],
  balanceDirection: [
    { required: true, message: "請選擇餘額方向", trigger: "change" },
  ],
};

// 計算屬性
const filteredAccounts = computed(() => {
  let result = accounts.value;

  if (searchForm.code) {
    result = result.filter((account) =>
      account.code?.toLowerCase().includes(searchForm.code.toLowerCase())
    );
  }

  if (searchForm.name) {
    result = result.filter((account) =>
      account.name?.toLowerCase().includes(searchForm.name.toLowerCase())
    );
  }

  if (searchForm.type) {
    result = result.filter((account) => account.type === searchForm.type);
  }

  return result;
});

const parentAccountOptions = computed(() => {
  // 編輯時排除當前科目及其子科目
  return accounts.value.filter((account) => {
    if (isEdit.value && account.id === currentEditId.value) {
      return false;
    }
    return account.isActive;
  });
});

// 方法
const loadAccounts = async () => {
  loading.value = true;
  try {
    const data = await accountApi.getAllAccounts();
    accounts.value = Array.isArray(data) ? data : [];
    ElMessage.success(`成功載入 ${accounts.value.length} 條科目記錄`);
  } catch (error) {
    ElMessage.error("載入科目列表失敗：" + (error.message || "未知錯誤"));
  } finally {
    loading.value = false;
  }
};

const handleSearch = () => {
  // 搜索邏輯已在 computed 中實現
};

const handleReset = () => {
  searchForm.code = "";
  searchForm.name = "";
  searchForm.type = "";
};

const handleAdd = () => {
  isEdit.value = false;
  currentEditId.value = null;
  dialogTitle.value = "新增科目";
  resetForm();
  dialogVisible.value = true;
};

const handleEdit = (row) => {
  isEdit.value = true;
  currentEditId.value = row.id;
  dialogTitle.value = "編輯科目";
  Object.assign(formData, {
    code: row.code,
    name: row.name,
    type: row.type,
    parentId: row.parentId,
    balanceDirection: row.balanceDirection,
    auxiliaryManagement: row.auxiliaryManagement || "",
    isActive: row.isActive,
  });
  dialogVisible.value = true;
};

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(
      `確定要刪除科目「${row.code} - ${row.name}」嗎？`,
      "確認刪除",
      {
        confirmButtonText: "確定",
        cancelButtonText: "取消",
        type: "warning",
      }
    );

    await accountApi.deleteAccount(row.id);
    ElMessage.success("刪除成功");
    loadAccounts();
  } catch (error) {
    if (error !== "cancel") {
      ElMessage.error("刪除失敗：" + (error.message || "未知錯誤"));
    }
  }
};

const handleSubmit = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
    submitting.value = true;

    const submitData = {
      code: formData.code,
      name: formData.name,
      type: formData.type,
      parentId: formData.parentId || null,
      balanceDirection: formData.balanceDirection,
      auxiliaryManagement: formData.auxiliaryManagement || null,
      isActive: formData.isActive,
    };

    if (isEdit.value) {
      await accountApi.updateAccount(currentEditId.value, submitData);
      ElMessage.success("更新成功");
    } else {
      await accountApi.createAccount(submitData);
      ElMessage.success("新增成功");
    }

    dialogVisible.value = false;
    loadAccounts();
  } catch (error) {
    if (error !== false) {
      // false 表示驗證失敗，不需要顯示錯誤
      ElMessage.error(
        (isEdit.value ? "更新" : "新增") +
          "失敗：" +
          (error.message || "未知錯誤")
      );
    }
  } finally {
    submitting.value = false;
  }
};

const handleDialogClose = () => {
  resetForm();
  formRef.value?.clearValidate();
};

const resetForm = () => {
  Object.assign(formData, {
    code: "",
    name: "",
    type: "",
    parentId: null,
    balanceDirection: "DEBIT",
    auxiliaryManagement: "",
    isActive: true,
  });
};

const getTypeLabel = (type) => {
  const typeMap = {
    ASSET: "資產",
    LIABILITY: "負債",
    EQUITY: "權益",
    INCOME: "收入",
    EXPENSE: "支出",
  };
  return typeMap[type] || type;
};

const getTypeTagType = (type) => {
  const tagMap = {
    ASSET: "success",
    LIABILITY: "warning",
    EQUITY: "info",
    INCOME: "",
    EXPENSE: "danger",
  };
  return tagMap[type] || "";
};

const tableRowClassName = ({ row, rowIndex }) => {
  if (rowIndex % 2 === 1) {
    return "table-row-light";
  }
  return "";
};

// 生命週期
onMounted(() => {
  loadAccounts();
});
</script>

<style scoped>
.account-management {
  padding: 0;
}

.main-card {
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-icon {
  font-size: 24px;
  color: #667eea;
}

.header-title {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
  letter-spacing: 0.5px;
}

.count-tag {
  margin-left: 8px;
  font-weight: 500;
}

.add-button {
  height: 40px;
  padding: 0 20px;
  font-weight: 500;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
  transition: all 0.3s ease;
}

.add-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.search-card {
  margin-bottom: 20px;
  border-radius: 8px;
  background: #fafbfc;
  border: 1px solid #e4e7ed;
}

.search-form {
  padding: 10px 0;
}

.search-form :deep(.el-form-item) {
  margin-bottom: 16px;
}

.search-input {
  width: 220px;
}

.search-select {
  width: 160px;
}

.data-table {
  border-radius: 8px;
  overflow: hidden;
}

.data-table :deep(.el-table__header) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.data-table :deep(.el-table__header th) {
  background: transparent !important;
  color: #fff !important;
  font-weight: 600;
  border-bottom: none !important;
}

.data-table :deep(.el-table__header th .cell) {
  color: #fff !important;
}

.data-table :deep(.el-table__body tr) {
  transition: all 0.2s ease;
}

.data-table :deep(.el-table__body tr:hover) {
  background: #f0f4ff !important;
  transform: scale(1.01);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.data-table :deep(.table-row-light) {
  background: #fafbfc;
}

.data-table :deep(.el-table__body td) {
  border-bottom: 1px solid #f0f0f0;
  padding: 16px 0;
}

.data-table :deep(.el-loading-mask) {
  border-radius: 8px;
}

.form-dialog :deep(.el-dialog__header) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 20px 24px;
  margin: 0;
  border-radius: 4px 4px 0 0;
}

.form-dialog :deep(.el-dialog__title) {
  color: #fff;
  font-weight: 600;
  font-size: 18px;
}

.form-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: #fff;
  font-size: 20px;
}

.form-dialog :deep(.el-dialog__body) {
  padding: 30px 24px;
}

.form-dialog :deep(.el-form-item__label) {
  font-weight: 500;
  color: #606266;
}

.form-dialog :deep(.el-input__wrapper) {
  border-radius: 6px;
  box-shadow: 0 0 0 1px #dcdfe6 inset;
  transition: all 0.3s ease;
}

.form-dialog :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #c0c4cc inset;
}

.form-dialog :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 1px #667eea inset;
}

.form-dialog :deep(.el-select .el-input__wrapper) {
  box-shadow: 0 0 0 1px #dcdfe6 inset;
}

.form-dialog :deep(.el-radio-group) {
  display: flex;
  gap: 20px;
}

.form-dialog :deep(.el-radio) {
  margin-right: 0;
}

.form-dialog :deep(.el-dialog__footer) {
  padding: 20px 24px;
  border-top: 1px solid #e4e7ed;
}

.form-dialog :deep(.el-button) {
  padding: 10px 24px;
  border-radius: 6px;
  font-weight: 500;
}

.form-dialog :deep(.el-button--primary) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
}

.form-dialog :deep(.el-button--primary:hover) {
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
  transform: translateY(-1px);
}

/* 響應式設計 */
@media (max-width: 768px) {
  .search-form {
    flex-direction: column;
  }

  .search-input,
  .search-select {
    width: 100%;
  }
}
</style>
