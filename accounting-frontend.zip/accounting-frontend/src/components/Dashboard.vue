<template>
  <div class="dashboard" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><DataAnalysis /></el-icon>
        系统概览
      </h1>
      <p class="page-subtitle">会计管理系统总览和关键指标</p>
    </div>

    <!-- 统计卡片 -->
    <el-row :gutter="20" style="margin-bottom: 20px">
      <el-col :xs="24" :sm="12" :md="6" :lg="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon" style="background: #409eff">
              <el-icon><Document /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-label">科目总数</div>
              <div class="stat-value">{{ stats.accountsCount || 0 }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6" :lg="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon" style="background: #67c23a">
              <el-icon><User /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-label">供应商数</div>
              <div class="stat-value">{{ stats.vendorsCount || 0 }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6" :lg="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon" style="background: #e6a23c">
              <el-icon><UserFilled /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-label">客户数</div>
              <div class="stat-value">{{ stats.customersCount || 0 }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6" :lg="6">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon" style="background: #f56c6c">
              <el-icon><Edit /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-label">凭证总数</div>
              <div class="stat-value">{{ stats.transactionsCount || 0 }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 订单统计 -->
    <el-row :gutter="20" style="margin-bottom: 20px">
      <el-col :xs="24" :sm="12" :md="12" :lg="12">
        <el-card class="info-card" shadow="hover">
          <template #header>
            <div style="display: flex; justify-content: space-between; align-items: center">
              <span style="font-size: 16px; font-weight: 600">销售订单</span>
              <el-tag type="success">{{ stats.salesOrdersCount || 0 }} 笔</el-tag>
            </div>
          </template>
          <div class="info-content">
            <div class="info-item">
              <span class="info-label">待发货订单：</span>
              <span class="info-value">{{ stats.pendingSalesOrders || 0 }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">已开票订单：</span>
              <span class="info-value success">{{ stats.invoicedSalesOrders || 0 }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="12" :lg="12">
        <el-card class="info-card" shadow="hover">
          <template #header>
            <div style="display: flex; justify-content: space-between; align-items: center">
              <span style="font-size: 16px; font-weight: 600">采购订单</span>
              <el-tag type="info">{{ stats.purchaseOrdersCount || 0 }} 笔</el-tag>
            </div>
          </template>
          <div class="info-content">
            <div class="info-item">
              <span class="info-label">待收货订单：</span>
              <span class="info-value">{{ stats.pendingPurchaseOrders || 0 }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">已入库订单：</span>
              <span class="info-value success">{{ stats.receivedPurchaseOrders || 0 }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 付款和凭证状态 -->
    <el-row :gutter="20" style="margin-bottom: 20px">
      <el-col :xs="24" :sm="12" :md="12" :lg="12">
        <el-card class="info-card" shadow="hover">
          <template #header>
            <div style="display: flex; justify-content: space-between; align-items: center">
              <span style="font-size: 16px; font-weight: 600">付款申请</span>
              <el-tag type="warning">{{ stats.pendingPayments || 0 }} 待处理</el-tag>
            </div>
          </template>
          <div class="info-content">
            <div class="info-item">
              <span class="info-label">待执行：</span>
              <span class="info-value warning">{{ stats.pendingPayments || 0 }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">已支付：</span>
              <span class="info-value success">{{ stats.paidPayments || 0 }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="12" :lg="12">
        <el-card class="info-card" shadow="hover">
          <template #header>
            <div style="display: flex; justify-content: space-between; align-items: center">
              <span style="font-size: 16px; font-weight: 600">凭证状态</span>
            </div>
          </template>
          <div class="info-content">
            <div class="info-item">
              <span class="info-label">草稿：</span>
              <span class="info-value">{{ stats.draftTransactions || 0 }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">已审核：</span>
              <span class="info-value warning">{{ stats.auditedTransactions || 0 }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">已过账：</span>
              <span class="info-value success">{{ stats.postedTransactions || 0 }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 快速操作 -->
    <el-card class="action-card" shadow="hover">
      <template #header>
        <span style="font-size: 16px; font-weight: 600">快速操作</span>
      </template>
      <el-row :gutter="15">
        <el-col :xs="24" :sm="12" :md="8" :lg="6">
          <el-button type="primary" @click="navigateTo('transactions')" style="width: 100%">
            <el-icon><Edit /></el-icon>
            新增凭证
          </el-button>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="6">
          <el-button type="success" @click="navigateTo('sales-orders')" style="width: 100%">
            <el-icon><ShoppingBag /></el-icon>
            新增销售订单
          </el-button>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="6">
          <el-button type="warning" @click="navigateTo('purchase-orders')" style="width: 100%">
            <el-icon><ShoppingCart /></el-icon>
            新增采购订单
          </el-button>
        </el-col>
        <el-col :xs="24" :sm="12" :md="8" :lg="6">
          <el-button type="info" @click="navigateTo('reports')" style="width: 100%">
            <el-icon><DataAnalysis /></el-icon>
            生成财务报表
          </el-button>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, inject } from "vue";
import { ElMessage } from "element-plus";
import {
  Document,
  User,
  UserFilled,
  Edit,
  ShoppingBag,
  ShoppingCart,
  DataAnalysis,
} from "@element-plus/icons-vue";
import {
  accountApi,
  vendorApi,
  customerApi,
  salesOrderApi,
  purchaseOrderApi,
  paymentApi,
} from "../api/index.js";

// 统计数据
const stats = reactive({
  accountsCount: 0,
  vendorsCount: 0,
  customersCount: 0,
  transactionsCount: 0,
  salesOrdersCount: 0,
  purchaseOrdersCount: 0,
  pendingSalesOrders: 0,
  invoicedSalesOrders: 0,
  pendingPurchaseOrders: 0,
  receivedPurchaseOrders: 0,
  pendingPayments: 0,
  paidPayments: 0,
  draftTransactions: 0,
  auditedTransactions: 0,
  postedTransactions: 0,
});

const loading = ref(false);

// 获取统计数据
const fetchStats = async () => {
  loading.value = true;
  try {
    // 获取科目数量
    try {
      const accounts = await accountApi.getAllAccounts();
      stats.accountsCount = Array.isArray(accounts) ? accounts.length : 0;
    } catch (error) {
      console.error("获取科目统计失败:", error);
    }

    // 获取供应商数量
    try {
      const vendors = await vendorApi.getAllVendors();
      stats.vendorsCount = Array.isArray(vendors) ? vendors.length : 0;
    } catch (error) {
      console.error("获取供应商统计失败:", error);
    }

    // 获取客户数量
    try {
      const customers = await customerApi.getAllCustomers();
      stats.customersCount = Array.isArray(customers) ? customers.length : 0;
    } catch (error) {
      console.error("获取客户统计失败:", error);
    }

    // 获取销售订单统计
    try {
      const salesOrders = await salesOrderApi.getAllSalesOrders();
      if (Array.isArray(salesOrders)) {
        stats.salesOrdersCount = salesOrders.length;
        stats.pendingSalesOrders = salesOrders.filter(
          (o) => o.status === "DRAFT" || o.status === "CONFIRMED"
        ).length;
        stats.invoicedSalesOrders = salesOrders.filter(
          (o) => o.status === "INVOICED"
        ).length;
      }
    } catch (error) {
      console.error("获取销售订单统计失败:", error);
    }

    // 获取采购订单统计
    try {
      const purchaseOrders = await purchaseOrderApi.getAllPurchaseOrders();
      if (Array.isArray(purchaseOrders)) {
        stats.purchaseOrdersCount = purchaseOrders.length;
        stats.pendingPurchaseOrders = purchaseOrders.filter(
          (o) => o.status === "DRAFT" || o.status === "CONFIRMED"
        ).length;
        stats.receivedPurchaseOrders = purchaseOrders.filter(
          (o) => o.status === "RECEIVED"
        ).length;
      }
    } catch (error) {
      console.error("获取采购订单统计失败:", error);
    }

    // 获取付款申请统计
    try {
      const pendingPayments = await paymentApi.getPaymentsByStatus("PENDING");
      const paidPayments = await paymentApi.getPaymentsByStatus("PAID");
      stats.pendingPayments = Array.isArray(pendingPayments) ? pendingPayments.length : 0;
      stats.paidPayments = Array.isArray(paidPayments) ? paidPayments.length : 0;
    } catch (error) {
      console.error("获取付款申请统计失败:", error);
    }
  } catch (error) {
    console.error("获取统计数据失败:", error);
  } finally {
    loading.value = false;
  }
};

// 导航到指定页面
const navigateTo = (tab) => {
  // 通过事件总线或直接修改父组件的activeTab
  // 由于是setup语法，我们需要通过emit或者全局事件
  const event = new CustomEvent("navigate-tab", { detail: { tab } });
  window.dispatchEvent(event);
};

// 获取标签名称
const getTabName = (tab) => {
  const tabMap = {
    transactions: "凭证管理",
    "sales-orders": "销售订单",
    "purchase-orders": "采购订单",
    reports: "财务报表",
  };
  return tabMap[tab] || tab;
};

// 组件挂载时获取数据
onMounted(() => {
  console.log("Dashboard 组件已挂载");
  fetchStats();
});
</script>

<style scoped>
.dashboard {
  width: 100%;
}

.page-header {
  margin-bottom: 24px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 32px;
}

.page-subtitle {
  margin: 8px 0 0 44px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.stat-card {
  border-radius: 12px;
  transition: transform 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-5px);
}

.stat-content {
  display: flex;
  align-items: center;
  gap: 15px;
}

.stat-icon {
  width: 60px;
  height: 60px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 28px;
  flex-shrink: 0;
}

.stat-info {
  flex: 1;
}

.stat-label {
  font-size: 14px;
  color: #909399;
  margin-bottom: 8px;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #303133;
}

.info-card {
  border-radius: 12px;
  height: 100%;
}

.info-content {
  padding: 10px 0;
}

.info-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
}

.info-item:last-child {
  border-bottom: none;
}

.info-label {
  font-size: 14px;
  color: #606266;
}

.info-value {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}

.info-value.success {
  color: #67c23a;
}

.info-value.warning {
  color: #e6a23c;
}

.action-card {
  border-radius: 12px;
}
</style>

