<template>
  <div class="user-management" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><User /></el-icon>
        使用者管理
      </h1>
      <p class="page-subtitle">新增、修改、管理系統使用者和其角色</p>
    </div>

    <el-card class="main-card" shadow="hover">
      <template #header>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:18px;font-weight:600">使用者列表</span>
          <el-button type="primary" @click="handleCreate">
            <el-icon><Plus /></el-icon>
            新增使用者
          </el-button>
        </div>
      </template>

      <el-table v-loading="loading" :data="users" stripe style="width: 100%">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="username" label="使用者名稱" min-width="150" />
        <el-table-column label="角色" min-width="200">
          <template #default="{ row }">
            <el-tag
              v-for="role in row.roles"
              :key="role.id"
              type="info"
              size="small"
              style="margin-right: 6px"
            >
              {{ role.name }}
            </el-tag>
            <span v-if="!row.roles || row.roles.length === 0" style="color: #909399">無角色</span>
          </template>
        </el-table-column>
        <el-table-column prop="enabled" label="狀態" width="100">
          <template #default="{ row }">
            <el-tag :type="row.enabled ? 'success' : 'danger'">
              {{ row.enabled ? '啟用' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="handleEdit(row)">編輯</el-button>
            <el-button type="danger" link size="small" @click="handleDelete(row)">刪除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/編輯使用者對話框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? '編輯使用者' : '新增使用者'"
      width="500px"
      @close="resetForm"
    >
      <el-form
        ref="userFormRef"
        :model="userForm"
        :rules="userFormRules"
        label-width="100px"
      >
        <el-form-item label="使用者名稱" prop="username">
          <el-input v-model="userForm.username" placeholder="請輸入使用者名稱" />
        </el-form-item>
        <el-form-item label="密碼" :prop="isEdit ? '' : 'password'">
          <el-input
            v-model="userForm.password"
            type="password"
            :placeholder="isEdit ? '留空則不修改密碼' : '請輸入密碼'"
            show-password
          />
        </el-form-item>
        <el-form-item label="狀態" prop="enabled">
          <el-switch v-model="userForm.enabled" />
        </el-form-item>
        <el-form-item label="角色" prop="roleIds">
          <el-select
            v-model="userForm.roleIds"
            multiple
            placeholder="請選擇角色"
            style="width: 100%"
          >
            <el-option
              v-for="role in availableRoles"
              :key="role.id"
              :label="role.name"
              :value="role.id"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">
          {{ isEdit ? '更新' : '創建' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { User, Plus } from '@element-plus/icons-vue';
import { userApi } from '../api';

const users = ref([]);
const availableRoles = ref([]);
const loading = ref(false);
const dialogVisible = ref(false);
const isEdit = ref(false);
const submitting = ref(false);
const userFormRef = ref(null);
const currentUserId = ref(null);

const userForm = ref({
  username: '',
  password: '',
  enabled: true,
  roleIds: []
});

const userFormRules = {
  username: [
    { required: true, message: '請輸入使用者名稱', trigger: 'blur' },
    { min: 3, max: 50, message: '使用者名稱長度應在 3 到 50 個字符之間', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '請輸入密碼', trigger: 'blur' },
    { min: 6, message: '密碼長度至少 6 個字符', trigger: 'blur' }
  ]
};

const fetchUsers = async () => {
  loading.value = true;
  try {
    const response = await userApi.getAllUsers();
    users.value = response;
  } catch (error) {
    ElMessage.error('載入使用者列表失敗：' + error.message);
  } finally {
    loading.value = false;
  }
};

const fetchRoles = async () => {
  try {
    const response = await userApi.getAllRoles();
    availableRoles.value = response;
  } catch (error) {
    ElMessage.error('載入角色列表失敗：' + error.message);
  }
};

const handleCreate = () => {
  isEdit.value = false;
  currentUserId.value = null;
  resetForm();
  dialogVisible.value = true;
};

const handleEdit = async (row) => {
  isEdit.value = true;
  currentUserId.value = row.id;
  try {
    const user = await userApi.getUserById(row.id);
    userForm.value = {
      username: user.username,
      password: '', // 編輯時不顯示密碼
      enabled: user.enabled,
      roleIds: user.roles ? user.roles.map(r => r.id) : []
    };
    dialogVisible.value = true;
  } catch (error) {
    ElMessage.error('載入使用者資訊失敗：' + error.message);
  }
};

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(
      `確定要刪除使用者「${row.username}」嗎？此操作無法撤銷。`,
      '確認刪除',
      {
        confirmButtonText: '確定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    );
    
    await userApi.deleteUser(row.id);
    ElMessage.success('使用者刪除成功');
    fetchUsers();
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('刪除使用者失敗：' + error.message);
    }
  }
};

const submitForm = async () => {
  if (!userFormRef.value) return;
  
  await userFormRef.value.validate(async (valid) => {
    if (!valid) return;
    
    submitting.value = true;
    try {
      if (isEdit.value) {
        // 更新使用者
        const updateData = {
          username: userForm.value.username,
          enabled: userForm.value.enabled,
          roleIds: userForm.value.roleIds || []
        };
        // 只有當密碼不為空時才更新密碼
        if (userForm.value.password && userForm.value.password.trim() !== '') {
          updateData.password = userForm.value.password;
        }
        await userApi.updateUser(currentUserId.value, updateData);
        ElMessage.success('使用者更新成功');
      } else {
        // 創建使用者
        await userApi.createUser({
          username: userForm.value.username,
          password: userForm.value.password,
          enabled: userForm.value.enabled,
          roleIds: userForm.value.roleIds || []
        });
        ElMessage.success('使用者創建成功');
      }
      dialogVisible.value = false;
      fetchUsers();
    } catch (error) {
      ElMessage.error((isEdit.value ? '更新' : '創建') + '使用者失敗：' + error.message);
    } finally {
      submitting.value = false;
    }
  });
};

const resetForm = () => {
  userForm.value = {
    username: '',
    password: '',
    enabled: true,
    roleIds: []
  };
  if (userFormRef.value) {
    userFormRef.value.clearValidate();
  }
};

onMounted(() => {
  fetchUsers();
  fetchRoles();
});

</script>

<style scoped>
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
}
.main-card {
  border-radius: 12px;
}
</style>

