<template>
  <div class="purchase-order-management" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><ShoppingCart /></el-icon>
        采购订单管理
      </h1>
      <p class="page-subtitle">管理采购订单，处理收货入库流程</p>
    </div>

    <el-card class="main-card" shadow="hover">
      <template #header>
        <div
          style="
            display: flex;
            justify-content: space-between;
            align-items: center;
          "
        >
          <span style="font-size: 18px; font-weight: 600">采购订单列表</span>
          <el-button type="primary" @click="handleAdd">
            <el-icon><Plus /></el-icon>
            新增订单
          </el-button>
        </div>
      </template>

      <!-- 搜索区域 -->
      <el-card class="search-card" shadow="never" style="margin-bottom: 20px">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="供应商名称">
            <el-input
              v-model="searchForm.vendorName"
              placeholder="请输入供应商名称"
              clearable
              style="width: 200px"
            />
          </el-form-item>
          <el-form-item label="状态">
            <el-select
              v-model="searchForm.status"
              placeholder="请选择状态"
              clearable
              style="width: 150px"
            >
              <el-option label="草稿" value="DRAFT" />
              <el-option label="已确认" value="CONFIRMED" />
              <el-option label="已入库" value="RECEIVED" />
              <el-option label="已取消" value="CANCELLED" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">查询</el-button>
            <el-button @click="handleReset">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 订单列表 -->
      <el-empty
        v-if="!loading && filteredPurchaseOrders.length === 0"
        description="暂无采购订单数据"
        :image-size="120"
      >
        <el-button type="primary" @click="handleAdd">新增订单</el-button>
        <el-button
          type="success"
          @click="createTestOrder"
          style="margin-left: 10px"
          >创建测试订单</el-button
        >
      </el-empty>

      <el-table
        v-else
        v-loading="loading"
        :data="filteredPurchaseOrders"
        stripe
        style="width: 100%"
      >
        <el-table-column prop="id" label="订单ID" width="100" />
        <el-table-column prop="vendorName" label="供应商名称" min-width="180" />
        <el-table-column prop="orderDate" label="订单日期" width="120">
          <template #default="{ row }">
            {{ formatDate(row.orderDate) }}
          </template>
        </el-table-column>
        <el-table-column prop="receiptDate" label="收货日期" width="120">
          <template #default="{ row }">
            {{ formatDate(row.receiptDate) || "-" }}
          </template>
        </el-table-column>
        <el-table-column
          prop="totalAmount"
          label="订单金额"
          width="140"
          align="right"
        >
          <template #default="{ row }">
            {{ formatAmount(row.totalAmount) }}
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="autoTransactionId" label="关联凭证" width="120">
          <template #default="{ row }">
            <el-tag v-if="row.autoTransactionId" type="success" size="small">
              #{{ row.autoTransactionId }}
            </el-tag>
            <span v-else class="text-muted">-</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220">
          <template #default="{ row }">
            <el-button type="info" size="small" @click="handleView(row)"
              >查看</el-button
            >
            <el-button
              v-if="canReceive(row)"
              type="success"
              size="small"
              @click="handleReceive(row)"
              style="margin-left: 8px"
            >
              收货入库
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增订单对话框 -->
    <el-dialog v-model="dialogVisible" title="新增采购订单" width="600px">
      <el-form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        label-width="120px"
      >
        <el-form-item label="供应商" prop="vendorId">
          <el-select
            v-model="formData.vendorId"
            placeholder="请选择供应商"
            filterable
            style="width: 100%"
          >
            <el-option
              v-for="vendor in vendors"
              :key="vendor.id"
              :label="`${vendor.vendorName} (${
                vendor.taxId || '无税号'
              })`"
              :value="vendor.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="订单日期" prop="orderDate">
          <el-date-picker
            v-model="formData.orderDate"
            type="date"
            placeholder="请选择订单日期"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="订单金额" prop="totalAmount">
          <el-input-number
            v-model="formData.totalAmount"
            :min="0"
            :precision="2"
            :step="100"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit" :loading="submitting"
          >确定</el-button
        >
      </template>
    </el-dialog>

    <!-- 查看详情对话框 -->
    <el-dialog v-model="viewDialogVisible" title="订单详情" width="700px">
      <el-descriptions :column="2" border v-if="viewingOrder">
        <el-descriptions-item label="订单ID">{{
          viewingOrder.id
        }}</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="getStatusType(viewingOrder.status)">
            {{ getStatusText(viewingOrder.status) }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="供应商名称">{{
          viewingOrder.vendorName
        }}</el-descriptions-item>
        <el-descriptions-item label="供应商ID">{{
          viewingOrder.vendorId
        }}</el-descriptions-item>
        <el-descriptions-item label="订单日期">{{
          formatDate(viewingOrder.orderDate)
        }}</el-descriptions-item>
        <el-descriptions-item label="收货日期">{{
          formatDate(viewingOrder.receiptDate) || "-"
        }}</el-descriptions-item>
        <el-descriptions-item label="订单金额">{{
          formatAmount(viewingOrder.totalAmount)
        }}</el-descriptions-item>
        <el-descriptions-item label="关联凭证">
          <el-tag v-if="viewingOrder.autoTransactionId" type="success">
            凭证 #{{ viewingOrder.autoTransactionId }}
          </el-tag>
          <span v-else class="text-muted">尚未生成凭证</span>
        </el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <el-button @click="viewDialogVisible = false">关闭</el-button>
      </template>
    </el-dialog>

    <!-- 收货对话框 -->
    <el-dialog v-model="receiveDialogVisible" title="收货入库" width="500px">
      <el-alert
        type="info"
        :closable="false"
        style="margin-bottom: 20px"
      >
        收货后将自动生成应付账款凭证
      </el-alert>
      <el-form
        ref="receiveFormRef"
        :model="receiveForm"
        :rules="receiveFormRules"
        label-width="120px"
      >
        <el-form-item label="实际金额" prop="actualAmount">
          <el-input-number
            v-model="receiveForm.actualAmount"
            :min="0"
            :precision="2"
            :step="100"
            style="width: 100%"
          />
          <div style="margin-top: 5px; color: #909399; font-size: 12px">
            订单金额：{{ formatAmount(currentReceiveOrder?.totalAmount) }}
          </div>
        </el-form-item>
        <el-form-item label="收货日期" prop="receiptDate">
          <el-date-picker
            v-model="receiveForm.receiptDate"
            type="date"
            placeholder="请选择收货日期"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="receiveDialogVisible = false">取消</el-button>
        <el-button type="success" @click="confirmReceive" :loading="receiving"
          >确认收货</el-button
        >
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { Plus, ShoppingCart } from "@element-plus/icons-vue";
import { purchaseOrderApi, vendorApi } from "../api/index.js";

// 数据
const purchaseOrders = ref([]);
const vendors = ref([]);
const loading = ref(false);
const dialogVisible = ref(false);
const viewDialogVisible = ref(false);
const receiveDialogVisible = ref(false);
const submitting = ref(false);
const receiving = ref(false);
const formRef = ref(null);
const receiveFormRef = ref(null);
const viewingOrder = ref(null);
const currentReceiveOrder = ref(null);

// 搜索表单
const searchForm = reactive({
  vendorName: "",
  status: "",
});

// 表单数据
const formData = reactive({
  vendorId: null,
  orderDate: "",
  totalAmount: 0,
});

// 收货表单
const receiveForm = reactive({
  actualAmount: 0,
  receiptDate: "",
});

// 表单验证规则
const formRules = {
  vendorId: [{ required: true, message: "请选择供应商", trigger: "change" }],
  orderDate: [
    { required: true, message: "请选择订单日期", trigger: "change" },
  ],
  totalAmount: [
    { required: true, message: "请输入订单金额", trigger: "blur" },
    {
      type: "number",
      min: 0.01,
      message: "订单金额必须大于 0",
      trigger: "blur",
    },
  ],
};

// 收货表单验证规则
const receiveFormRules = {
  actualAmount: [
    { required: true, message: "请输入实际金额", trigger: "blur" },
    {
      type: "number",
      min: 0.01,
      message: "实际金额必须大于 0",
      trigger: "blur",
    },
  ],
  receiptDate: [
    { required: true, message: "请选择收货日期", trigger: "change" },
  ],
};

// 过滤后的订单列表
const filteredPurchaseOrders = computed(() => {
  try {
    if (!Array.isArray(purchaseOrders.value)) return [];
    let result = purchaseOrders.value;
    if (searchForm.vendorName) {
      result = result.filter((o) =>
        o?.vendorName
          ?.toLowerCase()
          .includes(searchForm.vendorName.toLowerCase())
      );
    }
    if (searchForm.status) {
      result = result.filter((o) => o?.status === searchForm.status);
    }
    return result;
  } catch (error) {
    console.error("filteredPurchaseOrders 計算錯誤:", error);
    return [];
  }
});

// 格式化金額
const formatAmount = (amount) => {
  if (amount == null) return "0.00";
  return Number(amount).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

// 格式化日期
const formatDate = (date) => {
  if (!date) return "-";
  if (typeof date === "string") return date;
  return new Date(date).toLocaleDateString("zh-CN");
};

// 獲取狀態類型
const getStatusType = (status) => {
  const statusMap = {
    DRAFT: "info",
    CONFIRMED: "",
    RECEIVED: "success",
    CANCELLED: "danger",
  };
  return statusMap[status] || "";
};

// 獲取狀態文本
const getStatusText = (status) => {
  const statusMap = {
    DRAFT: "草稿",
    CONFIRMED: "已确认",
    RECEIVED: "已入库",
    CANCELLED: "已取消",
  };
  return statusMap[status] || status;
};

// 判斷是否可以收貨
const canReceive = (order) => {
  return order.status === "DRAFT" || order.status === "CONFIRMED";
};

// 獲取訂單列表
const fetchPurchaseOrders = async () => {
  loading.value = true;
  try {
    const data = await purchaseOrderApi.getAllPurchaseOrders();
    purchaseOrders.value = Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("獲取訂單列表失敗:", error);
    ElMessage.error(
      error.message || "獲取訂單列表失敗，請檢查後端服務是否啟動"
    );
    purchaseOrders.value = [];
  } finally {
    loading.value = false;
  }
};

// 獲取供應商列表
const fetchVendors = async () => {
  try {
    const data = await vendorApi.getAllVendors();
    vendors.value = Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("獲取供應商列表失敗:", error);
    vendors.value = [];
  }
};

// 創建測試訂單
const createTestOrder = async () => {
  try {
    const vendorList = await vendorApi.getAllVendors();

    if (!vendorList || vendorList.length === 0) {
      ElMessage.info("沒有供應商數據，正在創建測試供應商...");
      const testVendor = await vendorApi.createVendor({
        vendorName: "測試供應商",
        taxId: "TEST001",
        settlementCurrency: "CNY",
        status: "有效",
      });
      ElMessage.success("測試供應商創建成功");

      const testOrder = await purchaseOrderApi.createPurchaseOrder({
        vendorId: testVendor.id,
        orderDate: new Date().toISOString().split("T")[0],
        totalAmount: 8000.0,
      });
      ElMessage.success("測試訂單創建成功！");
      await fetchPurchaseOrders();
      return;
    }

    const firstVendor = vendorList[0];
    const testOrder = await purchaseOrderApi.createPurchaseOrder({
      vendorId: firstVendor.id,
      orderDate: new Date().toISOString().split("T")[0],
      totalAmount: 8000.0,
    });

    ElMessage.success("測試訂單創建成功！");
    await fetchPurchaseOrders();
  } catch (error) {
    console.error("創建測試訂單失敗:", error);
    ElMessage.error(error.message || "創建測試訂單失敗");
  }
};

// 搜索
const handleSearch = () => {
  // 搜索邏輯已在 computed 中實現
};

// 重置搜索
const handleReset = () => {
  searchForm.vendorName = "";
  searchForm.status = "";
};

// 新增
const handleAdd = () => {
  resetForm();
  dialogVisible.value = true;
};

// 查看詳情
const handleView = async (row) => {
  try {
    const data = await purchaseOrderApi.getPurchaseOrderById(row.id);
    viewingOrder.value = data;
    viewDialogVisible.value = true;
  } catch (error) {
    console.error("獲取訂單詳情失敗:", error);
    ElMessage.error(error.message || "獲取訂單詳情失敗");
  }
};

// 收貨
const handleReceive = (row) => {
  currentReceiveOrder.value = row;
  receiveForm.actualAmount = Number(row.totalAmount) || 0;
  receiveForm.receiptDate = new Date().toISOString().split("T")[0];
  receiveDialogVisible.value = true;
};

// 確認收貨
const confirmReceive = async () => {
  if (!receiveFormRef.value || !currentReceiveOrder.value) return;

  try {
    await receiveFormRef.value.validate();
    receiving.value = true;

    await purchaseOrderApi.receiveOrder(currentReceiveOrder.value.id, {
      actualAmount: receiveForm.actualAmount,
      receiptDate: receiveForm.receiptDate,
    });

    ElMessage.success("收貨成功！已自動生成應付賬款憑證");
    receiveDialogVisible.value = false;
    await fetchPurchaseOrders();
  } catch (error) {
    if (error !== false) {
      console.error("收貨失敗:", error);
      ElMessage.error(error.message || "收貨失敗");
    }
  } finally {
    receiving.value = false;
  }
};

// 提交表單
const handleSubmit = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
    submitting.value = true;

    const submitData = {
      vendorId: formData.vendorId,
      orderDate: formData.orderDate,
      totalAmount: formData.totalAmount,
    };

    await purchaseOrderApi.createPurchaseOrder(submitData);
    ElMessage.success("新增訂單成功");
    dialogVisible.value = false;
    await fetchPurchaseOrders();
  } catch (error) {
    if (error !== false) {
      console.error("提交失敗:", error);
      ElMessage.error(error.message || "提交失敗");
    }
  } finally {
    submitting.value = false;
  }
};

// 重置表單
const resetForm = () => {
  Object.assign(formData, {
    vendorId: null,
    orderDate: "",
    totalAmount: 0,
  });
  formRef.value?.clearValidate();
};

// 組件掛載時獲取數據
onMounted(() => {
  console.log("PurchaseOrderManagement 組件已掛載");
  fetchPurchaseOrders();
  fetchVendors();
});
</script>

<style scoped>
.purchase-order-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
}

.search-card {
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.page-header {
  margin-bottom: 24px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 32px;
}

.page-subtitle {
  margin: 8px 0 0 44px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.text-muted {
  color: #909399;
  font-style: italic;
}
</style>









