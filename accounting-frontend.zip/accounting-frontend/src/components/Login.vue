<template>
  <div class="login-page">
    <div class="login-container">
      <div class="login-card-wrapper">
        <el-card class="main-card" shadow="always">
          <template #header>
            <div class="card-header">
              <div class="header-content">
                <el-icon class="header-icon"><UserFilled /></el-icon>
                <span class="header-title">使用者登入</span>
              </div>
              <el-tag v-if="isLoggedIn" type="success" size="large">已登入</el-tag>
              <el-tag v-else type="info" size="large">未登入</el-tag>
            </div>
          </template>

          <div v-if="!isLoggedIn" class="login-form-container">
            <el-form :model="form" label-width="120px" class="login-form" size="large">
              <el-form-item label="使用者名稱" class="form-item-large">
                <el-input 
                  v-model="form.username" 
                  placeholder="請輸入使用者名稱"
                  :prefix-icon="User"
                  size="large"
                  clearable
                />
              </el-form-item>
              <el-form-item label="密碼" class="form-item-large">
                <el-input 
                  v-model="form.password" 
                  type="password" 
                  placeholder="請輸入密碼"
                  :prefix-icon="Lock"
                  size="large"
                  show-password
                  clearable
                  @keyup.enter="handleLogin"
                />
              </el-form-item>
              <el-form-item class="form-item-large">
                <el-button 
                  type="primary" 
                  @click="handleLogin" 
                  :loading="loading"
                  size="large"
                  class="login-button"
                >
                  <el-icon v-if="!loading"><Right /></el-icon>
                  <span style="margin-left: 8px">登入</span>
                </el-button>
                <el-button @click="reset" size="large" class="reset-button">重置</el-button>
              </el-form-item>
            </el-form>
            
            <el-divider>預設帳號資訊</el-divider>
            
            <div class="account-info">
              <el-alert type="info" :closable="false" show-icon>
                <template #title>
                  <div class="account-list">
                    <div class="account-item">
                      <el-tag type="success" size="small">管理員</el-tag>
                      <span>admin / admin123</span>
                    </div>
                    <div class="account-item">
                      <el-tag type="primary" size="small">會計</el-tag>
                      <span>accountant / accountant123</span>
                    </div>
                    <div class="account-item">
                      <el-tag type="warning" size="small">審計</el-tag>
                      <span>auditor / auditor123</span>
                    </div>
                    <div class="account-item">
                      <el-tag type="info" size="small">出納</el-tag>
                      <span>cashier / cashier123</span>
                    </div>
                    <div class="account-item">
                      <el-tag type="danger" size="small">查看者</el-tag>
                      <span>viewer / viewer123</span>
                    </div>
                  </div>
                </template>
              </el-alert>
            </div>
          </div>

          <div v-else class="profile-container">
            <div class="profile-header">
              <el-icon class="profile-icon"><UserFilled /></el-icon>
              <h3>當前使用者資訊</h3>
            </div>
            <el-descriptions title="" :column="1" border class="profile-descriptions">
              <el-descriptions-item label="使用者名稱">
                <span class="profile-value">{{ profile.username }}</span>
              </el-descriptions-item>
              <el-descriptions-item label="角色">
                <el-tag 
                  v-for="r in profile.roles" 
                  :key="r" 
                  type="info" 
                  size="large"
                  class="role-tag"
                >
                  {{ r }}
                </el-tag>
              </el-descriptions-item>
            </el-descriptions>
            <div class="logout-container">
              <el-button type="danger" @click="logout" size="large" class="logout-button">
                <el-icon><SwitchButton /></el-icon>
                <span style="margin-left: 8px">登出</span>
              </el-button>
            </div>
          </div>
        </el-card>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { User, Lock, Right, UserFilled, SwitchButton } from '@element-plus/icons-vue'
import api, { authApi } from '../api/index.js'

const form = reactive({ username: '', password: '' })
const loading = ref(false)
const profile = reactive({ username: '', roles: [] })

const isLoggedIn = computed(() => !!localStorage.getItem('auth_token'))

const loadProfileFromStorage = () => {
  const u = localStorage.getItem('auth_user')
  const r = localStorage.getItem('auth_roles')
  profile.username = u || ''
  profile.roles = r ? JSON.parse(r) : []
}

onMounted(() => {
  loadProfileFromStorage()
})

const handleLogin = async () => {
  if (!form.username || !form.password) {
    ElMessage.warning('請輸入使用者名稱與密碼')
    return
  }
  loading.value = true
  try {
    const resp = await authApi.login({ username: form.username, password: form.password })
    // 保存 token 與角色
    localStorage.setItem('auth_token', resp.token)
    localStorage.setItem('auth_user', resp.username)
    localStorage.setItem('auth_roles', JSON.stringify(resp.roles || []))
    loadProfileFromStorage()
    ElMessage.success('登入成功');
    window.dispatchEvent(new CustomEvent('auth-change'));
  } catch (e) {
    ElMessage.error(e.message || '登入失敗')
  } finally {
    loading.value = false
  }
}

const reset = () => {
  form.username = ''
  form.password = ''
}

const logout = () => {
  localStorage.removeItem('auth_token')
  localStorage.removeItem('auth_user')
  localStorage.removeItem('auth_roles')
  loadProfileFromStorage()
  ElMessage.success('已登出');
  window.dispatchEvent(new CustomEvent('auth-change'));
}
</script>

<style scoped>
.login-page {
  min-height: calc(100vh - 64px);
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  padding: 40px 20px;
}

.login-container {
  width: 100%;
  max-width: 800px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.login-card-wrapper {
  width: 100%;
  animation: fadeInUp 0.5s ease-out;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.main-card {
  border-radius: 16px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  border: 1px solid #e4e7ed;
}

.main-card :deep(.el-card__header) {
  background: #ffffff;
  color: #303133;
  padding: 30px;
  border-bottom: 1px solid #e4e7ed;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-content {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-icon {
  font-size: 32px;
  color: #409eff;
}

.header-title {
  font-size: 28px;
  font-weight: 600;
  color: #303133;
  letter-spacing: 0.5px;
}

.main-card :deep(.el-card__body) {
  padding: 50px;
}

.login-form-container {
  width: 100%;
}

.login-form {
  margin-bottom: 30px;
}

.form-item-large {
  margin-bottom: 30px;
}

.form-item-large :deep(.el-form-item__label) {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.form-item-large :deep(.el-input__wrapper) {
  padding: 12px 15px;
  font-size: 16px;
}

.login-button {
  width: 150px;
  height: 50px;
  font-size: 16px;
  font-weight: 600;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.login-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(64, 158, 255, 0.3);
}

.reset-button {
  width: 150px;
  height: 50px;
  font-size: 16px;
  font-weight: 600;
  border-radius: 8px;
  margin-left: 20px;
}

.account-info {
  margin-top: 30px;
}

.account-info :deep(.el-alert) {
  border-radius: 12px;
  padding: 20px;
}

.account-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.account-item {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 15px;
}

.account-item span {
  font-family: 'Courier New', monospace;
  color: #606266;
}

.profile-container {
  width: 100%;
}

.profile-header {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 2px solid #f0f0f0;
}

.profile-icon {
  font-size: 40px;
  color: #409eff;
}

.profile-header h3 {
  margin: 0;
  font-size: 24px;
  font-weight: 700;
  color: #303133;
}

.profile-descriptions {
  margin-bottom: 30px;
}

.profile-descriptions :deep(.el-descriptions__label) {
  font-size: 16px;
  font-weight: 600;
  width: 150px;
}

.profile-value {
  font-size: 18px;
  font-weight: 600;
  color: #409eff;
}

.role-tag {
  margin-right: 8px;
  padding: 8px 16px;
  font-size: 14px;
}

.logout-container {
  display: flex;
  justify-content: center;
  margin-top: 30px;
}

.logout-button {
  width: 200px;
  height: 50px;
  font-size: 16px;
  font-weight: 600;
  border-radius: 8px;
}

:deep(.el-divider__text) {
  background-color: #fff;
  color: #909399;
  font-size: 14px;
  padding: 0 20px;
}

/* 響應式設計 */
@media (max-width: 768px) {
  .main-card :deep(.el-card__body) {
    padding: 30px 20px;
  }
  
  .header-title {
    font-size: 22px;
  }
  
  .form-item-large :deep(.el-form-item__label) {
    width: 100px !important;
  }
  
  .login-button,
  .reset-button {
    width: 100%;
    margin-left: 0;
    margin-top: 10px;
  }
}
</style>


