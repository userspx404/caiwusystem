<template>
  <div class="bank-reconciliation-management" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><Document /></el-icon>
        银行对账
      </h1>
      <p class="page-subtitle">自动匹配银行对账单与系统凭证，确保账目一致</p>
    </div>

    <el-card class="main-card" shadow="hover">
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span style="font-size: 18px; font-weight: 600">自动银行对账</span>
        </div>
      </template>

      <!-- 对账表单 -->
      <el-card class="form-card" shadow="never" style="margin-bottom: 20px">
        <el-form
          ref="formRef"
          :model="reconciliationForm"
          :rules="formRules"
          label-width="140px"
        >
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="银行账户" prop="accountId">
                <el-select
                  v-model="reconciliationForm.accountId"
                  placeholder="请选择银行账户（资产科目）"
                  filterable
                  style="width: 100%"
                >
                  <el-option
                    v-for="account in bankAccounts"
                    :key="account.id"
                    :label="`${account.code} - ${account.name}`"
                    :value="account.id"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="容差金额" prop="tolerance">
                <el-input-number
                  v-model="reconciliationForm.tolerance"
                  :min="0"
                  :precision="2"
                  :step="0.01"
                  style="width: 100%"
                />
                <div style="margin-top: 5px; color: #909399; font-size: 12px">
                  允许的金额差异范围（默认：0.01）
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item>
            <el-button type="primary" @click="handleReconcile" :loading="reconciling" size="large">
              <el-icon><Document /></el-icon>
              执行自动对账
            </el-button>
            <el-button @click="handleReset">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 对账结果 -->
      <el-card v-if="reconciliationResult" class="result-card" shadow="never">
        <template #header>
          <div style="display: flex; justify-content: space-between; align-items: center">
            <span style="font-size: 16px; font-weight: 600">对账结果</span>
            <el-tag type="success" size="large">对账完成</el-tag>
          </div>
        </template>
        <el-descriptions :column="2" border>
          <el-descriptions-item label="处理的对账单数量">
            <span class="number-text">{{ reconciliationResult.totalStatementsProcessed }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="成功匹配数量">
            <span class="number-text success">{{ reconciliationResult.matchedCount }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="匹配的对账单ID" :span="2">
            <div v-if="reconciliationResult.matchedStatementIds && reconciliationResult.matchedStatementIds.length > 0">
              <el-tag
                v-for="id in reconciliationResult.matchedStatementIds"
                :key="id"
                type="success"
                size="small"
                style="margin-right: 8px; margin-bottom: 4px"
              >
                #{{ id }}
              </el-tag>
            </div>
            <span v-else class="text-muted">无</span>
          </el-descriptions-item>
          <el-descriptions-item label="匹配的凭证分录ID" :span="2">
            <div v-if="reconciliationResult.matchedSplitIds && reconciliationResult.matchedSplitIds.length > 0">
              <el-tag
                v-for="id in reconciliationResult.matchedSplitIds"
                :key="id"
                type="info"
                size="small"
                style="margin-right: 8px; margin-bottom: 4px"
              >
                #{{ id }}
              </el-tag>
            </div>
            <span v-else class="text-muted">无</span>
          </el-descriptions-item>
        </el-descriptions>
        <el-alert
          type="success"
          :closable="false"
          style="margin-top: 15px"
        >
          <template #title>
            <div>
              <strong>对账完成！</strong><br />
              共处理 {{ reconciliationResult.totalStatementsProcessed }} 条对账单，
              成功匹配 {{ reconciliationResult.matchedCount }} 条记录。
            </div>
          </template>
        </el-alert>
      </el-card>

      <!-- 说明信息 -->
      <el-alert
        type="info"
        :closable="false"
        style="margin-top: 20px"
      >
        <template #title>
          <div style="font-size: 14px; line-height: 1.6">
            <strong>使用说明：</strong><br />
            1. 选择需要进行对账的银行账户（资产类科目）<br />
            2. 设置容差金额，系统会自动匹配金额差异在容差范围内的记录<br />
            3. 点击「执行自动对账」按钮，系统会自动匹配银行对账单与系统凭证<br />
            4. 查看对账结果，了解匹配情况
          </div>
        </template>
      </el-alert>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { Document } from "@element-plus/icons-vue";
import { reconciliationApi, accountApi } from "../api/index.js";

// 数据
const bankAccounts = ref([]);
const reconciling = ref(false);
const formRef = ref(null);
const reconciliationResult = ref(null);

// 对账表单
const reconciliationForm = reactive({
  accountId: null,
  tolerance: 0.01,
});

// 表单验证规则
const formRules = {
  accountId: [
    { required: true, message: "请选择银行账户", trigger: "change" },
  ],
  tolerance: [
    { required: true, message: "请输入容差金额", trigger: "blur" },
    {
      type: "number",
      min: 0,
      message: "容差金额必须大于等于 0",
      trigger: "blur",
    },
  ],
};

// 获取银行账户列表（资产类科目）
const fetchBankAccounts = async () => {
  try {
    const data = await accountApi.getAllAccounts();
    // 筛选资产类科目（通常代码以1开头）
    bankAccounts.value = Array.isArray(data)
      ? data.filter((a) => a.code?.startsWith("1") || a.type === "ASSET")
      : [];
  } catch (error) {
    console.error("获取银行账户列表失败:", error);
    bankAccounts.value = [];
  }
};

// 执行对账
const handleReconcile = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
    reconciling.value = true;
    reconciliationResult.value = null;

    const submitData = {
      accountId: reconciliationForm.accountId,
      tolerance: reconciliationForm.tolerance,
    };

    const result = await reconciliationApi.autoReconcile(submitData);
    reconciliationResult.value = result;
    ElMessage.success("银行对账完成！");
  } catch (error) {
    if (error !== false) {
      console.error("执行对账失败:", error);
      ElMessage.error(error.message || "执行对账失败，请检查后端服务是否启动");
    }
  } finally {
    reconciling.value = false;
  }
};

// 重置表单
const handleReset = () => {
  Object.assign(reconciliationForm, {
    accountId: null,
    tolerance: 0.01,
  });
  reconciliationResult.value = null;
  formRef.value?.clearValidate();
};

// 组件挂载时获取数据
onMounted(() => {
  console.log("BankReconciliationManagement 组件已挂载");
  fetchBankAccounts();
});
</script>

<style scoped>
.bank-reconciliation-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
}

.form-card {
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.result-card {
  background: #fff;
  border: 1px solid #e9ecef;
}

.page-header {
  margin-bottom: 24px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 32px;
}

.page-subtitle {
  margin: 8px 0 0 44px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.number-text {
  font-weight: 600;
  font-size: 16px;
  font-family: "Courier New", monospace;
}

.number-text.success {
  color: #67c23a;
}

.text-muted {
  color: #909399;
  font-style: italic;
}
</style>









