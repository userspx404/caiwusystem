<template>
  <div class="valuation-management" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><Document /></el-icon>
        外币估值
      </h1>
      <p class="page-subtitle">对外币账户进行估值调整，生成估值调整凭证</p>
    </div>

    <el-card class="main-card" shadow="hover">
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span style="font-size: 18px; font-weight: 600">外币估值调整</span>
        </div>
      </template>

      <!-- 估值表单 -->
      <el-card class="form-card" shadow="never" style="margin-bottom: 20px">
        <el-form
          ref="formRef"
          :model="valuationForm"
          :rules="formRules"
          label-width="140px"
        >
          <el-form-item label="估值日期" prop="valuationDate">
            <el-date-picker
              v-model="valuationForm.valuationDate"
              type="date"
              placeholder="选择估值日期"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              style="width: 300px"
            />
            <div style="margin-top: 5px; color: #909399; font-size: 12px">
              系统将根据该日期的汇率对外币账户进行估值调整
            </div>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleValuation" :loading="valuating" size="large">
              <el-icon><Document /></el-icon>
              执行外币估值
            </el-button>
            <el-button @click="handleReset">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 估值结果 -->
      <el-card v-if="valuationResult" class="result-card" shadow="never">
        <template #header>
          <div style="display: flex; justify-content: space-between; align-items: center">
            <span style="font-size: 16px; font-weight: 600">估值调整结果</span>
            <el-tag type="success" size="large">估值完成</el-tag>
          </div>
        </template>
        <el-descriptions :column="2" border>
          <el-descriptions-item label="凭证ID">
            <el-tag type="success" size="large">#{{ valuationResult.id }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="凭证号码">
            {{ valuationResult.voucherNo || "-" }}
          </el-descriptions-item>
          <el-descriptions-item label="凭证日期">
            {{ formatDate(valuationResult.date) }}
          </el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="getStatusType(valuationResult.status)">
              {{ getStatusText(valuationResult.status) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="摘要" :span="2">
            {{ valuationResult.description || "外币估值调整" }}
          </el-descriptions-item>
        </el-descriptions>

        <!-- 凭证分录 -->
        <div v-if="valuationResult.splits && valuationResult.splits.length > 0" style="margin-top: 20px">
          <h3 style="margin-bottom: 15px; font-size: 16px; color: #303133">凭证分录</h3>
          <el-table :data="valuationResult.splits" border style="width: 100%">
            <el-table-column type="index" label="序号" width="60" />
            <el-table-column prop="accountCode" label="科目代码" width="120" />
            <el-table-column prop="accountName" label="科目名称" min-width="200" />
            <el-table-column prop="balanceDirection" label="方向" width="100">
              <template #default="{ row }">
                <el-tag :type="row.balanceDirection === 'DEBIT' ? 'success' : 'warning'" size="small">
                  {{ row.balanceDirection === 'DEBIT' ? '借方' : '贷方' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="amount" label="金额" width="150" align="right">
              <template #default="{ row }">
                <span class="amount-text">{{ formatAmount(row.amount) }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="description" label="摘要" min-width="200" />
          </el-table>
        </div>

        <el-alert
          type="success"
          :closable="false"
          style="margin-top: 15px"
        >
          <template #title>
            <div>
              <strong>估值调整完成！</strong><br />
              已生成估值调整凭证 #{{ valuationResult.id }}，请前往「凭证管理」查看详情。
            </div>
          </template>
        </el-alert>
      </el-card>

      <!-- 说明信息 -->
      <el-alert
        type="info"
        :closable="false"
        style="margin-top: 20px"
      >
        <template #title>
          <div style="font-size: 14px; line-height: 1.6">
            <strong>使用说明：</strong><br />
            1. 选择估值日期，系统将根据该日期的汇率对外币账户进行估值<br />
            2. 点击「执行外币估值」按钮，系统会自动计算汇率差异并生成调整凭证<br />
            3. 如果无需调整（如无外币余额或汇率无变化），系统将不生成凭证<br />
            4. 生成的调整凭证可以在「凭证管理」中查看和管理
          </div>
        </template>
      </el-alert>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { Document } from "@element-plus/icons-vue";
import { valuationApi } from "../api/index.js";

// 数据
const valuating = ref(false);
const formRef = ref(null);
const valuationResult = ref(null);

// 估值表单
const valuationForm = reactive({
  valuationDate: new Date().toISOString().split("T")[0],
});

// 表单验证规则
const formRules = {
  valuationDate: [
    { required: true, message: "请选择估值日期", trigger: "change" },
  ],
};

// 格式化金额
const formatAmount = (amount) => {
  if (amount == null) return "0.00";
  return Number(amount).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

// 格式化日期
const formatDate = (date) => {
  if (!date) return "-";
  if (typeof date === "string") return date;
  return new Date(date).toLocaleDateString("zh-CN");
};

// 获取状态类型
const getStatusType = (status) => {
  const statusMap = {
    DRAFT: "info",
    AUDITED: "warning",
    POSTED: "success",
    CANCELLED: "danger",
  };
  return statusMap[status] || "";
};

// 获取状态文本
const getStatusText = (status) => {
  const statusMap = {
    DRAFT: "草稿",
    AUDITED: "已审核",
    POSTED: "已过账",
    CANCELLED: "已作废",
  };
  return statusMap[status] || status;
};

// 执行估值
const handleValuation = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
    valuating.value = true;
    valuationResult.value = null;

    const submitData = {
      valuationDate: valuationForm.valuationDate,
    };

    const result = await valuationApi.performValuation(submitData);
    
    if (result) {
      valuationResult.value = result;
      ElMessage.success("外币估值调整完成！");
    } else {
      ElMessage.info("当前无需进行估值调整（无外币余额或汇率无变化）");
    }
  } catch (error) {
    if (error !== false) {
      console.error("执行估值失败:", error);
      if (error.status === 204) {
        ElMessage.info("当前无需进行估值调整");
      } else {
        ElMessage.error(error.message || "执行估值失败，请检查后端服务是否启动");
      }
    }
  } finally {
    valuating.value = false;
  }
};

// 重置表单
const handleReset = () => {
  valuationForm.valuationDate = new Date().toISOString().split("T")[0];
  valuationResult.value = null;
  formRef.value?.clearValidate();
};

// 组件挂载时
onMounted(() => {
  console.log("ValuationManagement 组件已挂载");
});
</script>

<style scoped>
.valuation-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
}

.form-card {
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.result-card {
  background: #fff;
  border: 1px solid #e9ecef;
}

.page-header {
  margin-bottom: 24px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 32px;
}

.page-subtitle {
  margin: 8px 0 0 44px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.amount-text {
  font-weight: 500;
  font-family: "Courier New", monospace;
}
</style>









