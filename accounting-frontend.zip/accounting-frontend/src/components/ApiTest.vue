<template>
  <div class="api-test-container">
    <el-card class="test-card">
      <template #header>
        <div class="card-header">
          <span>後端 API 連接測試</span>
        </div>
      </template>

      <el-space direction="vertical" size="large" style="width: 100%">
        <!-- 測試按鈕組 -->
        <el-space wrap>
          <el-button type="primary" @click="testAccounts" :loading="loading.accounts">
            測試科目列表 API
          </el-button>
          <el-button type="success" @click="testVendors" :loading="loading.vendors">
            測試供應商列表 API
          </el-button>
          <el-button type="warning" @click="testCustomers" :loading="loading.customers">
            測試客戶列表 API
          </el-button>
          <el-button type="info" @click="clearResults">
            清除結果
          </el-button>
        </el-space>

        <!-- 結果顯示區域 -->
        <el-card v-if="result" shadow="hover">
          <template #header>
            <div class="result-header">
              <el-tag :type="result.success ? 'success' : 'danger'">
                {{ result.success ? '成功' : '失敗' }}
              </el-tag>
              <span style="margin-left: 10px">{{ result.api }}</span>
            </div>
          </template>

          <div v-if="result.success">
            <el-alert
              :title="`成功獲取 ${result.data?.length || 0} 條記錄`"
              type="success"
              :closable="false"
              style="margin-bottom: 15px"
            />
            <el-table :data="result.data" stripe border style="width: 100%" max-height="400">
              <el-table-column
                v-for="(value, key) in result.data[0] || {}"
                :key="key"
                :prop="key"
                :label="key"
                :min-width="120"
              />
            </el-table>
          </div>

          <div v-else>
            <el-alert
              :title="result.error || '未知錯誤'"
              type="error"
              :closable="false"
            />
          </div>
        </el-card>

        <!-- 原始響應數據 -->
        <el-card v-if="result && result.raw" shadow="hover">
          <template #header>
            <span>原始響應數據</span>
          </template>
          <pre class="json-display">{{ JSON.stringify(result.raw, null, 2) }}</pre>
        </el-card>
      </el-space>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { accountApi, vendorApi, customerApi } from '../api/index'
import { ElMessage } from 'element-plus'

const loading = reactive({
  accounts: false,
  vendors: false,
  customers: false
})

const result = ref(null)

const testAccounts = async () => {
  loading.accounts = true
  result.value = null
  
  try {
    const data = await accountApi.getAllAccounts()
    result.value = {
      success: true,
      api: 'GET /api/accounts',
      data: Array.isArray(data) ? data : [data],
      raw: data
    }
    ElMessage.success('科目列表 API 測試成功！')
  } catch (error) {
    result.value = {
      success: false,
      api: 'GET /api/accounts',
      error: error.message || JSON.stringify(error),
      raw: error
    }
    ElMessage.error('科目列表 API 測試失敗：' + (error.message || '未知錯誤'))
  } finally {
    loading.accounts = false
  }
}

const testVendors = async () => {
  loading.vendors = true
  result.value = null
  
  try {
    const data = await vendorApi.getAllVendors()
    result.value = {
      success: true,
      api: 'GET /api/vendors',
      data: Array.isArray(data) ? data : [data],
      raw: data
    }
    ElMessage.success('供應商列表 API 測試成功！')
  } catch (error) {
    result.value = {
      success: false,
      api: 'GET /api/vendors',
      error: error.message || JSON.stringify(error),
      raw: error
    }
    ElMessage.error('供應商列表 API 測試失敗：' + (error.message || '未知錯誤'))
  } finally {
    loading.vendors = false
  }
}

const testCustomers = async () => {
  loading.customers = true
  result.value = null
  
  try {
    const data = await customerApi.getAllCustomers()
    result.value = {
      success: true,
      api: 'GET /api/customers',
      data: Array.isArray(data) ? data : [data],
      raw: data
    }
    ElMessage.success('客戶列表 API 測試成功！')
  } catch (error) {
    result.value = {
      success: false,
      api: 'GET /api/customers',
      error: error.message || JSON.stringify(error),
      raw: error
    }
    ElMessage.error('客戶列表 API 測試失敗：' + (error.message || '未知錯誤'))
  } finally {
    loading.customers = false
  }
}

const clearResults = () => {
  result.value = null
  ElMessage.info('已清除測試結果')
}
</script>

<style scoped>
.api-test-container {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.test-card {
  width: 100%;
}

.card-header {
  font-size: 18px;
  font-weight: bold;
}

.result-header {
  display: flex;
  align-items: center;
}

.json-display {
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 12px;
  line-height: 1.5;
  max-height: 400px;
  overflow-y: auto;
}
</style>












