<template>
  <div class="transaction-management" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><Edit /></el-icon>
        凭证录入与审核
      </h1>
      <p class="page-subtitle">录入会计凭证，确保借贷平衡</p>
    </div>

    <!-- 说明卡片 -->
    <el-alert
      type="info"
      :closable="false"
      style="margin-bottom: 20px"
    >
      <template #title>
        <div style="font-size: 14px; line-height: 1.6">
          <strong>使用说明：</strong><br />
          1. 凭证必须至少包含两条分录（一借一贷）<br />
          2. <strong>借方合计 = 贷方合计</strong>（借贷必须平衡）<br />
          3. 示例：销售商品收到现金 10,000 元<br />
          &nbsp;&nbsp;&nbsp;→ 借方：现金 10,000（资产增加）<br />
          &nbsp;&nbsp;&nbsp;→ 贷方：销售收入 10,000（收入增加）<br />
          4. 点击「创建测试凭证示例」查看完整示例
        </div>
      </template>
    </el-alert>

    <!-- 凭证列表 -->
    <el-card class="list-card" shadow="hover" style="margin-bottom: 20px">
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span style="font-size: 18px; font-weight: 600">凭证列表</span>
          <div>
            <el-button v-if="hasRole('ACCOUNTANT')" type="primary" @click="handleCreate">
              <el-icon><Plus /></el-icon>
              新增凭证
            </el-button>
            <el-button v-if="hasRole('AUDITOR')" type="success" @click="handleBatchPost" :loading="posting" style="margin-left: 10px">
              <el-icon><Check /></el-icon>
              批量过账
            </el-button>
          </div>
        </div>
      </template>

      <!-- 搜索和筛选 -->
      <el-card class="search-card" shadow="never" style="margin-bottom: 20px">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="凭证号码">
            <el-input
              v-model="searchForm.voucherNo"
              placeholder="请输入凭证号码"
              clearable
              style="width: 200px"
            />
          </el-form-item>
          <el-form-item label="状态">
            <el-select
              v-model="searchForm.status"
              placeholder="请选择状态"
              clearable
              style="width: 150px"
            >
              <el-option label="草稿" value="DRAFT" />
              <el-option label="已审核" value="AUDITED" />
              <el-option label="已过账" value="POSTED" />
              <el-option label="已作废" value="CANCELLED" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">查询</el-button>
            <el-button @click="handleResetSearch">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 凭证列表表格 -->
      <el-empty
        v-if="!loading && transactions.length === 0"
        description="暂无凭证数据，点击「新增凭证」开始录入"
        :image-size="120"
      >
        <el-button type="primary" @click="handleCreate">新增凭证</el-button>
      </el-empty>

      <el-table
        v-else
        v-loading="loading"
        :data="filteredTransactions"
        stripe
        style="width: 100%"
      >
        <el-table-column prop="id" label="凭证ID" width="100" />
        <el-table-column prop="voucherNo" label="凭证号码" width="180" />
        <el-table-column prop="date" label="凭证日期" width="120">
          <template #default="{ row }">
            {{ formatDate(row.date) }}
          </template>
        </el-table-column>
        <el-table-column prop="description" label="摘要" min-width="200" show-overflow-tooltip />
        <el-table-column prop="status" label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="分录数" width="100" align="center">
          <template #default="{ row }">
            {{ row.splits?.length || 0 }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="250">
          <template #default="{ row }">
            <el-button type="info" size="small" @click="handleViewTransaction(row)">
              查看
            </el-button>
            <el-button
              v-if="canAudit(row) && hasRole('AUDITOR')"
              type="warning"
              size="small"
              @click="handleAudit(row)"
              style="margin-left: 8px"
            >
              审核
            </el-button>
            <el-button
              v-if="canCancel(row) && hasRole('AUDITOR')"
              type="danger"
              size="small"
              @click="handleCancelTransaction(row)"
              style="margin-left: 8px"
            >
              作废
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 凭证录入 -->
    <el-card class="main-card" shadow="hover" v-if="showCreateForm">
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span style="font-size: 18px; font-weight: 600">凭证录入</span>
          <el-button @click="showCreateForm = false">关闭</el-button>
        </div>
      </template>

      <el-empty
        v-if="!currentTransaction"
        description="暂无凭证数据，点击「新增凭证」开始录入"
        :image-size="120"
      >
        <div style="display: flex; gap: 10px; justify-content: center">
          <el-button type="primary" @click="handleCreate">新增凭证</el-button>
          <el-button type="success" @click="createTestTransaction">创建测试凭证示例</el-button>
        </div>
      </el-empty>

      <div v-else>
        <!-- 凭证基本信息 -->
        <el-card class="form-card" shadow="never" style="margin-bottom: 20px">
          <el-form :model="transactionForm" label-width="120px">
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="凭证号码">
                  <el-input v-model="transactionForm.voucherNo" placeholder="自动生成或手动输入" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="凭证日期">
                  <el-date-picker
                    v-model="transactionForm.date"
                    type="date"
                    placeholder="选择日期"
                    format="YYYY-MM-DD"
                    value-format="YYYY-MM-DD"
                    style="width: 100%"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="摘要">
              <el-input
                v-model="transactionForm.description"
                type="textarea"
                :rows="2"
                placeholder="请输入凭证摘要"
              />
            </el-form-item>
            <el-form-item label="状态">
              <el-tag :type="getStatusType(transactionForm.status)">
                {{ getStatusText(transactionForm.status) }}
              </el-tag>
            </el-form-item>
          </el-form>
        </el-card>

        <!-- 凭证分录列表 -->
        <el-card class="splits-card" shadow="never" style="margin-bottom: 20px">
          <template #header>
            <div style="display: flex; justify-content: space-between; align-items: center">
              <span>凭证分录</span>
              <el-button type="primary" size="small" @click="handleAddSplit">
                <el-icon><Plus /></el-icon>
                添加分录
              </el-button>
            </div>
          </template>

          <el-table :data="transactionForm.splits" border style="width: 100%">
            <el-table-column type="index" label="序号" width="60" />
            <el-table-column label="科目" min-width="200">
              <template #default="{ row, $index }">
                <el-select
                  v-model="row.accountId"
                  placeholder="选择科目"
                  filterable
                  style="width: 100%"
                  @change="handleAccountChange($index, row)"
                >
                  <el-option
                    v-for="account in accounts"
                    :key="account.id"
                    :label="`${account.code} - ${account.name}`"
                    :value="account.id"
                  />
                </el-select>
              </template>
            </el-table-column>
            <el-table-column label="方向" width="120">
              <template #default="{ row }">
                <el-select v-model="row.balanceDirection" style="width: 100%">
                  <el-option label="借方" value="DEBIT" />
                  <el-option label="贷方" value="CREDIT" />
                </el-select>
              </template>
            </el-table-column>
            <el-table-column label="金额" width="150">
              <template #default="{ row }">
                <el-input-number
                  v-model="row.amount"
                  :min="0"
                  :precision="2"
                  :step="100"
                  style="width: 100%"
                />
              </template>
            </el-table-column>
            <el-table-column label="摘要" min-width="200">
              <template #default="{ row }">
                <el-input v-model="row.description" placeholder="分录摘要" />
              </template>
            </el-table-column>
            <el-table-column label="操作" width="100">
              <template #default="{ $index }">
                <el-button
                  type="danger"
                  size="small"
                  @click="handleRemoveSplit($index)"
                >
                  删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>

          <!-- 借贷平衡检查 -->
          <div style="margin-top: 20px; padding: 15px; background: #f5f7fa; border-radius: 4px">
            <el-row :gutter="20">
              <el-col :span="8">
                <div>
                  <strong>借方合计：</strong>
                  <span :class="balanceCheck.debitClass">
                    {{ formatAmount(balanceCheck.debitTotal) }}
                  </span>
                </div>
              </el-col>
              <el-col :span="8">
                <div>
                  <strong>贷方合计：</strong>
                  <span :class="balanceCheck.creditClass">
                    {{ formatAmount(balanceCheck.creditTotal) }}
                  </span>
                </div>
              </el-col>
              <el-col :span="8">
                <div>
                  <strong>差额：</strong>
                  <span :class="balanceCheck.differenceClass">
                    {{ formatAmount(balanceCheck.difference) }}
                  </span>
                </div>
              </el-col>
            </el-row>
            <el-alert
              v-if="balanceCheck.isBalanced"
              type="success"
              :closable="false"
              style="margin-top: 10px"
            >
              借贷平衡，可以保存
            </el-alert>
            <el-alert
              v-else
              type="warning"
              :closable="false"
              style="margin-top: 10px"
            >
              借贷不平衡，请检查分录金额
            </el-alert>
          </div>
        </el-card>

        <!-- 操作按钮 -->
        <div style="text-align: right; margin-top: 20px">
          <el-button @click="handleCancel">取消</el-button>
          <el-button type="primary" @click="handleSave" :loading="saving">
            保存凭证
          </el-button>
        </div>
      </div>
    </el-card>

    <!-- 查看凭证详情对话框 -->
    <el-dialog v-model="viewDialogVisible" title="凭证详情" width="900px">
      <el-descriptions :column="2" border v-if="viewingTransaction">
        <el-descriptions-item label="凭证ID">{{ viewingTransaction.id }}</el-descriptions-item>
        <el-descriptions-item label="凭证号码">{{ viewingTransaction.voucherNo }}</el-descriptions-item>
        <el-descriptions-item label="凭证日期">{{ formatDate(viewingTransaction.date) }}</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="getStatusType(viewingTransaction.status)">
            {{ getStatusText(viewingTransaction.status) }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="摘要" :span="2">
          {{ viewingTransaction.description || "-" }}
        </el-descriptions-item>
      </el-descriptions>

      <!-- 凭证分录 -->
      <div v-if="viewingTransaction?.splits && viewingTransaction.splits.length > 0" style="margin-top: 20px">
        <h3 style="margin-bottom: 15px; font-size: 16px; color: #303133">凭证分录</h3>
        <el-table :data="viewingTransaction.splits" border style="width: 100%">
          <el-table-column type="index" label="序号" width="60" />
          <el-table-column prop="accountCode" label="科目代码" width="120" />
          <el-table-column prop="accountName" label="科目名称" min-width="200" />
          <el-table-column prop="balanceDirection" label="方向" width="100">
            <template #default="{ row }">
              <el-tag :type="row.balanceDirection === 'DEBIT' ? 'success' : 'warning'" size="small">
                {{ row.balanceDirection === 'DEBIT' ? '借方' : '贷方' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="amount" label="金额" width="150" align="right">
            <template #default="{ row }">
              <span class="amount-text">{{ formatAmount(row.amount) }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="description" label="摘要" min-width="200" />
        </el-table>
      </div>
      <template #footer>
        <el-button @click="viewDialogVisible = false">关闭</el-button>
        <el-button
          v-if="canAudit(viewingTransaction)"
          type="warning"
          @click="handleAudit(viewingTransaction)"
          style="margin-left: 10px"
        >
          审核
        </el-button>
        <el-button
          v-if="canCancel(viewingTransaction)"
          type="danger"
          @click="handleCancelTransaction(viewingTransaction)"
          style="margin-left: 10px"
        >
          作废
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from "vue";

// 角色/權限輔助
const userRoles = ref([]);
const loadRoles = () => {
  try {
    const r = localStorage.getItem('auth_roles');
    userRoles.value = r ? JSON.parse(r) : [];
  } catch (e) {
    userRoles.value = [];
  }
};
const hasRole = (role) => userRoles.value.includes(role);
const hasAnyRole = (...roles) => roles.some(r => userRoles.value.includes(r));
import { ElMessage, ElMessageBox } from "element-plus";
import { Plus, Edit, Check } from "@element-plus/icons-vue";
import { transactionApi, accountApi, postingApi } from "../api/index.js";

// 數據
const accounts = ref([]);
const transactions = ref([]);
const loading = ref(false);
const currentTransaction = ref(null);
const saving = ref(false);
const posting = ref(false);
const showCreateForm = ref(false);
const viewDialogVisible = ref(false);
const viewingTransaction = ref(null);

// 搜索表單
const searchForm = reactive({
  voucherNo: "",
  status: "",
});

// 憑證表單
const transactionForm = reactive({
  id: null,
  voucherNo: "",
  date: new Date().toISOString().split("T")[0],
  description: "",
  status: "DRAFT",
  splits: [],
});

// 借貸平衡檢查
const balanceCheck = computed(() => {
  const debitTotal = transactionForm.splits
    .filter((s) => s.balanceDirection === "DEBIT")
    .reduce((sum, s) => sum + (Number(s.amount) || 0), 0);

  const creditTotal = transactionForm.splits
    .filter((s) => s.balanceDirection === "CREDIT")
    .reduce((sum, s) => sum + (Number(s.amount) || 0), 0);

  const difference = Math.abs(debitTotal - creditTotal);
  const isBalanced = difference < 0.01 && transactionForm.splits.length > 0;

  return {
    debitTotal,
    creditTotal,
    difference,
    isBalanced,
    debitClass: debitTotal > 0 ? "amount-text positive" : "amount-text",
    creditClass: creditTotal > 0 ? "amount-text positive" : "amount-text",
    differenceClass: isBalanced
      ? "amount-text positive"
      : "amount-text negative",
  };
});

// 格式化金額
const formatAmount = (amount) => {
  if (amount == null) return "0.00";
  return Number(amount).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

// 格式化日期
const formatDate = (date) => {
  if (!date) return "-";
  if (typeof date === "string") return date;
  return new Date(date).toLocaleDateString("zh-CN");
};

// 獲取狀態類型
const getStatusType = (status) => {
  const statusMap = {
    DRAFT: "info",
    AUDITED: "warning",
    POSTED: "success",
    CANCELLED: "danger",
  };
  return statusMap[status] || "";
};

// 獲取狀態文本
const getStatusText = (status) => {
  const statusMap = {
    DRAFT: "草稿",
    AUDITED: "已审核",
    POSTED: "已过账",
    CANCELLED: "已作废",
  };
  return statusMap[status] || status;
};

// 獲取科目列表
const fetchAccounts = async () => {
  try {
    const data = await accountApi.getAllAccounts();
    accounts.value = Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("获取科目列表失败:", error);
    ElMessage.error(error.message || "获取科目列表失败");
    accounts.value = [];
  }
};

// 科目選擇變化
const handleAccountChange = (index, row) => {
  const account = accounts.value.find((a) => a.id === row.accountId);
  if (account) {
    row.accountCode = account.code;
    row.accountName = account.name;
    // 根據科目類型自動設置方向
    if (account.balanceDirection) {
      row.balanceDirection = account.balanceDirection;
    }
  }
};

// 添加分錄
const handleAddSplit = () => {
  transactionForm.splits.push({
    accountId: null,
    accountCode: "",
    accountName: "",
    balanceDirection: "DEBIT",
    amount: 0,
    description: "",
  });
};

// 刪除分錄
const handleRemoveSplit = (index) => {
  transactionForm.splits.splice(index, 1);
};

// 過濾後的憑證列表
const filteredTransactions = computed(() => {
  try {
    if (!Array.isArray(transactions.value)) return [];
    let result = transactions.value;
    if (searchForm.voucherNo) {
      result = result.filter((t) =>
        t?.voucherNo?.toLowerCase().includes(searchForm.voucherNo.toLowerCase())
      );
    }
    if (searchForm.status) {
      result = result.filter((t) => t?.status === searchForm.status);
    }
    return result;
  } catch (error) {
    console.error("filteredTransactions 計算錯誤:", error);
    return [];
  }
});

// 獲取憑證列表
const fetchTransactions = async () => {
  loading.value = true;
  try {
    const data = await transactionApi.getAllTransactions();
    transactions.value = Array.isArray(data) ? data : [];
    if (transactions.value.length === 0) {
      console.log("憑證列表為空，但請求成功");
    }
  } catch (error) {
    console.error("獲取憑證列表失敗:", error);
    const errorMessage = error.message || "獲取憑證列表失敗";
    
    // 根據錯誤類型顯示不同的提示
    if (error.code === "NETWORK_ERROR") {
      ElMessage.error({
        message: errorMessage,
        duration: 5000,
        showClose: true
      });
    } else {
      ElMessage.error(errorMessage);
    }
    
    transactions.value = [];
  } finally {
    loading.value = false;
  }
};

// 搜索
const handleSearch = () => {
  // 搜索邏輯已在 computed 中實現
};

// 重置搜索
const handleResetSearch = () => {
  searchForm.voucherNo = "";
  searchForm.status = "";
};

// 判斷是否可以審核
const canAudit = (transaction) => {
  if (!transaction) return false;
  return transaction.status === "DRAFT";
};

// 判斷是否可以取消
const canCancel = (transaction) => {
  if (!transaction) return false;
  return transaction.status === "DRAFT" || transaction.status === "AUDITED";
};

// 查看憑證詳情
const handleViewTransaction = (row) => {
  viewingTransaction.value = { ...row };
  viewDialogVisible.value = true;
};

// 審核憑證
const handleAudit = async (row) => {
  try {
    await ElMessageBox.confirm(
      `確定要審核憑證「${row.voucherNo}」嗎？`,
      "確認審核",
      {
        confirmButtonText: "確定",
        cancelButtonText: "取消",
        type: "warning",
      }
    );

    await transactionApi.auditTransaction(row.id, 1); // 使用默認審核人ID
    ElMessage.success("審核成功！");
    await fetchTransactions();
    if (viewDialogVisible.value) {
      viewDialogVisible.value = false;
    }
  } catch (error) {
    if (error !== "cancel") {
      console.error("審核失敗:", error);
      ElMessage.error(error.message || "審核失敗");
    }
  }
};

// 取消憑證
const handleCancelTransaction = async (row) => {
  try {
    await ElMessageBox.confirm(
      `確定要作廢憑證「${row.voucherNo}」嗎？`,
      "確認作廢",
      {
        confirmButtonText: "確定",
        cancelButtonText: "取消",
        type: "warning",
      }
    );

    await transactionApi.cancelTransaction(row.id);
    ElMessage.success("作廢成功！");
    await fetchTransactions();
    if (viewDialogVisible.value) {
      viewDialogVisible.value = false;
    }
  } catch (error) {
    if (error !== "cancel") {
      console.error("作廢失敗:", error);
      ElMessage.error(error.message || "作廢失敗");
    }
  }
};

// 新增憑證
const handleCreate = () => {
  showCreateForm.value = true;
  currentTransaction.value = { id: Date.now() };
  Object.assign(transactionForm, {
    id: null,
    voucherNo: "",
    date: new Date().toISOString().split("T")[0],
    description: "",
    status: "DRAFT",
    splits: [],
  });
  // 默認添加兩條分錄
  handleAddSplit();
  handleAddSplit();
};

// 創建測試憑證示例
const createTestTransaction = async () => {
  try {
    // 先獲取科目列表
    if (accounts.value.length === 0) {
      await fetchAccounts();
    }

    if (accounts.value.length < 2) {
      ElMessage.warning("请先在「科目管理」中创建至少两个科目");
      return;
    }

    // 選擇現金和銀行存款科目（通常是資產類科目，借方增加）
    const cashAccount = accounts.value.find(
      (a) => a.name?.includes("现金") || a.name?.includes("银行") || a.code?.startsWith("1")
    ) || accounts.value[0];

    // 選擇收入或負債科目（通常是貸方增加）
    const incomeAccount = accounts.value.find(
      (a) => a.name?.includes("收入") || a.name?.includes("应付") || a.code?.startsWith("4") || a.code?.startsWith("2")
    ) || accounts.value[1];

    // 創建測試憑證
    showCreateForm.value = true;
    currentTransaction.value = { id: Date.now() };
    Object.assign(transactionForm, {
      id: null,
      voucherNo: `VOUCHER-${new Date().getTime()}`,
      date: new Date().toISOString().split("T")[0],
      description: "测试凭证：销售商品收到现金",
      status: "DRAFT",
      splits: [
        {
          accountId: cashAccount.id,
          accountCode: cashAccount.code,
          accountName: cashAccount.name,
          balanceDirection: "DEBIT", // 借方：現金增加
          amount: 10000.0,
          description: "收到现金",
        },
        {
          accountId: incomeAccount.id,
          accountCode: incomeAccount.code,
          accountName: incomeAccount.name,
          balanceDirection: "CREDIT", // 貸方：收入增加
          amount: 10000.0,
          description: "销售收入",
        },
      ],
    });

    ElMessage.success("测试凭证已创建！这是一个借贷平衡的示例：\n借方（现金）10,000.00 = 贷方（收入）10,000.00");
  } catch (error) {
    console.error("创建测试凭证失败:", error);
    ElMessage.error(error.message || "创建测试凭证失败");
  }
};

// 取消
const handleCancel = () => {
  showCreateForm.value = false;
  currentTransaction.value = null;
  transactionForm.splits = [];
};

// 保存憑證
const handleSave = async () => {
  // 驗證
  if (!transactionForm.date) {
    ElMessage.warning("请选择凭证日期");
    return;
  }

  if (transactionForm.splits.length < 2) {
    ElMessage.warning("至少需要两条分录");
    return;
  }

  if (!balanceCheck.value.isBalanced) {
    ElMessage.warning("借贷不平衡，无法保存");
    return;
  }

  // 驗證每條分錄
  for (let i = 0; i < transactionForm.splits.length; i++) {
    const split = transactionForm.splits[i];
    if (!split.accountId) {
      ElMessage.warning(`第 ${i + 1} 条分录未选择科目`);
      return;
    }
    if (!split.amount || split.amount <= 0) {
      ElMessage.warning(`第 ${i + 1} 条分录金额无效`);
      return;
    }
  }

  try {
    saving.value = true;

    const submitData = {
      voucherNo: transactionForm.voucherNo || null,
      date: transactionForm.date,
      description: transactionForm.description,
      status: "DRAFT",
      splits: transactionForm.splits.map((s) => ({
        accountId: s.accountId,
        balanceDirection: s.balanceDirection,
        amount: s.amount,
        description: s.description || "",
      })),
    };

    await transactionApi.createTransaction(submitData);
    ElMessage.success("凭证保存成功");
    handleCancel();
    await fetchTransactions();
    showCreateForm.value = false;
  } catch (error) {
    console.error("保存凭证失败:", error);
    ElMessage.error(error.message || "保存凭证失败");
  } finally {
    saving.value = false;
  }
};

// 批量过账
const handleBatchPost = async () => {
  try {
    await ElMessageBox.confirm(
      "确定要执行批量过账操作吗？\n这将把所有状态为「已审核」的凭证批量过账为「已过账」状态。",
      "确认批量过账",
      {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }
    );

    posting.value = true;
    const result = await postingApi.batchPostTransactions();
    ElMessage.success(`批量过账成功！共过账 ${result.transactionsPosted || 0} 条凭证`);
    await fetchTransactions();
  } catch (error) {
    if (error !== "cancel") {
      console.error("批量过账失败:", error);
      ElMessage.error(error.message || "批量过账失败");
    }
  } finally {
    posting.value = false;
  }
};

// 組件掛載時獲取數據
onMounted(() => {
  loadRoles();
  fetchAccounts();
  fetchTransactions();
});
</script>

<style scoped>
.transaction-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
}

.form-card {
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.splits-card {
  background: #fff;
}

.amount-text {
  font-weight: 500;
  font-family: "Courier New", monospace;
}

.amount-text.positive {
  color: #67c23a;
}

.amount-text.negative {
  color: #f56c6c;
}

.page-header {
  margin-bottom: 24px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 32px;
}

.page-subtitle {
  margin: 8px 0 0 44px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.posting-card {
  background: #f0f9ff;
  border: 1px solid #bae6fd;
}
</style>

