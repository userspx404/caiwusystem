<template>
  <div class="tax-management" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><Document /></el-icon>
        税务管理
      </h1>
      <p class="page-subtitle">计算和申报税务，自动生成税务申报记录和付款申请</p>
    </div>

    <el-card class="main-card" shadow="hover">
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span style="font-size: 18px; font-weight: 600">税务计算与申报</span>
        </div>
      </template>

      <!-- 税务计算表单 -->
      <el-card class="form-card" shadow="never" style="margin-bottom: 20px">
        <el-form
          ref="formRef"
          :model="taxForm"
          :rules="formRules"
          label-width="140px"
        >
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="申报期间" prop="filingPeriod">
                <el-input
                  v-model="taxForm.filingPeriod"
                  placeholder="例如：2025-Q4"
                  style="width: 100%"
                />
                <div style="margin-top: 5px; color: #909399; font-size: 12px">
                  格式：YYYY-QN（如：2025-Q4）
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="税种" prop="taxType">
                <el-input
                  v-model="taxForm.taxType"
                  placeholder="例如：企业所得税"
                  style="width: 100%"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="开始日期" prop="startDate">
                <el-date-picker
                  v-model="taxForm.startDate"
                  type="date"
                  placeholder="选择开始日期"
                  format="YYYY-MM-DD"
                  value-format="YYYY-MM-DD"
                  style="width: 100%"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="结束日期" prop="endDate">
                <el-date-picker
                  v-model="taxForm.endDate"
                  type="date"
                  placeholder="选择结束日期"
                  format="YYYY-MM-DD"
                  value-format="YYYY-MM-DD"
                  style="width: 100%"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="税率" prop="taxRate">
                <el-input-number
                  v-model="taxForm.taxRate"
                  :min="0"
                  :max="1"
                  :precision="4"
                  :step="0.01"
                  style="width: 100%"
                />
                <div style="margin-top: 5px; color: #909399; font-size: 12px">
                  例如：0.25 表示 25%
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="银行账户" prop="bankAccountId">
                <el-select
                  v-model="taxForm.bankAccountId"
                  placeholder="请选择用于支付税款的银行账户"
                  filterable
                  style="width: 100%"
                >
                  <el-option
                    v-for="account in bankAccounts"
                    :key="account.id"
                    :label="`${account.code} - ${account.name}`"
                    :value="account.id"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item>
            <el-button type="primary" @click="handleCalculateAndFile" :loading="calculating" size="large">
              <el-icon><Document /></el-icon>
              计算并申报税务
            </el-button>
            <el-button @click="handleReset">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 申报结果 -->
      <el-card v-if="taxFilingResult" class="result-card" shadow="never">
        <template #header>
          <div style="display: flex; justify-content: space-between; align-items: center">
            <span style="font-size: 16px; font-weight: 600">申报结果</span>
            <el-tag :type="getFilingStatusType(taxFilingResult.filingStatus)" size="large">
              {{ getFilingStatusText(taxFilingResult.filingStatus) }}
            </el-tag>
          </div>
        </template>
        <el-descriptions :column="2" border>
          <el-descriptions-item label="申报ID">{{ taxFilingResult.id }}</el-descriptions-item>
          <el-descriptions-item label="申报期间">{{ taxFilingResult.filingPeriod }}</el-descriptions-item>
          <el-descriptions-item label="税种">{{ taxFilingResult.taxType }}</el-descriptions-item>
          <el-descriptions-item label="应缴税额">
            <span class="amount-text large">{{ formatAmount(taxFilingResult.payableAmount) }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="申报状态">
            <el-tag :type="getFilingStatusType(taxFilingResult.filingStatus)">
              {{ getFilingStatusText(taxFilingResult.filingStatus) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="付款申请ID" v-if="taxFilingResult.paymentRequestId">
            <el-tag type="success">#{{ taxFilingResult.paymentRequestId }}</el-tag>
          </el-descriptions-item>
        </el-descriptions>
        <el-alert
          type="success"
          :closable="false"
          style="margin-top: 15px"
        >
          <template #title>
            <div>
              <strong>申报成功！</strong><br />
              <span v-if="taxFilingResult.paymentRequestId">
                已自动创建付款申请 #{{ taxFilingResult.paymentRequestId }}，请在「付款管理」中执行付款。
              </span>
              <span v-else>
                本期无需缴纳税款。
              </span>
            </div>
          </template>
        </el-alert>
      </el-card>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { Document } from "@element-plus/icons-vue";
import { taxApi, accountApi } from "../api/index.js";

// 数据
const bankAccounts = ref([]);
const calculating = ref(false);
const formRef = ref(null);
const taxFilingResult = ref(null);

// 税务表单
const taxForm = reactive({
  filingPeriod: "",
  taxType: "企业所得税",
  startDate: "",
  endDate: "",
  taxRate: 0.25,
  bankAccountId: null,
});

// 表单验证规则
const formRules = {
  filingPeriod: [
    { required: true, message: "请输入申报期间", trigger: "blur" },
  ],
  taxType: [{ required: true, message: "请输入税种", trigger: "blur" }],
  startDate: [
    { required: true, message: "请选择开始日期", trigger: "change" },
  ],
  endDate: [
    { required: true, message: "请选择结束日期", trigger: "change" },
  ],
  taxRate: [
    { required: true, message: "请输入税率", trigger: "blur" },
    {
      type: "number",
      min: 0,
      max: 1,
      message: "税率必须在 0 到 1 之间",
      trigger: "blur",
    },
  ],
  bankAccountId: [
    { required: true, message: "请选择银行账户", trigger: "change" },
  ],
};

// 格式化金额
const formatAmount = (amount) => {
  if (amount == null) return "0.00";
  return Number(amount).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

// 获取申报状态类型
const getFilingStatusType = (status) => {
  const statusMap = {
    DRAFT: "info",
    FILED: "success",
    PAID: "success",
    FAILED: "danger",
  };
  return statusMap[status] || "";
};

// 获取申报状态文本
const getFilingStatusText = (status) => {
  const statusMap = {
    DRAFT: "草稿",
    FILED: "已申报",
    PAID: "已缴纳",
    FAILED: "申报失败",
  };
  return statusMap[status] || status;
};

// 获取银行账户列表（资产类科目）
const fetchBankAccounts = async () => {
  try {
    const data = await accountApi.getAllAccounts();
    // 筛选资产类科目（通常代码以1开头）
    bankAccounts.value = Array.isArray(data)
      ? data.filter((a) => a.code?.startsWith("1") || a.type === "ASSET")
      : [];
  } catch (error) {
    console.error("获取银行账户列表失败:", error);
    bankAccounts.value = [];
  }
};

// 计算并申报税务
const handleCalculateAndFile = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
    calculating.value = true;
    taxFilingResult.value = null;

    const submitData = {
      filingPeriod: taxForm.filingPeriod,
      taxType: taxForm.taxType,
      startDate: taxForm.startDate,
      endDate: taxForm.endDate,
      taxRate: taxForm.taxRate,
      bankAccountId: taxForm.bankAccountId,
    };

    const result = await taxApi.calculateAndFile(submitData);
    
    if (result) {
      taxFilingResult.value = result;
      ElMessage.success("税务计算和申报成功！");
    } else {
      ElMessage.info("本期无需缴纳税款，未创建申报记录");
    }
  } catch (error) {
    if (error !== false) {
      console.error("计算并申报税务失败:", error);
      if (error.status === 204) {
        ElMessage.info("本期无需缴纳税款");
      } else {
        ElMessage.error(error.message || "计算并申报税务失败");
      }
    }
  } finally {
    calculating.value = false;
  }
};

// 重置表单
const handleReset = () => {
  Object.assign(taxForm, {
    filingPeriod: "",
    taxType: "企业所得税",
    startDate: "",
    endDate: "",
    taxRate: 0.25,
    bankAccountId: null,
  });
  taxFilingResult.value = null;
  formRef.value?.clearValidate();
};

// 组件挂载时获取数据
onMounted(() => {
  console.log("TaxManagement 组件已挂载");
  fetchBankAccounts();
});
</script>

<style scoped>
.tax-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
}

.form-card {
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.result-card {
  background: #fff;
  border: 1px solid #e9ecef;
}

.page-header {
  margin-bottom: 24px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 32px;
}

.page-subtitle {
  margin: 8px 0 0 44px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.amount-text {
  font-weight: 500;
  font-family: "Courier New", monospace;
}

.amount-text.large {
  font-size: 18px;
  font-weight: 700;
  color: #f56c6c;
}
</style>

