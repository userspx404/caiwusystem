<template>
  <div class="financial-report-management" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><Document /></el-icon>
        财务报表生成
      </h1>
      <p class="page-subtitle">生成资产负债表和利润表</p>
    </div>

    <el-card class="main-card" shadow="hover">
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span style="font-size: 18px; font-weight: 600">报表生成</span>
        </div>
      </template>

      <!-- 报表生成表单 -->
      <el-card class="form-card" shadow="never" style="margin-bottom: 20px">
        <el-form :model="reportForm" label-width="120px" :inline="true">
          <el-form-item label="报表类型" prop="reportType">
            <el-select
              v-model="reportForm.reportType"
              placeholder="请选择报表类型"
              style="width: 200px"
            >
              <el-option label="资产负债表" value="BALANCE_SHEET" />
              <el-option label="利润表" value="INCOME_STATEMENT" />
            </el-select>
          </el-form-item>
          <el-form-item label="报表日期" prop="reportDate">
            <el-date-picker
              v-model="reportForm.reportDate"
              type="date"
              placeholder="选择日期"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              style="width: 200px"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleGenerate" :loading="generating">
              <el-icon><Search /></el-icon>
              生成报表
            </el-button>
            <el-button @click="handleReset">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 报表显示区域 -->
      <div v-if="currentReport">
        <el-card class="report-card" shadow="never">
          <template #header>
            <div style="display: flex; justify-content: space-between; align-items: center">
              <div>
                <h2 style="margin: 0; font-size: 20px; color: #303133">
                  {{ currentReport.reportName }}
                </h2>
                <p style="margin: 5px 0 0 0; font-size: 14px; color: #909399">
                  报表日期：{{ formatDate(currentReport.reportDate) }}
                </p>
              </div>
              <el-button type="success" @click="handleExport">
                <el-icon><Download /></el-icon>
                导出报表
              </el-button>
            </div>
          </template>

          <!-- 资产负债表 -->
          <div v-if="reportForm.reportType === 'BALANCE_SHEET'">
            <el-table
              :data="balanceSheetData"
              border
              style="width: 100%; margin-bottom: 20px"
              :show-header="true"
            >
              <el-table-column prop="section" label="项目" width="300" />
              <el-table-column prop="item" label="科目" min-width="200" />
              <el-table-column prop="amount" label="金额" width="200" align="right">
                <template #default="{ row }">
                  <span class="amount-text">{{ formatAmount(row.amount) }}</span>
                </template>
              </el-table-column>
            </el-table>

            <!-- 合计行 -->
            <div style="padding: 15px; background: #f5f7fa; border-radius: 4px; margin-top: 20px">
              <el-row :gutter="20">
                <el-col :span="12">
                  <div style="text-align: center">
                    <strong>资产合计：</strong>
                    <span class="amount-text large positive">
                      {{ formatAmount(currentReport.totalAssets) }}
                    </span>
                  </div>
                </el-col>
                <el-col :span="12">
                  <div style="text-align: center">
                    <strong>负债和权益合计：</strong>
                    <span class="amount-text large positive">
                      {{ formatAmount(currentReport.totalLiabilitiesAndEquity) }}
                    </span>
                  </div>
                </el-col>
              </el-row>
              <el-alert
                v-if="isBalanceSheetBalanced"
                type="success"
                :closable="false"
                style="margin-top: 15px"
              >
                资产负债表平衡：资产合计 = 负债和权益合计
              </el-alert>
              <el-alert
                v-else
                type="warning"
                :closable="false"
                style="margin-top: 15px"
              >
                资产负债表不平衡，请检查数据
              </el-alert>
            </div>
          </div>

          <!-- 利润表 -->
          <div v-else-if="reportForm.reportType === 'INCOME_STATEMENT'">
            <el-table
              :data="incomeStatementData"
              border
              style="width: 100%; margin-bottom: 20px"
            >
              <el-table-column prop="section" label="项目" width="300" />
              <el-table-column prop="item" label="科目" min-width="200" />
              <el-table-column prop="amount" label="金额" width="200" align="right">
                <template #default="{ row }">
                  <span :class="getAmountClass(row.amount)">
                    {{ formatAmount(row.amount) }}
                  </span>
                </template>
              </el-table-column>
            </el-table>

            <!-- 净利润 -->
            <div style="padding: 15px; background: #f5f7fa; border-radius: 4px; margin-top: 20px">
              <div style="text-align: center">
                <strong>净利润：</strong>
                <span :class="getNetIncomeClass()" class="amount-text large">
                  {{ formatAmount(currentReport.netIncome) }}
                </span>
              </div>
            </div>
          </div>
        </el-card>
      </div>

      <!-- 空状态 -->
      <el-empty
        v-else
        description="请选择报表类型和日期，然后点击「生成报表」"
        :image-size="120"
      />
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from "vue";
import { ElMessage } from "element-plus";
import { Search, Download, Document } from "@element-plus/icons-vue";
import { reportApi } from "../api/index.js";

// 数据
const currentReport = ref(null);
const generating = ref(false);

// 报表表单
const reportForm = reactive({
  reportType: "BALANCE_SHEET",
  reportDate: new Date().toISOString().split("T")[0],
});

// 资产负债表数据
const balanceSheetData = computed(() => {
  if (!currentReport.value || !currentReport.value.sections) return [];
  const data = [];
  for (const [sectionName, section] of Object.entries(currentReport.value.sections)) {
    if (section.items && section.items.length > 0) {
      section.items.forEach((item, index) => {
        data.push({
          section: index === 0 ? sectionName : "",
          item: item.accountName || item.name || item.accountCode || item.code || "-",
          amount: item.balance || item.amount || 0,
        });
      });
      // 添加小计行
      if (section.subtotal != null) {
        data.push({
          section: "",
          item: `${sectionName}小计`,
          amount: section.subtotal,
          isSubtotal: true,
        });
      }
    }
  }
  return data;
});

// 利润表数据
const incomeStatementData = computed(() => {
  if (!currentReport.value || !currentReport.value.sections) return [];
  const data = [];
  for (const [sectionName, section] of Object.entries(currentReport.value.sections)) {
    if (section.items && section.items.length > 0) {
      section.items.forEach((item, index) => {
        data.push({
          section: index === 0 ? sectionName : "",
          item: item.accountName || item.name || item.accountCode || item.code || "-",
          amount: item.balance || item.amount || 0,
        });
      });
      // 添加小计行
      if (section.subtotal != null) {
        data.push({
          section: "",
          item: `${sectionName}小计`,
          amount: section.subtotal,
          isSubtotal: true,
        });
      }
    }
  }
  return data;
});

// 资产负债表是否平衡
const isBalanceSheetBalanced = computed(() => {
  if (!currentReport.value) return false;
  const assets = currentReport.value.totalAssets || 0;
  const liabilities = currentReport.value.totalLiabilitiesAndEquity || 0;
  return Math.abs(Number(assets) - Number(liabilities)) < 0.01;
});

// 格式化金额
const formatAmount = (amount) => {
  if (amount == null) return "0.00";
  return Number(amount).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

// 格式化日期
const formatDate = (date) => {
  if (!date) return "-";
  if (typeof date === "string") return date;
  return new Date(date).toLocaleDateString("zh-CN");
};

// 获取金额样式类
const getAmountClass = (amount) => {
  const num = Number(amount);
  if (num > 0) return "amount-text positive";
  if (num < 0) return "amount-text negative";
  return "amount-text";
};

// 获取净利润样式类
const getNetIncomeClass = () => {
  if (!currentReport.value) return "";
  const netIncome = Number(currentReport.value.netIncome || 0);
  return netIncome >= 0 ? "positive" : "negative";
};

// 生成报表
const handleGenerate = async () => {
  if (!reportForm.reportType) {
    ElMessage.warning("请选择报表类型");
    return;
  }

  if (!reportForm.reportDate) {
    ElMessage.warning("请选择报表日期");
    return;
  }

  try {
    generating.value = true;
    const data = await reportApi.generateReport({
      reportType: reportForm.reportType,
      reportDate: reportForm.reportDate,
    });
    currentReport.value = data;
    ElMessage.success("报表生成成功");
  } catch (error) {
    console.error("生成报表失败:", error);
    ElMessage.error(error.message || "生成报表失败，请检查后端服务是否启动");
    currentReport.value = null;
  } finally {
    generating.value = false;
  }
};

// 重置
const handleReset = () => {
  reportForm.reportType = "BALANCE_SHEET";
  reportForm.reportDate = new Date().toISOString().split("T")[0];
  currentReport.value = null;
};

// 导出报表
const handleExport = () => {
  if (!currentReport.value) {
    ElMessage.warning("请先生成报表");
    return;
  }

  // 简单的导出功能（可以后续扩展为PDF或Excel导出）
  const reportText = generateReportText();
  const blob = new Blob([reportText], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${currentReport.value.reportName}_${reportForm.reportDate}.txt`;
  link.click();
  URL.revokeObjectURL(url);
  ElMessage.success("报表导出成功");
};

// 生成报表文本
const generateReportText = () => {
  if (!currentReport.value) return "";
  let text = `${currentReport.value.reportName}\n`;
  text += `报表日期：${formatDate(currentReport.value.reportDate)}\n`;
  text += "=".repeat(50) + "\n\n";

  if (reportForm.reportType === "BALANCE_SHEET") {
    text += "资产合计：" + formatAmount(currentReport.value.totalAssets) + "\n";
    text += "负债和权益合计：" + formatAmount(currentReport.value.totalLiabilitiesAndEquity) + "\n";
  } else {
    text += "净利润：" + formatAmount(currentReport.value.netIncome) + "\n";
  }

  return text;
};
</script>

<style scoped>
.financial-report-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
}

.form-card {
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.report-card {
  background: #fff;
}

.page-header {
  margin-bottom: 24px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 32px;
}

.page-subtitle {
  margin: 8px 0 0 44px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.amount-text {
  font-weight: 500;
  font-family: "Courier New", monospace;
}

.amount-text.positive {
  color: #67c23a;
}

.amount-text.negative {
  color: #f56c6c;
}

.amount-text.large {
  font-size: 20px;
  font-weight: 700;
}
</style>

