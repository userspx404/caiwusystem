<template>
  <div class="vendor-management">
    <el-card class="main-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon class="header-icon"><User /></el-icon>
            <span class="header-title">供應商管理</span>
            <el-tag type="info" size="small" class="count-tag">
              共 {{ vendors.length }} 項
            </el-tag>
          </div>
          <el-button type="primary" @click="handleAdd" class="add-button">
            <el-icon><Plus /></el-icon>
            新增供應商
          </el-button>
        </div>
      </template>

      <!-- 搜索和筛选 -->
      <el-card class="search-card" shadow="never">
        <el-form :inline="true" :model="searchForm" class="search-form">
          <el-form-item label="供應商名稱">
            <el-input
              v-model="searchForm.vendorName"
              placeholder="請輸入供應商名稱"
              clearable
              class="search-input"
              @keyup.enter="handleSearch"
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          <el-form-item label="稅號">
            <el-input
              v-model="searchForm.taxId"
              placeholder="請輸入稅號"
              clearable
              class="search-input"
              @keyup.enter="handleSearch"
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          <el-form-item label="狀態">
            <el-select
              v-model="searchForm.status"
              placeholder="請選擇狀態"
              clearable
              class="search-select"
            >
              <el-option label="有效" value="有效" />
              <el-option label="無效" value="無效" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch" :icon="Search">
              查詢
            </el-button>
            <el-button @click="handleReset" :icon="Refresh">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 供應商列表表格 -->
      <el-table
        v-loading="loading"
        :data="filteredVendors"
        stripe
        class="data-table"
        style="width: 100%"
        :default-sort="{ prop: 'id', order: 'ascending' }"
        :row-class-name="tableRowClassName"
      >
        <el-table-column prop="id" label="ID" width="80" sortable />
        <el-table-column prop="vendorName" label="供應商名稱" min-width="180" sortable />
        <el-table-column prop="taxId" label="稅號" width="150" sortable />
        <el-table-column prop="contactPerson" label="聯繫人" width="120" />
        <el-table-column prop="bankAcctNo" label="銀行帳號" width="180" />
        <el-table-column prop="settlementCurrency" label="結算貨幣" width="120">
          <template #default="{ row }">
            <el-tag v-if="row.settlementCurrency" type="info" size="small">
              {{ row.settlementCurrency }}
            </el-tag>
            <span v-else class="text-muted">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="狀態" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === '有效' ? 'success' : 'danger'">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button
              type="primary"
              size="small"
              :icon="Edit"
              @click="handleEdit(row)"
              class="action-button"
            >
              編輯
            </el-button>
            <el-button
              type="danger"
              size="small"
              :icon="Delete"
              @click="handleDelete(row)"
              class="action-button"
            >
              刪除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/編輯對話框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogTitle"
      width="600px"
      :close-on-click-modal="false"
      class="form-dialog"
    >
      <el-form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        label-width="120px"
        class="form-content"
      >
        <el-form-item label="供應商名稱" prop="vendorName">
          <el-input
            v-model="formData.vendorName"
            placeholder="請輸入供應商名稱"
            clearable
          />
        </el-form-item>
        <el-form-item label="稅號" prop="taxId">
          <el-input
            v-model="formData.taxId"
            placeholder="請輸入稅號（唯一）"
            clearable
          />
        </el-form-item>
        <el-form-item label="聯繫人" prop="contactPerson">
          <el-input
            v-model="formData.contactPerson"
            placeholder="請輸入聯繫人姓名"
            clearable
          />
        </el-form-item>
        <el-form-item label="銀行帳號" prop="bankAcctNo">
          <el-input
            v-model="formData.bankAcctNo"
            placeholder="請輸入銀行帳號"
            clearable
          />
        </el-form-item>
        <el-form-item label="結算貨幣" prop="settlementCurrency">
          <el-input
            v-model="formData.settlementCurrency"
            placeholder="例如：CNY, USD"
            clearable
          />
        </el-form-item>
        <el-form-item label="狀態" prop="status">
          <el-select v-model="formData.status" placeholder="請選擇狀態" style="width: 100%">
            <el-option label="有效" value="有效" />
            <el-option label="無效" value="無效" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handleSubmit" :loading="submitting">
            確定
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Search,
  Refresh,
  Plus,
  Edit,
  Delete,
  User,
} from "@element-plus/icons-vue";
import { vendorApi } from "../api/index.js";

// 數據
const vendors = ref([]);
const loading = ref(false);
const dialogVisible = ref(false);
const dialogTitle = ref("新增供應商");
const submitting = ref(false);
const formRef = ref(null);

// 搜索表單
const searchForm = reactive({
  vendorName: "",
  taxId: "",
  status: "",
});

// 表單數據
const formData = reactive({
  id: null,
  vendorName: "",
  taxId: "",
  contactPerson: "",
  bankAcctNo: "",
  settlementCurrency: "",
  status: "有效",
});

// 表單驗證規則
const formRules = {
  vendorName: [
    { required: true, message: "請輸入供應商名稱", trigger: "blur" },
    { min: 2, max: 150, message: "長度在 2 到 150 個字符", trigger: "blur" },
  ],
  taxId: [
    { required: true, message: "請輸入稅號", trigger: "blur" },
    { min: 1, max: 50, message: "長度在 1 到 50 個字符", trigger: "blur" },
  ],
  contactPerson: [
    { max: 100, message: "長度不能超過 100 個字符", trigger: "blur" },
  ],
  bankAcctNo: [
    { max: 50, message: "長度不能超過 50 個字符", trigger: "blur" },
  ],
  settlementCurrency: [
    { max: 10, message: "長度不能超過 10 個字符", trigger: "blur" },
  ],
  status: [
    { required: true, message: "請選擇狀態", trigger: "change" },
  ],
};

// 過濾後的供應商列表
const filteredVendors = computed(() => {
  let result = vendors.value;

  if (searchForm.vendorName) {
    result = result.filter((v) =>
      v.vendorName?.toLowerCase().includes(searchForm.vendorName.toLowerCase())
    );
  }

  if (searchForm.taxId) {
    result = result.filter((v) =>
      v.taxId?.toLowerCase().includes(searchForm.taxId.toLowerCase())
    );
  }

  if (searchForm.status) {
    result = result.filter((v) => v.status === searchForm.status);
  }

  return result;
});

// 獲取供應商列表
const fetchVendors = async () => {
  loading.value = true;
  try {
    const data = await vendorApi.getAllVendors();
    vendors.value = Array.isArray(data) ? data : [];
    ElMessage.success("供應商列表加載成功");
  } catch (error) {
    console.error("獲取供應商列表失敗:", error);
    ElMessage.error(error.message || "獲取供應商列表失敗");
    vendors.value = [];
  } finally {
    loading.value = false;
  }
};

// 搜索
const handleSearch = () => {
  // 搜索邏輯已在 computed 中實現
};

// 重置搜索
const handleReset = () => {
  searchForm.vendorName = "";
  searchForm.taxId = "";
  searchForm.status = "";
};

// 新增
const handleAdd = () => {
  dialogTitle.value = "新增供應商";
  resetForm();
  dialogVisible.value = true;
};

// 編輯
const handleEdit = (row) => {
  dialogTitle.value = "編輯供應商";
  Object.assign(formData, {
    id: row.id,
    vendorName: row.vendorName || "",
    taxId: row.taxId || "",
    contactPerson: row.contactPerson || "",
    bankAcctNo: row.bankAcctNo || "",
    settlementCurrency: row.settlementCurrency || "",
    status: row.status || "有效",
  });
  dialogVisible.value = true;
};

// 刪除
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(
      `確定要刪除供應商「${row.vendorName}」嗎？此操作不可恢復。`,
      "確認刪除",
      {
        confirmButtonText: "確定",
        cancelButtonText: "取消",
        type: "warning",
      }
    );

    loading.value = true;
    await vendorApi.deleteVendor(row.id);
    ElMessage.success("刪除成功");
    await fetchVendors();
  } catch (error) {
    if (error !== "cancel") {
      console.error("刪除供應商失敗:", error);
      ElMessage.error(error.message || "刪除供應商失敗");
    }
  } finally {
    loading.value = false;
  }
};

// 提交表單
const handleSubmit = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
    submitting.value = true;

    const submitData = {
      vendorName: formData.vendorName,
      taxId: formData.taxId,
      contactPerson: formData.contactPerson || null,
      bankAcctNo: formData.bankAcctNo || null,
      settlementCurrency: formData.settlementCurrency || null,
      status: formData.status,
    };

    if (formData.id) {
      // 更新
      await vendorApi.updateVendor(formData.id, submitData);
      ElMessage.success("更新成功");
    } else {
      // 新增
      await vendorApi.createVendor(submitData);
      ElMessage.success("新增成功");
    }

    dialogVisible.value = false;
    await fetchVendors();
  } catch (error) {
    if (error !== false) {
      // false 表示驗證失敗，不需要顯示錯誤
      console.error("提交失敗:", error);
      ElMessage.error(error.message || "提交失敗");
    }
  } finally {
    submitting.value = false;
  }
};

// 重置表單
const resetForm = () => {
  Object.assign(formData, {
    id: null,
    vendorName: "",
    taxId: "",
    contactPerson: "",
    bankAcctNo: "",
    settlementCurrency: "",
    status: "有效",
  });
  formRef.value?.clearValidate();
};

// 表格行樣式
const tableRowClassName = ({ rowIndex }) => {
  return rowIndex % 2 === 1 ? "table-row-even" : "";
};

// 組件掛載時獲取數據
onMounted(() => {
  fetchVendors();
});
</script>

<style scoped>
.vendor-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
  overflow: hidden;
  background: #fff;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-icon {
  font-size: 24px;
  color: #667eea;
}

.header-title {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}

.count-tag {
  margin-left: 8px;
}

.add-button {
  border-radius: 6px;
  padding: 10px 20px;
  font-weight: 500;
}

.search-card {
  margin-bottom: 20px;
  border-radius: 8px;
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.search-form {
  padding: 10px 0;
}

.search-input,
.search-select {
  width: 200px;
}

.data-table {
  border-radius: 8px;
  overflow: hidden;
}

.data-table :deep(.el-table__header) {
  background: #f5f7fa;
}

.data-table :deep(.el-table__header th) {
  background: #f5f7fa;
  color: #606266;
  font-weight: 600;
  border-bottom: 2px solid #e4e7ed;
}

.data-table :deep(.table-row-even) {
  background: #fafafa;
}

.data-table :deep(.el-table__row:hover) {
  background: #f0f9ff !important;
}

.action-button {
  margin-right: 8px;
}

.text-muted {
  color: #909399;
  font-style: italic;
}

.form-dialog :deep(.el-dialog__header) {
  padding: 20px 24px;
  border-bottom: 1px solid #e4e7ed;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 8px 8px 0 0;
}

.form-dialog :deep(.el-dialog__title) {
  color: #fff;
  font-weight: 600;
  font-size: 18px;
}

.form-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: #fff;
  font-size: 20px;
}

.form-dialog :deep(.el-dialog__body) {
  padding: 24px;
}

.form-content {
  padding: 10px 0;
}

.form-content :deep(.el-form-item__label) {
  font-weight: 500;
  color: #606266;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding-top: 10px;
}

@media (max-width: 768px) {
  .search-form {
    flex-direction: column;
  }

  .search-input,
  .search-select {
    width: 100%;
  }
}
</style>










