<template>
  <div class="customer-management">
    <el-card class="main-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon class="header-icon"><UserFilled /></el-icon>
            <span class="header-title">客戶管理</span>
            <el-tag type="info" size="small" class="count-tag">
              共 {{ customers.length }} 項
            </el-tag>
          </div>
          <el-button type="primary" @click="handleAdd" class="add-button">
            <el-icon><Plus /></el-icon>
            新增客戶
          </el-button>
        </div>
      </template>

      <!-- 搜索和筛选 -->
      <el-card class="search-card" shadow="never">
        <el-form :inline="true" :model="searchForm" class="search-form">
          <el-form-item label="客戶名稱">
            <el-input
              v-model="searchForm.customerName"
              placeholder="請輸入客戶名稱"
              clearable
              class="search-input"
              @keyup.enter="handleSearch"
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          <el-form-item label="稅號">
            <el-input
              v-model="searchForm.taxId"
              placeholder="請輸入稅號"
              clearable
              class="search-input"
              @keyup.enter="handleSearch"
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          <el-form-item label="狀態">
            <el-select
              v-model="searchForm.status"
              placeholder="請選擇狀態"
              clearable
              class="search-select"
            >
              <el-option label="有效" value="有效" />
              <el-option label="無效" value="無效" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch" :icon="Search">
              查詢
            </el-button>
            <el-button @click="handleReset" :icon="Refresh">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 客戶列表表格 -->
      <el-table
        v-loading="loading"
        :data="filteredCustomers"
        stripe
        class="data-table"
        style="width: 100%"
        :default-sort="{ prop: 'id', order: 'ascending' }"
        :row-class-name="tableRowClassName"
      >
        <el-table-column prop="id" label="ID" width="80" sortable />
        <el-table-column prop="customerName" label="客戶名稱" min-width="180" sortable />
        <el-table-column prop="taxId" label="稅號" width="150" />
        <el-table-column prop="creditLimit" label="信用額度" width="120" align="right">
          <template #default="{ row }">
            <span class="amount-text">{{ formatAmount(row.creditLimit) }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="currentBalance" label="當前餘額" width="120" align="right">
          <template #default="{ row }">
            <span :class="getBalanceClass(row.currentBalance)">
              {{ formatAmount(row.currentBalance) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="settlementCurrency" label="結算貨幣" width="120">
          <template #default="{ row }">
            <el-tag v-if="row.settlementCurrency" type="info" size="small">
              {{ row.settlementCurrency }}
            </el-tag>
            <span v-else class="text-muted">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="狀態" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === '有效' ? 'success' : 'danger'">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button
              type="primary"
              size="small"
              :icon="Edit"
              @click="handleEdit(row)"
              class="action-button"
            >
              編輯
            </el-button>
            <el-button
              type="danger"
              size="small"
              :icon="Delete"
              @click="handleDelete(row)"
              class="action-button"
            >
              刪除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/編輯對話框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogTitle"
      width="600px"
      :close-on-click-modal="false"
      class="form-dialog"
    >
      <el-form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        label-width="120px"
        class="form-content"
      >
        <el-form-item label="客戶名稱" prop="customerName">
          <el-input
            v-model="formData.customerName"
            placeholder="請輸入客戶名稱"
            clearable
          />
        </el-form-item>
        <el-form-item label="稅號" prop="taxId">
          <el-input
            v-model="formData.taxId"
            placeholder="請輸入稅號（可選）"
            clearable
          />
        </el-form-item>
        <el-form-item label="信用額度" prop="creditLimit">
          <el-input-number
            v-model="formData.creditLimit"
            :min="0"
            :precision="2"
            :step="1000"
            placeholder="請輸入信用額度"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="結算貨幣" prop="settlementCurrency">
          <el-input
            v-model="formData.settlementCurrency"
            placeholder="例如：CNY, USD"
            clearable
          />
        </el-form-item>
        <el-form-item label="狀態" prop="status">
          <el-select v-model="formData.status" placeholder="請選擇狀態" style="width: 100%">
            <el-option label="有效" value="有效" />
            <el-option label="無效" value="無效" />
          </el-select>
        </el-form-item>
        <el-form-item v-if="formData.id" label="當前餘額">
          <el-input-number
            :model-value="formData.currentBalance"
            disabled
            :precision="2"
            style="width: 100%"
          />
          <div class="form-tip">當前餘額由系統自動計算，不可手動修改</div>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handleSubmit" :loading="submitting">
            確定
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  Search,
  Refresh,
  Plus,
  Edit,
  Delete,
  UserFilled,
} from "@element-plus/icons-vue";
import { customerApi } from "../api/index.js";

// 數據
const customers = ref([]);
const loading = ref(false);
const dialogVisible = ref(false);
const dialogTitle = ref("新增客戶");
const submitting = ref(false);
const formRef = ref(null);

// 搜索表單
const searchForm = reactive({
  customerName: "",
  taxId: "",
  status: "",
});

// 表單數據
const formData = reactive({
  id: null,
  customerName: "",
  taxId: "",
  creditLimit: 0,
  currentBalance: 0,
  settlementCurrency: "",
  status: "有效",
});

// 表單驗證規則
const formRules = {
  customerName: [
    { required: true, message: "請輸入客戶名稱", trigger: "blur" },
    { min: 2, max: 150, message: "長度在 2 到 150 個字符", trigger: "blur" },
  ],
  taxId: [
    { max: 50, message: "長度不能超過 50 個字符", trigger: "blur" },
  ],
  creditLimit: [
    { required: true, message: "請輸入信用額度", trigger: "blur" },
    { type: "number", min: 0, message: "信用額度必須大於或等於 0", trigger: "blur" },
  ],
  settlementCurrency: [
    { max: 10, message: "長度不能超過 10 個字符", trigger: "blur" },
  ],
  status: [
    { required: true, message: "請選擇狀態", trigger: "change" },
  ],
};

// 過濾後的客戶列表
const filteredCustomers = computed(() => {
  let result = customers.value;

  if (searchForm.customerName) {
    result = result.filter((c) =>
      c.customerName?.toLowerCase().includes(searchForm.customerName.toLowerCase())
    );
  }

  if (searchForm.taxId) {
    result = result.filter((c) =>
      c.taxId?.toLowerCase().includes(searchForm.taxId.toLowerCase())
    );
  }

  if (searchForm.status) {
    result = result.filter((c) => c.status === searchForm.status);
  }

  return result;
});

// 格式化金額
const formatAmount = (amount) => {
  if (amount == null) return "0.00";
  return Number(amount).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

// 獲取餘額樣式類
const getBalanceClass = (balance) => {
  if (balance == null) return "amount-text";
  const num = Number(balance);
  if (num > 0) return "amount-text positive";
  if (num < 0) return "amount-text negative";
  return "amount-text";
};

// 獲取客戶列表
const fetchCustomers = async () => {
  loading.value = true;
  try {
    const data = await customerApi.getAllCustomers();
    customers.value = Array.isArray(data) ? data : [];
    ElMessage.success("客戶列表加載成功");
  } catch (error) {
    console.error("獲取客戶列表失敗:", error);
    ElMessage.error(error.message || "獲取客戶列表失敗");
    customers.value = [];
  } finally {
    loading.value = false;
  }
};

// 搜索
const handleSearch = () => {
  // 搜索邏輯已在 computed 中實現
};

// 重置搜索
const handleReset = () => {
  searchForm.customerName = "";
  searchForm.taxId = "";
  searchForm.status = "";
};

// 新增
const handleAdd = () => {
  dialogTitle.value = "新增客戶";
  resetForm();
  dialogVisible.value = true;
};

// 編輯
const handleEdit = (row) => {
  dialogTitle.value = "編輯客戶";
  Object.assign(formData, {
    id: row.id,
    customerName: row.customerName || "",
    taxId: row.taxId || "",
    creditLimit: row.creditLimit ? Number(row.creditLimit) : 0,
    currentBalance: row.currentBalance ? Number(row.currentBalance) : 0,
    settlementCurrency: row.settlementCurrency || "",
    status: row.status || "有效",
  });
  dialogVisible.value = true;
};

// 刪除
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(
      `確定要刪除客戶「${row.customerName}」嗎？此操作不可恢復。`,
      "確認刪除",
      {
        confirmButtonText: "確定",
        cancelButtonText: "取消",
        type: "warning",
      }
    );

    loading.value = true;
    await customerApi.deleteCustomer(row.id);
    ElMessage.success("刪除成功");
    await fetchCustomers();
  } catch (error) {
    if (error !== "cancel") {
      console.error("刪除客戶失敗:", error);
      ElMessage.error(error.message || "刪除客戶失敗");
    }
  } finally {
    loading.value = false;
  }
};

// 提交表單
const handleSubmit = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
    submitting.value = true;

    const submitData = {
      customerName: formData.customerName,
      taxId: formData.taxId || null,
      creditLimit: formData.creditLimit,
      settlementCurrency: formData.settlementCurrency || null,
      status: formData.status,
    };

    if (formData.id) {
      // 更新
      await customerApi.updateCustomer(formData.id, submitData);
      ElMessage.success("更新成功");
    } else {
      // 新增
      await customerApi.createCustomer(submitData);
      ElMessage.success("新增成功");
    }

    dialogVisible.value = false;
    await fetchCustomers();
  } catch (error) {
    if (error !== false) {
      // false 表示驗證失敗，不需要顯示錯誤
      console.error("提交失敗:", error);
      ElMessage.error(error.message || "提交失敗");
    }
  } finally {
    submitting.value = false;
  }
};

// 重置表單
const resetForm = () => {
  Object.assign(formData, {
    id: null,
    customerName: "",
    taxId: "",
    creditLimit: 0,
    currentBalance: 0,
    settlementCurrency: "",
    status: "有效",
  });
  formRef.value?.clearValidate();
};

// 表格行樣式
const tableRowClassName = ({ rowIndex }) => {
  return rowIndex % 2 === 1 ? "table-row-even" : "";
};

// 組件掛載時獲取數據
onMounted(() => {
  fetchCustomers();
});
</script>

<style scoped>
.customer-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
  overflow: hidden;
  background: #fff;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-icon {
  font-size: 24px;
  color: #667eea;
}

.header-title {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}

.count-tag {
  margin-left: 8px;
}

.add-button {
  border-radius: 6px;
  padding: 10px 20px;
  font-weight: 500;
}

.search-card {
  margin-bottom: 20px;
  border-radius: 8px;
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.search-form {
  padding: 10px 0;
}

.search-input,
.search-select {
  width: 200px;
}

.data-table {
  border-radius: 8px;
  overflow: hidden;
}

.data-table :deep(.el-table__header) {
  background: #f5f7fa;
}

.data-table :deep(.el-table__header th) {
  background: #f5f7fa;
  color: #606266;
  font-weight: 600;
  border-bottom: 2px solid #e4e7ed;
}

.data-table :deep(.table-row-even) {
  background: #fafafa;
}

.data-table :deep(.el-table__row:hover) {
  background: #f0f9ff !important;
}

.action-button {
  margin-right: 8px;
}

.text-muted {
  color: #909399;
  font-style: italic;
}

.amount-text {
  font-weight: 500;
  font-family: "Courier New", monospace;
}

.amount-text.positive {
  color: #67c23a;
}

.amount-text.negative {
  color: #f56c6c;
}

.form-dialog :deep(.el-dialog__header) {
  padding: 20px 24px;
  border-bottom: 1px solid #e4e7ed;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 8px 8px 0 0;
}

.form-dialog :deep(.el-dialog__title) {
  color: #fff;
  font-weight: 600;
  font-size: 18px;
}

.form-dialog :deep(.el-dialog__headerbtn .el-dialog__close) {
  color: #fff;
  font-size: 20px;
}

.form-dialog :deep(.el-dialog__body) {
  padding: 24px;
}

.form-content {
  padding: 10px 0;
}

.form-content :deep(.el-form-item__label) {
  font-weight: 500;
  color: #606266;
}

.form-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding-top: 10px;
}

@media (max-width: 768px) {
  .search-form {
    flex-direction: column;
  }

  .search-input,
  .search-select {
    width: 100%;
  }
}
</style>










