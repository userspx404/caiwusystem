<template>
  <div class="payment-management" style="padding: 20px">
    <div class="page-header">
      <h1 class="page-title">
        <el-icon class="title-icon"><CreditCard /></el-icon>
        付款管理
      </h1>
      <p class="page-subtitle">管理供应商付款申请和执行付款</p>
    </div>

    <el-card class="main-card" shadow="hover">
      <template #header>
        <div
          style="
            display: flex;
            justify-content: space-between;
            align-items: center;
          "
        >
          <span style="font-size: 18px; font-weight: 600">付款申请列表</span>
          <el-button
            v-if="hasAnyRole('ACCOUNTANT', 'CASHIER')"
            type="primary"
            @click="handleAdd"
          >
            <el-icon><Plus /></el-icon>
            新增付款申请
          </el-button>
        </div>
      </template>

      <!-- 搜索和筛选 -->
      <el-card class="search-card" shadow="never" style="margin-bottom: 20px">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="状态">
            <el-select
              v-model="searchForm.status"
              placeholder="请选择状态"
              clearable
              style="width: 200px"
              @change="handleStatusChange"
            >
              <el-option label="待执行" value="PENDING" />
              <el-option label="已支付" value="PAID" />
              <el-option label="支付失败" value="FAILED" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">查询</el-button>
            <el-button @click="handleReset">重置</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- 付款申请列表 -->
      <el-empty
        v-if="!loading && payments.length === 0"
        description="暂无付款申请数据"
        :image-size="120"
      >
        <el-button type="primary" @click="handleAdd">新增付款申请</el-button>
      </el-empty>

      <el-table
        v-else
        v-loading="loading"
        :data="payments"
        stripe
        style="width: 100%"
      >
        <el-table-column prop="id" label="申请ID" width="100" />
        <el-table-column prop="vendorName" label="供应商" min-width="180" />
        <el-table-column prop="requestDate" label="申请日期" width="120">
          <template #default="{ row }">
            {{ formatDate(row.requestDate) }}
          </template>
        </el-table-column>
        <el-table-column
          prop="amount"
          label="付款金额"
          width="140"
          align="right"
        >
          <template #default="{ row }">
            <span class="amount-text">{{ formatAmount(row.amount) }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="bankReceiptId" label="银行回单号" width="150">
          <template #default="{ row }">
            <span v-if="row.bankReceiptId" class="text-success">
              {{ row.bankReceiptId }}
            </span>
            <span v-else class="text-muted">-</span>
          </template>
        </el-table-column>
        <el-table-column prop="autoTransactionId" label="关联凭证" width="120">
          <template #default="{ row }">
            <el-tag v-if="row.autoTransactionId" type="success" size="small">
              #{{ row.autoTransactionId }}
            </el-tag>
            <span v-else class="text-muted">-</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200">
          <template #default="{ row }">
            <el-button type="info" size="small" @click="handleView(row)">
              查看
            </el-button>
            <el-button
              v-if="canExecute(row) && hasRole('CASHIER')"
              type="success"
              size="small"
              @click="handleExecute(row)"
              style="margin-left: 8px"
              :loading="executingPaymentId === row.id"
            >
              执行付款
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增付款申请对话框 -->
    <el-dialog v-model="dialogVisible" title="新增付款申请" width="600px">
      <el-form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        label-width="120px"
      >
        <el-form-item label="供应商" prop="vendorId">
          <el-select
            v-model="formData.vendorId"
            placeholder="请选择供应商"
            filterable
            style="width: 100%"
          >
            <el-option
              v-for="vendor in vendors"
              :key="vendor.id"
              :label="`${vendor.vendorName} (${vendor.taxId || '无税号'})`"
              :value="vendor.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="银行账户" prop="bankAccountId">
          <el-select
            v-model="formData.bankAccountId"
            placeholder="请选择银行账户（资产科目）"
            filterable
            style="width: 100%"
          >
            <el-option
              v-for="account in bankAccounts"
              :key="account.id"
              :label="`${account.code} - ${account.name}`"
              :value="account.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="付款金额" prop="amount">
          <el-input-number
            v-model="formData.amount"
            :min="0"
            :precision="2"
            :step="100"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="申请日期" prop="requestDate">
          <el-date-picker
            v-model="formData.requestDate"
            type="date"
            placeholder="选择日期（可选，默认今天）"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit" :loading="submitting">
          确定
        </el-button>
      </template>
    </el-dialog>

    <!-- 查看详情对话框 -->
    <el-dialog v-model="viewDialogVisible" title="付款申请详情" width="700px">
      <el-descriptions :column="2" border v-if="viewingPayment">
        <el-descriptions-item label="申请ID">{{
          viewingPayment.id
        }}</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="getStatusType(viewingPayment.status)">
            {{ getStatusText(viewingPayment.status) }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="供应商">{{
          viewingPayment.vendorName
        }}</el-descriptions-item>
        <el-descriptions-item label="供应商ID">{{
          viewingPayment.vendorId
        }}</el-descriptions-item>
        <el-descriptions-item label="申请日期">{{
          formatDate(viewingPayment.requestDate)
        }}</el-descriptions-item>
        <el-descriptions-item label="付款金额">
          <span class="amount-text large">{{
            formatAmount(viewingPayment.amount)
          }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="银行账户ID">{{
          viewingPayment.bankAccountId || "-"
        }}</el-descriptions-item>
        <el-descriptions-item label="银行回单号">
          <span v-if="viewingPayment.bankReceiptId" class="text-success">
            {{ viewingPayment.bankReceiptId }}
          </span>
          <span v-else class="text-muted">-</span>
        </el-descriptions-item>
        <el-descriptions-item label="关联凭证" :span="2">
          <el-tag v-if="viewingPayment.autoTransactionId" type="success">
            凭证 #{{ viewingPayment.autoTransactionId }}
          </el-tag>
          <span v-else class="text-muted">尚未生成凭证</span>
        </el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <el-button @click="viewDialogVisible = false">关闭</el-button>
      </template>
    </el-dialog>

    <!-- 执行付款对话框 -->
    <el-dialog v-model="executeDialogVisible" title="执行付款" width="500px">
      <el-alert type="warning" :closable="false" style="margin-bottom: 20px">
        此操作将模拟银企直连执行付款，并自动生成付款凭证
      </el-alert>
      <el-form ref="executeFormRef" :model="executeForm" label-width="120px">
        <el-form-item label="银行回单号">
          <el-input
            v-model="executeForm.bankReceiptId"
            placeholder="请输入银行回单号（可选）"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="executeDialogVisible = false">取消</el-button>
        <el-button type="success" @click="confirmExecute" :loading="executing">
          确认执行付款
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";

// 角色/權限輔助
const userRoles = ref([]);
const loadRoles = () => {
  try {
    const r = localStorage.getItem("auth_roles");
    userRoles.value = r ? JSON.parse(r) : [];
  } catch (e) {
    userRoles.value = [];
  }
};
const hasRole = (role) => userRoles.value.includes(role);
const hasAnyRole = (...roles) => roles.some((r) => userRoles.value.includes(r));
import { ElMessage } from "element-plus";
import { Plus, CreditCard } from "@element-plus/icons-vue";
import { paymentApi, vendorApi, accountApi } from "../api/index.js";

// 数据
const payments = ref([]);
const vendors = ref([]);
const bankAccounts = ref([]);
const loading = ref(false);
const dialogVisible = ref(false);
const viewDialogVisible = ref(false);
const executeDialogVisible = ref(false);
const submitting = ref(false);
const executing = ref(false);
const executingPaymentId = ref(null);
const formRef = ref(null);

const viewingPayment = ref(null);
const currentExecutePayment = ref(null);

// 搜索表单
const searchForm = reactive({
  status: "PENDING",
});

// 表单数据
const formData = reactive({
  vendorId: null,
  bankAccountId: null,
  amount: 0,
  requestDate: "",
});

// 执行付款表单
const executeForm = reactive({
  bankReceiptId: "",
});

// 表单验证规则
const formRules = {
  vendorId: [{ required: true, message: "请选择供应商", trigger: "change" }],
  bankAccountId: [
    { required: true, message: "请选择银行账户", trigger: "change" },
  ],
  amount: [
    { required: true, message: "请输入付款金额", trigger: "blur" },
    {
      type: "number",
      min: 0.01,
      message: "付款金额必须大于 0",
      trigger: "blur",
    },
  ],
};

// 格式化金额
const formatAmount = (amount) => {
  if (amount == null) return "0.00";
  return Number(amount).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

// 格式化日期
const formatDate = (date) => {
  if (!date) return "-";
  if (typeof date === "string") return date;
  return new Date(date).toLocaleDateString("zh-CN");
};

// 获取状态类型
const getStatusType = (status) => {
  const statusMap = {
    PENDING: "warning",
    PAID: "success",
    FAILED: "danger",
  };
  return statusMap[status] || "";
};

// 获取状态文本
const getStatusText = (status) => {
  const statusMap = {
    PENDING: "待执行",
    PAID: "已支付",
    FAILED: "支付失败",
  };
  return statusMap[status] || status;
};

// 判断是否可以执行付款
const canExecute = (payment) => {
  return payment.status === "PENDING";
};

// 获取付款申请列表
const fetchPayments = async () => {
  loading.value = true;
  try {
    const data = await paymentApi.getPaymentsByStatus(searchForm.status);
    payments.value = Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("获取付款申请列表失败:", error);
    ElMessage.error(
      error.message || "获取付款申请列表失败，请检查后端服务是否启动"
    );
    payments.value = [];
  } finally {
    loading.value = false;
  }
};

// 获取供应商列表
const fetchVendors = async () => {
  try {
    const data = await vendorApi.getAllVendors();
    vendors.value = Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("获取供应商列表失败:", error);
    vendors.value = [];
  }
};

// 获取银行账户列表（资产类科目）
const fetchBankAccounts = async () => {
  try {
    const data = await accountApi.getAllAccounts();
    // 筛选资产类科目（通常代码以1开头）
    bankAccounts.value = Array.isArray(data)
      ? data.filter((a) => a.code?.startsWith("1") || a.type === "ASSET")
      : [];
  } catch (error) {
    console.error("获取银行账户列表失败:", error);
    bankAccounts.value = [];
  }
};

// 状态变化
const handleStatusChange = () => {
  fetchPayments();
};

// 搜索
const handleSearch = () => {
  fetchPayments();
};

// 重置搜索
const handleReset = () => {
  searchForm.status = "PENDING";
  fetchPayments();
};

// 新增
const handleAdd = () => {
  resetForm();
  dialogVisible.value = true;
};

// 查看详情
const handleView = async (row) => {
  try {
    const data = await paymentApi.getPaymentById(row.id);
    viewingPayment.value = data;
    viewDialogVisible.value = true;
  } catch (error) {
    console.error("获取付款申请详情失败:", error);
    ElMessage.error(error.message || "获取付款申请详情失败");
  }
};

// 执行付款
const handleExecute = (row) => {
  currentExecutePayment.value = row;
  executeForm.bankReceiptId = "";
  executeDialogVisible.value = true;
};

// 确认执行付款
const confirmExecute = async () => {
  if (!currentExecutePayment.value) return;

  try {
    executing.value = true;
    executingPaymentId.value = currentExecutePayment.value.id;

    await paymentApi.executePayment(currentExecutePayment.value.id, {
      success: true,
      bankReceiptId: executeForm.bankReceiptId || null,
      bankReceiptRaw: null,
    });

    ElMessage.success("付款执行成功！已自动生成付款凭证");
    executeDialogVisible.value = false;
    await fetchPayments();
  } catch (error) {
    console.error("执行付款失败:", error);
    ElMessage.error(error.message || "执行付款失败");
  } finally {
    executing.value = false;
    executingPaymentId.value = null;
  }
};

// 提交表单
const handleSubmit = async () => {
  if (!formRef.value) return;

  try {
    await formRef.value.validate();
    submitting.value = true;

    const submitData = {
      vendorId: formData.vendorId,
      bankAccountId: formData.bankAccountId,
      amount: formData.amount,
      requestDate: formData.requestDate || null,
    };

    await paymentApi.createPaymentRequest(submitData);
    ElMessage.success("新增付款申请成功");
    dialogVisible.value = false;
    await fetchPayments();
  } catch (error) {
    if (error !== false) {
      console.error("提交失败:", error);
      ElMessage.error(error.message || "提交失败");
    }
  } finally {
    submitting.value = false;
  }
};

// 重置表单
const resetForm = () => {
  Object.assign(formData, {
    vendorId: null,
    bankAccountId: null,
    amount: 0,
    requestDate: "",
  });
  formRef.value?.clearValidate();
};

// 组件挂载时获取数据
onMounted(() => {
  loadRoles();
  fetchPayments();
  fetchVendors();
  fetchBankAccounts();
});
</script>

<style scoped>
.payment-management {
  width: 100%;
}

.main-card {
  border-radius: 12px;
}

.search-card {
  background: #f8f9fa;
  border: 1px solid #e9ecef;
}

.page-header {
  margin-bottom: 24px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 32px;
}

.page-subtitle {
  margin: 8px 0 0 44px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.amount-text {
  font-weight: 500;
  font-family: "Courier New", monospace;
}

.amount-text.large {
  font-size: 18px;
  font-weight: 700;
}

.text-success {
  color: #67c23a;
  font-weight: 500;
}

.text-muted {
  color: #909399;
  font-style: italic;
}
</style>
