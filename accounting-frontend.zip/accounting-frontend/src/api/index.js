import axios from "axios";

// 創建 axios 實例，配置基礎 URL
const api = axios.create({
  baseURL: "/accounting",
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
});

// 請求攔截器
api.interceptors.request.use(
  (config) => {
    // 添加 JWT Token
    const token = localStorage.getItem("auth_token");
    if (token) {
      config.headers = config.headers || {};
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 響應攔截器
api.interceptors.response.use(
  (response) => {
    return response.data;
  },
  (error) => {
    // 統一錯誤處理
    if (error.response) {
      // 服務器返回了錯誤響應
      console.error("API 錯誤:", error.response.status, error.response.data);
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        `服務器錯誤 (${error.response.status})`;
      return Promise.reject({
        message: errorMessage,
        status: error.response.status,
        data: error.response.data,
      });
    } else if (error.request) {
      // 請求已發送但沒有收到響應
      console.error("請求失敗 - 無法連接到服務器:", error.request);
      console.error("請檢查:");
      console.error("1. 後端服務是否在 http://localhost:8071 運行");
      console.error("2. 後端服務是否已啟動");
      console.error("3. 防火牆是否阻止了連接");
      return Promise.reject({
        message:
          "無法連接到後端服務。請確認後端服務已在 http://localhost:8071 啟動",
        code: "NETWORK_ERROR",
      });
    } else {
      // 請求配置錯誤
      console.error("請求配置錯誤:", error.message);
      return Promise.reject({
        message: `請求錯誤: ${error.message}`,
        code: "REQUEST_ERROR",
      });
    }
  }
);

// API 方法
export const accountApi = {
  // 獲取所有科目
  getAllAccounts: () => api.get("/api/accounts"),

  // 根據 ID 獲取科目
  getAccountById: (id) => api.get(`/api/accounts/${id}`),

  // 創建科目
  createAccount: (data) => api.post("/api/accounts", data),

  // 更新科目
  updateAccount: (id, data) => api.put(`/api/accounts/${id}`, data),

  // 刪除科目
  deleteAccount: (id) => api.delete(`/api/accounts/${id}`),
};

export const vendorApi = {
  // 獲取所有供應商
  getAllVendors: () => api.get("/api/vendors"),

  // 根據 ID 獲取供應商
  getVendorById: (id) => api.get(`/api/vendors/${id}`),

  // 創建供應商
  createVendor: (data) => api.post("/api/vendors", data),

  // 更新供應商
  updateVendor: (id, data) => api.put(`/api/vendors/${id}`, data),

  // 刪除供應商
  deleteVendor: (id) => api.delete(`/api/vendors/${id}`),
};

export const customerApi = {
  // 獲取所有客戶
  getAllCustomers: () => api.get("/api/customers"),

  // 根據 ID 獲取客戶
  getCustomerById: (id) => api.get(`/api/customers/${id}`),

  // 創建客戶
  createCustomer: (data) => api.post("/api/customers", data),

  // 更新客戶
  updateCustomer: (id, data) => api.put(`/api/customers/${id}`, data),

  // 刪除客戶
  deleteCustomer: (id) => api.delete(`/api/customers/${id}`),
};

export const salesOrderApi = {
  // 獲取所有銷售訂單
  getAllSalesOrders: () => api.get("/api/sales-orders"),

  // 根據 ID 獲取銷售訂單
  getSalesOrderById: (id) => api.get(`/api/sales-orders/${id}`),

  // 創建銷售訂單
  createSalesOrder: (data) => api.post("/api/sales-orders", data),

  // 發貨並開票
  shipAndInvoiceOrder: (id) =>
    api.post(`/api/sales-orders/${id}/ship-and-invoice`),
};

export const transactionApi = {
  // 獲取所有憑證
  getAllTransactions: () => api.get("/api/transactions"),

  // 根據 ID 獲取憑證
  getTransactionById: (id) => api.get(`/api/transactions/${id}`),

  // 創建憑證
  createTransaction: (data) => api.post("/api/transactions", data),

  // 審核憑證
  auditTransaction: (id, auditorId) =>
    api.post(`/api/transactions/${id}/audit`, { auditorId }),

  // 取消憑證
  cancelTransaction: (id) => api.post(`/api/transactions/${id}/cancel`),
};

export const postingApi = {
  // 批量過賬
  batchPostTransactions: () => api.post("/api/postings/batch"),
};

export const reportApi = {
  // 生成財務報表
  generateReport: (data) => api.post("/api/reports/generate", data),
};

export const paymentApi = {
  // 獲取付款申請列表（按狀態）
  getPaymentsByStatus: (status) => {
    const params = status ? { status } : {};
    return api.get("/api/payments", { params });
  },

  // 根據 ID 獲取付款申請
  getPaymentById: (id) => api.get(`/api/payments/${id}`),

  // 創建付款申請
  createPaymentRequest: (data) => api.post("/api/payments", data),

  // 執行付款
  executePayment: (id, data) => api.post(`/api/payments/${id}/execute`, data),
};

export const purchaseOrderApi = {
  // 獲取所有採購訂單
  getAllPurchaseOrders: () => api.get("/api/purchase-orders"),

  // 根據 ID 獲取採購訂單
  getPurchaseOrderById: (id) => api.get(`/api/purchase-orders/${id}`),

  // 創建採購訂單
  createPurchaseOrder: (data) => api.post("/api/purchase-orders", data),

  // 收貨
  receiveOrder: (id, data) =>
    api.post(`/api/purchase-orders/${id}/receive`, data),
};

export const taxApi = {
  // 計算並申報稅務
  calculateAndFile: (data) => api.post("/api/taxes/calculate-and-file", data),
};

export const reconciliationApi = {
  // 自動銀行對賬
  autoReconcile: (data) =>
    api.post("/api/reconciliations/auto-reconcile", data),
};

export const valuationApi = {
  // 外幣估值
  performValuation: (data) => api.post("/api/valuations", data),
};

export const authApi = {
  // 登入取得 JWT
  login: (data) => api.post("/api/auth/login", data),
};

export const userApi = {
  // 獲取所有使用者
  getAllUsers: () => api.get("/api/users"),
  // 根據 ID 獲取使用者
  getUserById: (id) => api.get(`/api/users/${id}`),
  // 建立使用者
  createUser: (data) => api.post("/api/users", data),
  // 更新使用者
  updateUser: (id, data) => api.put(`/api/users/${id}`, data),
  // 刪除使用者
  deleteUser: (id) => api.delete(`/api/users/${id}`),
  // 獲取所有角色
  getAllRoles: () => api.get("/api/users/roles"),
};

export default api;
