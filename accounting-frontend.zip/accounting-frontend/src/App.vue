<script setup>
import { ref, defineAsyncComponent, computed, onMounted } from "vue";
import { ElMessage } from 'element-plus';
import { Menu as IconMenu, Document, Tools, User, UserFilled, ShoppingBag, ShoppingCart, Edit, DataAnalysis, CreditCard, Money, Link, TrendCharts, SwitchButton } from "@element-plus/icons-vue";

// --- 异步组件定义 ---
const Dashboard = defineAsyncComponent(() => import("./components/Dashboard.vue"));
const AccountManagement = defineAsyncComponent(() => import("./components/AccountManagement.vue"));
const VendorManagement = defineAsyncComponent(() => import("./components/VendorManagement.vue"));
const CustomerManagement = defineAsyncComponent(() => import("./components/CustomerManagement.vue"));
const SalesOrderManagement = defineAsyncComponent(() => import("./components/SalesOrderManagement.vue"));
const PurchaseOrderManagement = defineAsyncComponent(() => import("./components/PurchaseOrderManagement.vue"));
const TransactionManagement = defineAsyncComponent(() => import("./components/TransactionManagement.vue"));
const FinancialReportManagement = defineAsyncComponent(() => import("./components/FinancialReportManagement.vue"));
const PaymentManagement = defineAsyncComponent(() => import("./components/PaymentManagement.vue"));
const TaxManagement = defineAsyncComponent(() => import("./components/TaxManagement.vue"));
const BankReconciliationManagement = defineAsyncComponent(() => import("./components/BankReconciliationManagement.vue"));
const ValuationManagement = defineAsyncComponent(() => import("./components/ValuationManagement.vue"));
const ApiTest = defineAsyncComponent(() => import("./components/ApiTest.vue"));
const UserManagement = defineAsyncComponent(() => import("./components/UserManagement.vue"));
const Login = defineAsyncComponent(() => import("./components/Login.vue"));

// --- 状态管理 ---
const activeTab = ref("login");
const isLoggedIn = ref(false);
const username = ref('');
const userRoles = ref([]);

// --- 导航与角色定义 ---
const allTabs = [
  { label: "系统概览", value: "dashboard", icon: DataAnalysis, roles: ['ADMIN', 'ACCOUNTANT', 'AUDITOR', 'CASHIER', 'VIEWER'] },
  { label: "科目管理", value: "accounts", icon: Document, roles: ['ADMIN', 'ACCOUNTANT'] },
  { label: "供應商管理", value: "vendors", icon: User, roles: ['ADMIN', 'ACCOUNTANT'] },
  { label: "客戶管理", value: "customers", icon: UserFilled, roles: ['ADMIN', 'ACCOUNTANT'] },
  { label: "銷售訂單", value: "sales-orders", icon: ShoppingBag, roles: ['ADMIN', 'ACCOUNTANT', 'AUDITOR'] },
  { label: "採購訂單", value: "purchase-orders", icon: ShoppingCart, roles: ['ADMIN', 'ACCOUNTANT'] },
  { label: "憑證管理", value: "transactions", icon: Edit, roles: ['ADMIN', 'ACCOUNTANT', 'AUDITOR'] },
  { label: "財務報表", value: "reports", icon: DataAnalysis, roles: ['ADMIN', 'AUDITOR', 'VIEWER'] },
  { label: "付款管理", value: "payments", icon: CreditCard, roles: ['ADMIN', 'CASHIER', 'ACCOUNTANT'] },
  { label: "稅務管理", value: "taxes", icon: Money, roles: ['ADMIN', 'ACCOUNTANT'] },
  { label: "銀行對賬", value: "reconciliation", icon: Link, roles: ['ADMIN', 'ACCOUNTANT'] },
  { label: "外幣估值", value: "valuation", icon: TrendCharts, roles: ['ADMIN', 'ACCOUNTANT'] },
  { label: "API 測試", value: "test", icon: Tools, roles: ['ADMIN'] },
  { label: "使用者管理", value: "users", icon: User, roles: ['ADMIN'] },
  { label: "登入", value: "login", icon: User, public: true }, // 公开页面
];

// --- 权限逻辑 ---
const updateAuthState = () => {
  const token = localStorage.getItem('auth_token');
  isLoggedIn.value = !!token;
  if (token) {
    username.value = localStorage.getItem('auth_user') || '';
    try {
      userRoles.value = JSON.parse(localStorage.getItem('auth_roles') || '[]');
    } catch (e) {
      userRoles.value = [];
    }
    if (activeTab.value === 'login') {
      activeTab.value = 'dashboard';
    }
  } else {
    username.value = '';
    userRoles.value = [];
    activeTab.value = 'login';
  }
};

const visibleTabs = computed(() => {
  if (!isLoggedIn.value) {
    return allTabs.filter(t => t.public);
  }
  return allTabs.filter(tab => {
    if (tab.public) return false; // 登入后不显示公开页面
    if (!tab.roles) return true; // 没有角色限制的页面默认显示
    return tab.roles.some(role => userRoles.value.includes(role));
  });
});

const handleLogout = () => {
  localStorage.removeItem('auth_token');
  localStorage.removeItem('auth_user');
  localStorage.removeItem('auth_roles');
  ElMessage.success('已成功登出');
  updateAuthState();
};

// --- 生命周期与事件监听 ---
onMounted(() => {
  updateAuthState();
  window.addEventListener('auth-change', updateAuthState);
});

// 监听来自子组件的导航事件
window.addEventListener("navigate-tab", (event) => {
  if (event.detail && event.detail.tab) {
    activeTab.value = event.detail.tab;
  }
});
</script>

<template>
  <div id="app">
    <el-container>
      <el-header class="app-header">
        <div class="header-content">
          <div class="logo-section">
            <el-icon class="logo-icon"><IconMenu /></el-icon>
            <h1 class="app-title">會計管理系統</h1>
          </div>

          <!-- 动态菜单 -->
          <el-menu
            v-if="isLoggedIn"
            mode="horizontal"
            :default-active="activeTab"
            @select="activeTab = $event"
            class="nav-menu"
          >
            <el-menu-item
              v-for="tab in visibleTabs"
              :key="tab.value"
              :index="tab.value"
              class="nav-item"
            >
              <el-icon><component :is="tab.icon" /></el-icon>
              <span>{{ tab.label }}</span>
            </el-menu-item>
          </el-menu>

          <!-- 用户信息与登出 -->
          <div class="user-section">
            <div v-if="isLoggedIn" class="user-info">
              <el-icon><User /></el-icon>
              <span>{{ username }}</span>
              <el-tag v-for="role in userRoles" :key="role" size="small" type="info" style="margin-left: 6px">{{ role }}</el-tag>
              <el-button @click="handleLogout" type="danger" :icon="SwitchButton" circle style="margin-left: 12px" />
            </div>
            <el-button v-else @click="activeTab='login'" type="primary">前往登入</el-button>
          </div>
        </div>
      </el-header>

      <el-main class="app-main">
        <!-- 登录页面 -->
        <Login v-if="activeTab === 'login'" />

        <!-- 功能页面 (登录后可见) -->
        <template v-if="isLoggedIn">
          <Dashboard v-if="activeTab === 'dashboard'" />
          <AccountManagement v-if="activeTab === 'accounts'" />
          <VendorManagement v-if="activeTab === 'vendors'" />
          <CustomerManagement v-if="activeTab === 'customers'" />
          <SalesOrderManagement v-if="activeTab === 'sales-orders'" />
          <PurchaseOrderManagement v-if="activeTab === 'purchase-orders'" />
          <TransactionManagement v-if="activeTab === 'transactions'" />
          <FinancialReportManagement v-if="activeTab === 'reports'" />
          <PaymentManagement v-if="activeTab === 'payments'" />
          <TaxManagement v-if="activeTab === 'taxes'" />
          <BankReconciliationManagement v-if="activeTab === 'reconciliation'" />
          <ValuationManagement v-if="activeTab === 'valuation'" />
          <ApiTest v-if="activeTab === 'test'" />
          <UserManagement v-if="activeTab === 'users'" />
        </template>
        <el-empty v-else-if="activeTab !== 'login'" description="请先登入以访问此页面" />
      </el-main>
    </el-container>
  </div>
</template>

<style>
.user-section {
  display: flex;
  align-items: center;
  margin-left: auto;
  padding-left: 20px;
  flex-shrink: 0;
}

.user-info {
  display: flex;
  align-items: center;
  color: #fff;
  gap: 8px;
}
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    "Helvetica Neue", Arial, sans-serif;
}

#app {
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}

.app-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  padding: 0;
  height: 64px !important;
}

.header-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  height: 100%;
  width: 100%;
  margin: 0;
  overflow-x: auto;
  overflow-y: hidden;
}

.logo-section {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
  margin-right: 20px;
}

.logo-icon {
  font-size: 28px;
  color: #fff;
}

.app-title {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
  color: #fff;
  letter-spacing: 0.5px;
  white-space: nowrap;
}

.nav-menu {
  background: transparent !important;
  border: none !important;
  flex: 1;
  overflow-x: auto;
  overflow-y: hidden;
  min-width: 0;
}

.nav-menu .el-menu-item {
  color: rgba(255, 255, 255, 0.9) !important;
  border-bottom: 2px solid transparent !important;
  padding: 0 12px !important;
  height: 64px !important;
  line-height: 64px !important;
  transition: all 0.3s ease;
  font-size: 14px !important;
  white-space: nowrap !important;
}

.nav-menu .el-menu-item:hover {
  background: rgba(255, 255, 255, 0.1) !important;
  color: #fff !important;
}

.nav-menu .el-menu-item.is-active {
  color: #ffd04b !important;
  border-bottom-color: #ffd04b !important;
  background: rgba(255, 255, 255, 0.1) !important;
}

.nav-menu .el-menu-item .el-icon {
  margin-right: 6px;
}

.app-main {
  padding: 30px;
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
}
</style>
