package com.example.accountingsystem.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordHashGenerator {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        
        System.out.println("admin123: " + encoder.encode("admin123"));
        System.out.println("accountant123: " + encoder.encode("accountant123"));
        System.out.println("auditor123: " + encoder.encode("auditor123"));
        System.out.println("cashier123: " + encoder.encode("cashier123"));
        System.out.println("viewer123: " + encoder.encode("viewer123"));
    }
}




