package com.example.accountingsystem.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CustomerDto {

    private Long id;
    private String customerName;
    private String taxId;
    private BigDecimal creditLimit;
    private BigDecimal currentBalance;
    private String settlementCurrency;
    private String status;

}



