package com.example.accountingsystem.dto;

import lombok.Data;

@Data
public class CurrencyDto {

    private String code;
    private String name;
    private boolean isBaseCurrency;

}

