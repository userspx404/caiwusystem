package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.SplitDto;
import com.example.accountingsystem.dto.TransactionDto;
import com.example.accountingsystem.entity.*;
import com.example.accountingsystem.exception.InvalidRequestException;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.AccountRepository;
import com.example.accountingsystem.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    @Autowired
    public TransactionService(TransactionRepository transactionRepository, AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    // 供內部模組（如 UC002 自動記帳）直接傳入實體使用
    @Transactional
    public Transaction createTransaction(Transaction transaction) {
        if (transaction.getSplits() == null || transaction.getSplits().size() < 2) {
            throw new InvalidRequestException("Transaction must have at least two splits.");
        }
        validateBalance(transaction);
        if (transaction.getVoucherNo() == null || transaction.getVoucherNo().isBlank()) {
            transaction.setVoucherNo(generateVoucherNo("TX"));
        }
        if (transaction.getStatus() == null) {
            transaction.setStatus(TransactionStatus.DRAFT);
        }
        // 確保所有分錄中的科目是受管理的 Entity
        for (Split split : transaction.getSplits()) {
            Long accountId = split.getAccount().getId();
            Account managed = accountRepository.findById(accountId)
                    .orElseThrow(() -> new ResourceNotFoundException("Account not found for split with accountId: " + accountId));
            split.setAccount(managed);
            split.setTransaction(transaction);
        }
        return transactionRepository.save(transaction);
    }

    @Transactional
    public TransactionDto createTransaction(TransactionDto transactionDto) {
        // UC011 業務規則：憑證必須包含至少兩個分錄
        if (transactionDto.getSplits() == null || transactionDto.getSplits().size() < 2) {
            throw new InvalidRequestException("Transaction must have at least two splits.");
        }

        // UC011 業務規則：借貸必須平衡
        validateBalance(transactionDto);

        Transaction transaction = new Transaction();
        // 憑證號：若未提供，則自動生成；若提供則使用提供的值
        String voucherNo = transactionDto.getVoucherNo();
        if (voucherNo == null || voucherNo.isBlank()) {
            voucherNo = generateVoucherNo("TX");
        }
        transaction.setVoucherNo(voucherNo);

        transaction.setDate(transactionDto.getDate());
        transaction.setDescription(transactionDto.getDescription());
        transaction.setStatus(transactionDto.getStatus() != null ? transactionDto.getStatus() : TransactionStatus.DRAFT);

        for (SplitDto splitDto : transactionDto.getSplits()) {
            Account account = accountRepository.findById(splitDto.getAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Account not found for split with accountId: " + splitDto.getAccountId()));

            Split split = new Split();
            split.setAccount(account);
            split.setAmountBase(splitDto.getAmount());
            split.setBalanceDirection(splitDto.getBalanceDirection());
            split.setDescription(splitDto.getDescription());
            transaction.addSplit(split);
        }

        Transaction savedTransaction = transactionRepository.save(transaction);
        return toDto(savedTransaction);
    }

    private String generateVoucherNo(String prefix) {
        String base = prefix + "-" + java.time.LocalDate.now().toString().replaceAll("-", "");
        String candidate = base;
        int seq = 1;
        while (transactionRepository.findByVoucherNo(candidate).isPresent()) {
            candidate = base + "-" + (seq++);
        }
        return candidate;
    }

    private void validateBalance(TransactionDto transactionDto) {
        BigDecimal total = BigDecimal.ZERO;
        for (SplitDto split : transactionDto.getSplits()) {
            BigDecimal amount = split.getAmount() == null ? BigDecimal.ZERO : split.getAmount();
            if (split.getBalanceDirection() == BalanceDirection.DEBIT) {
                total = total.add(amount);
            } else if (split.getBalanceDirection() == BalanceDirection.CREDIT) {
                total = total.subtract(amount);
            }
        }

        // 使用 compareTo 進行精確比較
        if (total.compareTo(BigDecimal.ZERO) != 0) {
            throw new InvalidRequestException("Transaction is not balanced. Debits do not equal Credits. Difference: " + total);
        }
    }

    private void validateBalance(Transaction transaction) {
        BigDecimal total = BigDecimal.ZERO;
        for (Split split : transaction.getSplits()) {
            BigDecimal amount = split.getAmountBase() == null ? BigDecimal.ZERO : split.getAmountBase();
            if (split.getBalanceDirection() == BalanceDirection.DEBIT) {
                total = total.add(amount);
            } else if (split.getBalanceDirection() == BalanceDirection.CREDIT) {
                total = total.subtract(amount);
            }
        }
        if (total.compareTo(BigDecimal.ZERO) != 0) {
            throw new InvalidRequestException("Transaction is not balanced. Debits do not equal Credits. Difference: " + total);
        }
    }

    // DTO 轉換
    @Transactional
    public TransactionDto auditTransaction(Long transactionId, Long auditorId) {
        Transaction transaction = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + transactionId));

        if (transaction.getStatus() != TransactionStatus.DRAFT) {
            throw new InvalidRequestException("Only DRAFT transactions can be audited. Current status: " + transaction.getStatus());
        }

        // In a real system, you would check if auditorId is different from creatorId
        transaction.setStatus(TransactionStatus.AUDITED);
        transaction.setAuditorId(auditorId);

        Transaction savedTransaction = transactionRepository.save(transaction);
        return toDto(savedTransaction);
    }

    @Transactional
    public TransactionDto cancelTransaction(Long transactionId) {
        Transaction transaction = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + transactionId));

        if (transaction.getStatus() == TransactionStatus.POSTED) {
            throw new InvalidRequestException("Cannot cancel a POSTED transaction.");
        }

        if (transaction.getStatus() == TransactionStatus.CANCELLED) {
            throw new InvalidRequestException("Transaction is already cancelled.");
        }

        transaction.setStatus(TransactionStatus.CANCELLED);

        Transaction savedTransaction = transactionRepository.save(transaction);
        return toDto(savedTransaction);
    }

    public int batchPostTransactions() {
        // 1. 獲取所有已審核的憑證
        List<Transaction> transactionsToPost = transactionRepository.findByStatus(TransactionStatus.AUDITED);
        if (transactionsToPost.isEmpty()) {
            return 0;
        }

        LocalDateTime postingTime = LocalDateTime.now();

        // 2. 遍歷所有憑證，更新科目餘額
        for (Transaction transaction : transactionsToPost) {
            for (Split split : transaction.getSplits()) {
                Account account = split.getAccount();
                BigDecimal splitAmount = split.getAmountBase();

                // 根據借貸方向更新餘額
                if (split.getBalanceDirection() == BalanceDirection.DEBIT) {
                    account.setCurrentBalance(account.getCurrentBalance().add(splitAmount));
                } else { // CREDIT
                    account.setCurrentBalance(account.getCurrentBalance().subtract(splitAmount));
                }
                // 注意：這裡我們先在記憶體中更新餘額，最後由 JPA 一次性儲存
            }

            // 3. 更新憑證狀態和過帳日期
            transaction.setStatus(TransactionStatus.POSTED);
            transaction.setPostingDate(postingTime);
        }

        // 4. 由於在同一個交易中，JPA 會自動儲存被修改的受管實體 (managed entities)，
        // 所以理論上不需要手動呼叫 saveAll。但為了明確起見，我們執行儲存。
        transactionRepository.saveAll(transactionsToPost);

        return transactionsToPost.size();
    }

    public TransactionDto toDto(Transaction transaction) {
        TransactionDto dto = new TransactionDto();
        dto.setId(transaction.getId());
        dto.setVoucherNo(transaction.getVoucherNo());
        dto.setDate(transaction.getDate());
        dto.setDescription(transaction.getDescription());
        dto.setStatus(transaction.getStatus());
        dto.setCreatorId(transaction.getCreatorId());
        dto.setAuditorId(transaction.getAuditorId());

        dto.setSplits(transaction.getSplits().stream().map(split -> {
            SplitDto splitDto = new SplitDto();
            splitDto.setId(split.getId());
            splitDto.setAccountId(split.getAccount().getId());
            splitDto.setAccountCode(split.getAccount().getCode());
            splitDto.setAccountName(split.getAccount().getName());
            splitDto.setAmount(split.getAmountBase());
            splitDto.setBalanceDirection(split.getBalanceDirection());
            splitDto.setDescription(split.getDescription());
            return splitDto;
        }).collect(Collectors.toList()));

        return dto;
    }

    @Transactional(readOnly = true)
    public List<TransactionDto> getAllTransactions() {
        // 使用 JOIN FETCH 立即加載 splits，避免懶加載問題
        List<Transaction> transactions = transactionRepository.findAllWithSplits();
        return transactions.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public TransactionDto getTransactionById(Long id) {
        // 使用 JOIN FETCH 立即加載 splits，避免懶加載問題
        Transaction transaction = transactionRepository.findByIdWithSplits(id)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + id));
        return toDto(transaction);
    }
}
