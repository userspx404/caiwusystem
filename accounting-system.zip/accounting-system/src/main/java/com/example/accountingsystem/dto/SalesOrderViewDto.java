package com.example.accountingsystem.dto;

import com.example.accountingsystem.entity.SalesOrderStatus;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class SalesOrderViewDto {

    private Long id;
    private Long customerId;
    private String customerName;
    private String invoiceNo;
    private LocalDate invoiceDate;
    private BigDecimal totalAmount;
    private Long autoTransactionId;
    private SalesOrderStatus status;

}



