package com.example.accountingsystem.dto;

import lombok.Data;

@Data
public class PaymentExecuteDto {
    private boolean success;          // 模擬銀企直連結果
    private String bankReceiptId;     // 銀行回執編號
    private String bankReceiptRaw;    // 銀行回執原文（JSON/XML）
}

