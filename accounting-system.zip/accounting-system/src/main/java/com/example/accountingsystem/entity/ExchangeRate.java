package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "exchange_rates")
@Data
public class ExchangeRate {

    @EmbeddedId
    private ExchangeRateId id;

    @Column(name = "rate_to_base", nullable = false, precision = 19, scale = 8)
    private BigDecimal rateToBase;

    // Optional: Link to the valuation transaction if this rate was used for one
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "valuation_transaction_id")
    private Transaction valuationTransaction;
}

