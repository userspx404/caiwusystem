package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.SalesOrderDto;
import com.example.accountingsystem.dto.SalesOrderViewDto;
import com.example.accountingsystem.entity.*;
import com.example.accountingsystem.exception.InvalidRequestException;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.AccountRepository;
import com.example.accountingsystem.repository.CustomerRepository;
import com.example.accountingsystem.repository.SalesOrderRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SalesOrderService {

    private final SalesOrderRepository salesOrderRepository;
    private final CustomerRepository customerRepository;
    private final AccountRepository accountRepository;
    private final TransactionService transactionService;

    // --- Constants for Account Codes ---
    private static final String ACCOUNTS_RECEIVABLE_CODE = "1122"; // 應收帳款
    private static final String MAIN_REVENUE_CODE = "4001";      // 主營業務收入

    @Autowired
    public SalesOrderService(SalesOrderRepository salesOrderRepository, CustomerRepository customerRepository, AccountRepository accountRepository, TransactionService transactionService) {
        this.salesOrderRepository = salesOrderRepository;
        this.customerRepository = customerRepository;
        this.accountRepository = accountRepository;
        this.transactionService = transactionService;
    }

    @Transactional
    public SalesOrderViewDto createSalesOrder(SalesOrderDto salesOrderDto) {
        Customer customer = customerRepository.findById(salesOrderDto.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found: " + salesOrderDto.getCustomerId()));

        SalesOrder salesOrder = new SalesOrder();
        salesOrder.setCustomer(customer);
        salesOrder.setInvoiceNo(salesOrderDto.getInvoiceNo());
        salesOrder.setInvoiceDate(salesOrderDto.getInvoiceDate());
        salesOrder.setTotalAmount(salesOrderDto.getTotalAmount());
        salesOrder.setStatus(SalesOrderStatus.DRAFT);

        SalesOrder savedOrder = salesOrderRepository.save(salesOrder);
        return convertToViewDto(savedOrder);
    }

    @Transactional(readOnly = true)
    public SalesOrderViewDto getSalesOrderById(Long id) {
        return salesOrderRepository.findById(id)
                .map(this::convertToViewDto)
                .orElseThrow(() -> new ResourceNotFoundException("SalesOrder not found with id: " + id));
    }

    @Transactional(readOnly = true)
    public List<SalesOrderViewDto> getAllSalesOrders() {
        return salesOrderRepository.findAll().stream()
                .map(this::convertToViewDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public SalesOrderViewDto shipAndInvoiceOrder(Long orderId) {
        SalesOrder order = salesOrderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("SalesOrder not found with id: " + orderId));

        if (order.getStatus() != SalesOrderStatus.CONFIRMED && order.getStatus() != SalesOrderStatus.DRAFT) {
            throw new InvalidRequestException("Order cannot be shipped/invoiced. Current status: " + order.getStatus());
        }

        Customer customer = order.getCustomer();

        // 1. 信用額度檢查 (UC010 擴充路徑 E1)
        BigDecimal newBalance = customer.getCurrentBalance().add(order.getTotalAmount());
        if (newBalance.compareTo(customer.getCreditLimit()) > 0) {
            throw new InvalidRequestException("Credit limit exceeded for customer: " + customer.getCustomerName());
        }

        // 2. 自動生成應收帳款憑證
        Transaction arTransaction = createArTransaction(order);
        Transaction savedTx = transactionService.createTransaction(arTransaction);

        // 3. 更新客戶餘額
        customer.setCurrentBalance(newBalance);
        customerRepository.save(customer);

        // 4. 更新銷售訂單狀態
        order.setStatus(SalesOrderStatus.INVOICED);
        order.setAutoTransaction(savedTx);
        SalesOrder updatedOrder = salesOrderRepository.save(order);

        return convertToViewDto(updatedOrder);
    }

    private Transaction createArTransaction(SalesOrder order) {
        Account arAccount = accountRepository.findByCode(ACCOUNTS_RECEIVABLE_CODE)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + ACCOUNTS_RECEIVABLE_CODE));
        Account revenueAccount = accountRepository.findByCode(MAIN_REVENUE_CODE)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + MAIN_REVENUE_CODE));

        Transaction transaction = new Transaction();
        transaction.setDate(order.getInvoiceDate() != null ? order.getInvoiceDate() : LocalDate.now());
        transaction.setDescription("Sales to " + order.getCustomer().getCustomerName() + " (SO#" + order.getId() + ")");
        transaction.setStatus(TransactionStatus.AUDITED); // 自動審核

        // 借：應收帳款  貸：主營業務收入
        Split dr = new Split();
        dr.setAccount(arAccount);
        dr.setAmountBase(order.getTotalAmount());
        dr.setBalanceDirection(BalanceDirection.DEBIT);

        Split cr = new Split();
        cr.setAccount(revenueAccount);
        cr.setAmountBase(order.getTotalAmount());
        cr.setBalanceDirection(BalanceDirection.CREDIT);

        transaction.addSplit(dr);
        transaction.addSplit(cr);

        return transaction;
    }

    private SalesOrderViewDto convertToViewDto(SalesOrder order) {
        SalesOrderViewDto dto = new SalesOrderViewDto();
        BeanUtils.copyProperties(order, dto);
        if (order.getCustomer() != null) {
            dto.setCustomerId(order.getCustomer().getId());
            dto.setCustomerName(order.getCustomer().getCustomerName());
        }
        if (order.getAutoTransaction() != null) {
            dto.setAutoTransactionId(order.getAutoTransaction().getId());
        }
        return dto;
    }
}


