package com.example.accountingsystem.dto;

import lombok.Data;

@Data
public class AuditRequestDto {

    private Long auditorId;

}
