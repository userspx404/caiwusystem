package com.example.accountingsystem.service;

import com.example.accountingsystem.entity.Vendor;
import com.example.accountingsystem.exception.InvalidRequestException;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.VendorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VendorService {

    private final VendorRepository vendorRepository;

    @Autowired
    public VendorService(VendorRepository vendorRepository) {
        this.vendorRepository = vendorRepository;
    }

    /**
     * Creates a new vendor.
     * It checks if the Tax ID is unique as per UC001.
     * @param vendor The vendor to create.
     * @return The saved vendor.
     * @throws InvalidRequestException if the tax ID already exists.
     */
    public Vendor createVendor(Vendor vendor) {
        vendorRepository.findByTaxId(vendor.getTaxId()).ifPresent(v -> {
            throw new InvalidRequestException("Tax ID '" + vendor.getTaxId() + "' already exists.");
        });
        // As per UC001, the status of a new vendor is '有效'
        vendor.setStatus("有效");
        return vendorRepository.save(vendor);
    }

    /**
     * Retrieves a vendor by its ID.
     * @param id The ID of the vendor.
     * @return The found vendor.
     * @throws ResourceNotFoundException if vendor is not found.
     */
    public Vendor getVendorById(Long id) {
        return vendorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vendor not found with id: " + id));
    }

    /**
     * Retrieves all vendors.
     * @return A list of all vendors.
     */
    public List<Vendor> getAllVendors() {
        return vendorRepository.findAll();
    }

    /**
     * Updates an existing vendor's information.
     * @param id The ID of the vendor to update.
     * @param vendorDetails The new details for the vendor.
     * @return The updated vendor.
     * @throws ResourceNotFoundException if vendor is not found.
     * @throws InvalidRequestException if the new tax ID is already taken by another vendor.
     */
    public Vendor updateVendor(Long id, Vendor vendorDetails) {
        Vendor existingVendor = getVendorById(id);

        // Check if taxId is being changed and if the new one is already in use
        if (!existingVendor.getTaxId().equals(vendorDetails.getTaxId())) {
            Optional<Vendor> vendorWithNewTaxId = vendorRepository.findByTaxId(vendorDetails.getTaxId());
            if (vendorWithNewTaxId.isPresent() && !vendorWithNewTaxId.get().getId().equals(id)) {
                throw new InvalidRequestException("Tax ID '" + vendorDetails.getTaxId() + "' is already in use by another vendor.");
            }
        }

        existingVendor.setVendorName(vendorDetails.getVendorName());
        existingVendor.setTaxId(vendorDetails.getTaxId());
        existingVendor.setContactPerson(vendorDetails.getContactPerson());
        existingVendor.setBankAcctNo(vendorDetails.getBankAcctNo());
        existingVendor.setSettlementCurrency(vendorDetails.getSettlementCurrency());
        existingVendor.setStatus(vendorDetails.getStatus());

        return vendorRepository.save(existingVendor);
    }

    /**
     * Deletes a vendor by its ID.
     * Note: In a real-world scenario, we might prefer to deactivate the vendor (soft delete)
     * if it's linked to transactions, as per design constraints.
     * @param id The ID of the vendor to delete.
     */
    public void deleteVendor(Long id) {
        if (!vendorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Vendor not found with id: " + id);
        }
        vendorRepository.deleteById(id);
    }
}

