package com.example.accountingsystem.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class SalesOrderDto {

    private Long customerId;
    private String invoiceNo;
    private LocalDate invoiceDate;
    private BigDecimal totalAmount;

}



