package com.example.accountingsystem.entity;

public enum TransactionStatus {
    DRAFT,      // 草稿
    AUDITED,    // 已審核
    POSTED,     // 已過帳
    CANCELLED   // 已作廢
}

