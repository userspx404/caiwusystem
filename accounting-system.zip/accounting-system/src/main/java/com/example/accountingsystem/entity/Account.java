package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "accounts")
@Data
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "account_id")
    private Long id;

    @Column(unique = true, nullable = false, length = 50)
    private String code;

    @Column(nullable = false, length = 100)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AccountType type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private Account parent;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Account> children = new ArrayList<>();

    @Enumerated(EnumType.STRING)
    @Column(name = "balance_direction", nullable = false, length = 10)
    private BalanceDirection balanceDirection;

    // 輔助核算管理，暫存為字串，未來可擴充為 JSON
    @Column(name = "auxiliary_management", length = 255)
    private String auxiliaryManagement;

    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;

    // 科目計價貨幣，例如 USD, EUR。若為 NULL 表示為本位幣
    @Column(name = "currency", length = 10)
    private String currency;

    // 該科目的目前餘額
    @Column(name = "current_balance", nullable = false, precision = 19, scale = 4)
    private java.math.BigDecimal currentBalance = java.math.BigDecimal.ZERO;
}

