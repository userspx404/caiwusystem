package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.PaymentRequestDto;
import com.example.accountingsystem.dto.TaxCalculationRequestDto;
import com.example.accountingsystem.dto.TaxFilingDto;
import com.example.accountingsystem.entity.*;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.AccountRepository;
import com.example.accountingsystem.repository.SplitRepository;
import com.example.accountingsystem.repository.TaxFilingRepository;
import com.example.accountingsystem.repository.VendorRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class TaxService {

    private final TaxFilingRepository taxFilingRepository;
    private final AccountRepository accountRepository;
    private final SplitRepository splitRepository;
    private final VendorRepository vendorRepository;
    private final TransactionService transactionService;
    private final PaymentService paymentService;

    // --- Constants for Account and Vendor Codes ---
    private static final String INCOME_TAX_EXPENSE_CODE = "6301"; // 所得稅費用
    private static final String TAXES_PAYABLE_CODE = "2221";      // 應交稅費
    private static final String TAX_AUTHORITY_VENDOR_TIN = "TAX-GOV-001"; // 稅務機關的稅號

    @Autowired
    public TaxService(TaxFilingRepository taxFilingRepository, AccountRepository accountRepository, SplitRepository splitRepository, VendorRepository vendorRepository, TransactionService transactionService, PaymentService paymentService) {
        this.taxFilingRepository = taxFilingRepository;
        this.accountRepository = accountRepository;
        this.splitRepository = splitRepository;
        this.vendorRepository = vendorRepository;
        this.transactionService = transactionService;
        this.paymentService = paymentService;
    }

    @Transactional
    public TaxFilingDto calculateAndCreateTaxFiling(TaxCalculationRequestDto request) {
        // 1. 計算稅前利潤 (收入為貸方，費用為借方，所以收入取負值)
        BigDecimal totalIncome = splitRepository.sumAmountByAccountTypeInDateRange(List.of(AccountType.INCOME), request.getStartDate(), request.getEndDate()).negate();
        BigDecimal totalExpense = splitRepository.sumAmountByAccountTypeInDateRange(List.of(AccountType.EXPENSE), request.getStartDate(), request.getEndDate());
        BigDecimal profitBeforeTax = totalIncome.subtract(totalExpense);

        // 2. 計算應納稅額
        BigDecimal payableAmount = profitBeforeTax.multiply(request.getTaxRate()).setScale(2, RoundingMode.HALF_UP);

        if (payableAmount.compareTo(BigDecimal.ZERO) <= 0) {
            // 如果沒有應納稅額，則不進行後續操作
            return null;
        }

        // 3. 建立稅務調整憑證 (借：所得稅費用，貸：應交稅費)
        Account taxExpenseAccount = accountRepository.findByCode(INCOME_TAX_EXPENSE_CODE)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + INCOME_TAX_EXPENSE_CODE));
        Account taxesPayableAccount = accountRepository.findByCode(TAXES_PAYABLE_CODE)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + TAXES_PAYABLE_CODE));

        Transaction taxTransaction = new Transaction();
        taxTransaction.setDate(request.getEndDate());
        taxTransaction.setDescription(request.getFilingPeriod() + " " + request.getTaxType());
        taxTransaction.setStatus(TransactionStatus.AUDITED); // 自動審核

        Split dr = new Split();
        dr.setAccount(taxExpenseAccount);
        dr.setAmountBase(payableAmount);
        dr.setBalanceDirection(BalanceDirection.DEBIT);

        Split cr = new Split();
        cr.setAccount(taxesPayableAccount);
        cr.setAmountBase(payableAmount);
        cr.setBalanceDirection(BalanceDirection.CREDIT);

        taxTransaction.addSplit(dr);
        taxTransaction.addSplit(cr);
        transactionService.createTransaction(taxTransaction);

        // 4. 建立稅務申報記錄
        TaxFiling taxFiling = new TaxFiling();
        taxFiling.setFilingPeriod(request.getFilingPeriod());
        taxFiling.setTaxType(request.getTaxType());
        taxFiling.setPayableAmount(payableAmount);
        taxFiling.setFilingStatus(FilingStatus.DRAFT);

        // 5. 自動產生指向稅務機關的待付款項
        Vendor taxAuthority = vendorRepository.findByTaxId(TAX_AUTHORITY_VENDOR_TIN)
                .orElseThrow(() -> new ResourceNotFoundException("Tax Authority vendor not found: " + TAX_AUTHORITY_VENDOR_TIN));
        
        PaymentRequestDto prDto = new PaymentRequestDto();
        prDto.setVendorId(taxAuthority.getId());
        // 注意：這裡的 bankAccountId 應由前端或更高層邏輯決定，此處暫時留空或設為預設
        // 在實際應用中，可能需要一個配置來指定預設的納稅帳戶
        // prDto.setBankAccountId(...);
        prDto.setAmount(payableAmount);
        prDto.setRequestDate(request.getEndDate().plusDays(1));
        
        // 這裡我們假設 paymentService.createRequest 返回的 DTO 包含新建立的實體 ID
        // 但為了關聯，我們需要 PaymentRequest 實體
        prDto.setBankAccountId(request.getBankAccountId()); // 使用請求中指定的銀行帳戶ID

        PaymentRequest newPaymentRequest = paymentService.createRequestAndReturnEntity(prDto);
        taxFiling.setPaymentRequest(newPaymentRequest);

        TaxFiling savedTaxFiling = taxFilingRepository.save(taxFiling);

        return convertToDto(savedTaxFiling);
    }

    private TaxFilingDto convertToDto(TaxFiling taxFiling) {
        TaxFilingDto dto = new TaxFilingDto();
        BeanUtils.copyProperties(taxFiling, dto);
        if (taxFiling.getPaymentRequest() != null) {
            dto.setPaymentRequestId(taxFiling.getPaymentRequest().getId());
        }
        return dto;
    }
}

