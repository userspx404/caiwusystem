package com.example.accountingsystem.dto;

import com.example.accountingsystem.entity.ReportType;
import lombok.Data;

import java.time.LocalDate;

@Data
public class ReportRequestDto {

    private ReportType reportType;
    private LocalDate reportDate;

}
