package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.FinancialReportDto;
import com.example.accountingsystem.dto.ReportRequestDto;
import com.example.accountingsystem.service.FinancialReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/reports")
public class FinancialReportController {

    private final FinancialReportService financialReportService;

    @Autowired
    public FinancialReportController(FinancialReportService financialReportService) {
        this.financialReportService = financialReportService;
    }

    /**
     * Generates a financial report based on the given type and date.
     * @param requestDto DTO containing the report type and date.
     * @return The generated financial report.
     */
    @PostMapping("/generate")
    public ResponseEntity<FinancialReportDto> generateReport(@RequestBody ReportRequestDto requestDto) {
        FinancialReportDto report = financialReportService.generateReport(requestDto.getReportType(), requestDto.getReportDate());
        return ResponseEntity.ok(report);
    }
}
