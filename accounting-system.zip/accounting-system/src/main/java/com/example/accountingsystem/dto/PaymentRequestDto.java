package com.example.accountingsystem.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PaymentRequestDto {
    private Long vendorId;
    private Long bankAccountId; // 支付所用銀行科目ID（資產科目）
    private BigDecimal amount;
    private LocalDate requestDate; // 可選，未提供則用今天
}

