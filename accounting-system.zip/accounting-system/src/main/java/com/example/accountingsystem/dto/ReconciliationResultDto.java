package com.example.accountingsystem.dto;

import lombok.Data;

import java.util.List;

@Data
public class ReconciliationResultDto {

    private int totalStatementsProcessed;
    private int matchedCount;
    private List<Long> matchedStatementIds;
    private List<Long> matchedSplitIds;

}

