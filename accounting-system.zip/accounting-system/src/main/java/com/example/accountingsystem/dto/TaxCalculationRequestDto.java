package com.example.accountingsystem.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class TaxCalculationRequestDto {

    private String filingPeriod; // e.g., "2025-Q4"
    private String taxType;      // e.g., "Corporate Income Tax"
    private LocalDate startDate;
    private LocalDate endDate;
    private BigDecimal taxRate;    // e.g., 0.25 for 25%

    private Long bankAccountId;  // 用於支付稅款的銀行科目ID

}

