package com.example.accountingsystem.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ReconciliationRequestDto {

    private Long accountId;
    private BigDecimal tolerance;

}

