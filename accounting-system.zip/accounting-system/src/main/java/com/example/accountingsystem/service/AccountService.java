package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.AccountDto;
import com.example.accountingsystem.entity.Account;
import com.example.accountingsystem.exception.InvalidRequestException;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.AccountRepository;
import com.example.accountingsystem.repository.SplitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountService {

    private final AccountRepository accountRepository;
    private final SplitRepository splitRepository;

    @Autowired
    public AccountService(AccountRepository accountRepository, SplitRepository splitRepository) {
        this.accountRepository = accountRepository;
        this.splitRepository = splitRepository;
    }

    // 這是一個輔助方法，用於將 Entity 轉換為 DTO
    private AccountDto toDto(Account account) {
        AccountDto dto = new AccountDto();
        dto.setId(account.getId());
        dto.setCode(account.getCode());
        dto.setName(account.getName());
        dto.setType(account.getType());
        dto.setBalanceDirection(account.getBalanceDirection());
        dto.setActive(account.isActive());
        dto.setAuxiliaryManagement(account.getAuxiliaryManagement());

        if (account.getParent() != null) {
            dto.setParentId(account.getParent().getId());
            dto.setParentCode(account.getParent().getCode());
            dto.setParentName(account.getParent().getName());
        }

        return dto;
    }

    // 查詢所有帳戶
    public List<AccountDto> getAllAccounts() {
        return accountRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public AccountDto getAccountById(Long id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + id));
        return toDto(account);
    }

    public AccountDto getAccountByCode(String code) {
        Account account = accountRepository.findByCode(code)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found with code: " + code));
        return toDto(account);
    }

    public AccountDto createAccount(AccountDto accountDto) {
        // UC003 業務規則：科目編碼必須唯一
        accountRepository.findByCode(accountDto.getCode()).ifPresent(a -> {
            throw new InvalidRequestException("Account code '" + accountDto.getCode() + "' already exists.");
        });

        Account account = new Account();
        account.setCode(accountDto.getCode());
        account.setName(accountDto.getName());
        account.setType(accountDto.getType());
        account.setBalanceDirection(accountDto.getBalanceDirection());
        account.setActive(accountDto.isActive());
        account.setAuxiliaryManagement(accountDto.getAuxiliaryManagement());

        // UC003 業務規則：父級科目必須已存在
        if (accountDto.getParentId() != null) {
            Account parent = accountRepository.findById(accountDto.getParentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Parent account not found with id: " + accountDto.getParentId()));
            account.setParent(parent);
        }

        Account savedAccount = accountRepository.save(account);
        return toDto(savedAccount);
    }

    public AccountDto updateAccount(Long id, AccountDto accountDto) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + id));

        // 如果要更新 code，檢查新 code 是否已被其他帳戶使用
        if (accountDto.getCode() != null && !accountDto.getCode().equals(account.getCode())) {
            accountRepository.findByCode(accountDto.getCode()).ifPresent(a -> {
                if (!a.getId().equals(id)) {
                    throw new InvalidRequestException("Account code '" + accountDto.getCode() + "' already exists.");
                }
            });
            account.setCode(accountDto.getCode());
        }

        if (accountDto.getName() != null) {
            account.setName(accountDto.getName());
        }
        if (accountDto.getType() != null) {
            account.setType(accountDto.getType());
        }
        if (accountDto.getBalanceDirection() != null) {
            account.setBalanceDirection(accountDto.getBalanceDirection());
        }
        if (accountDto.getAuxiliaryManagement() != null) {
            account.setAuxiliaryManagement(accountDto.getAuxiliaryManagement());
        }
        account.setActive(accountDto.isActive());

        Account updatedAccount = accountRepository.save(account);
        return toDto(updatedAccount);
    }

    public void deleteAccount(Long id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + id));

        // UC003 業務規則：只有沒有發生額的最低級科目才允許删除。
        // 1. 檢查是否有子科目 (不是最低級)
        if (!account.getChildren().isEmpty()) {
            throw new InvalidRequestException("Cannot delete account with code '" + account.getCode() + "' because it has child accounts.");
        }

        // 2. 檢查是否有發生額 (在 splits 表中被使用)
        if (splitRepository.existsByAccountId(id)) {
            throw new InvalidRequestException("Cannot delete account with code '" + account.getCode() + "' because it has transactions associated with it.");
        }

        accountRepository.delete(account);
    }
}

