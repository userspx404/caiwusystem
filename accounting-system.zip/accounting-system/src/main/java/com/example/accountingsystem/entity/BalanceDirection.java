package com.example.accountingsystem.entity;

public enum BalanceDirection {
    DEBIT,      // 借方
    CREDIT      // 貸方
}

