package com.example.accountingsystem.dto;

import lombok.Data;

@Data
public class VendorDto {

    private Long id;
    private String vendorName;
    private String taxId;
    private String contactPerson;
    private String bankAcctNo;
    private String settlementCurrency;
    private String status;

}

