package com.example.accountingsystem.config;

import com.example.accountingsystem.entity.Role;
import com.example.accountingsystem.entity.User;
import com.example.accountingsystem.repository.RoleRepository;
import com.example.accountingsystem.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        // 確保角色存在
        ensureRoleExists("ADMIN", 1);
        ensureRoleExists("ACCOUNTANT", 2);
        ensureRoleExists("AUDITOR", 3);
        ensureRoleExists("CASHIER", 4);
        ensureRoleExists("VIEWER", 5);

        // 確保使用者存在並更新密碼
        ensureUserExists("admin", "admin123", 1L, Set.of(1));
        ensureUserExists("accountant", "accountant123", 2L, Set.of(2));
        ensureUserExists("auditor", "auditor123", 3L, Set.of(3));
        ensureUserExists("cashier", "cashier123", 4L, Set.of(4));
        ensureUserExists("viewer", "viewer123", 5L, Set.of(5));
    }

    private void ensureRoleExists(String roleName, Integer roleId) {
        Optional<Role> role = roleRepository.findById(roleId);
        if (role.isEmpty()) {
            Role newRole = new Role();
            newRole.setId(roleId);
            newRole.setName(roleName);
            roleRepository.save(newRole);
        } else if (!roleName.equals(role.get().getName())) {
            role.get().setName(roleName);
            roleRepository.save(role.get());
        }
    }

    @Transactional
    private void ensureUserExists(String username, String password, Long userId, Set<Integer> roleIds) {
        // 根據用戶名查找用戶
        Optional<User> userOpt = userRepository.findByUsername(username);
        User user;
        
        if (userOpt.isPresent()) {
            user = userOpt.get();
            // 更新密碼（使用正確的 BCrypt 哈希）
            user.setPassword(passwordEncoder.encode(password));
            user.setEnabled(true);
        } else {
            // 創建新用戶
            user = new User();
            user.setUsername(username);
            user.setPassword(passwordEncoder.encode(password));
            user.setEnabled(true);
        }
        
        // 設置角色 - 在同一事務中重新查詢，確保 Role 是托管的
        Set<Role> roles = new HashSet<>();
        for (Integer roleId : roleIds) {
            // 在同一事務中查詢，確保返回的 Role 是托管的實體
            roleRepository.findById(roleId).ifPresent(roles::add);
        }
        user.setRoles(roles);
        
        userRepository.save(user);
    }
}

