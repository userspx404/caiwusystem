package com.example.accountingsystem.entity;

public enum FilingStatus {
    DRAFT,          // 草稿 (稅款已計算)
    FILED,          // 已申報 (已提交給稅務系統)
    PAID,           // 已繳納 (對應的付款申請已支付)
    FAILED          // 申報失敗
}



