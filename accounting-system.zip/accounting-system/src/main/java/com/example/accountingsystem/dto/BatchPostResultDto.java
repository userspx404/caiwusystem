package com.example.accountingsystem.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class BatchPostResultDto {

    private int transactionsPosted;
    private LocalDateTime postingTimestamp;
    private String message;

    public BatchPostResultDto(int transactionsPosted) {
        this.transactionsPosted = transactionsPosted;
        this.postingTimestamp = LocalDateTime.now();
        if (transactionsPosted > 0) {
            this.message = "Successfully posted " + transactionsPosted + " transactions.";
        } else {
            this.message = "No audited transactions found to post.";
        }
    }
}

