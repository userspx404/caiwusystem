package com.example.accountingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// 強制指定元件掃描的基礎套件，解決控制器無法被自動發現的問題
@SpringBootApplication(scanBasePackages = "com.example.accountingsystem")
public class AccountingSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(AccountingSystemApplication.class, args);
    }
}
