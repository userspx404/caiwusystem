package com.example.accountingsystem.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ValuationRequestDto {

    private LocalDate valuationDate;

}

