package com.example.accountingsystem.repository;

import com.example.accountingsystem.entity.BankStatement;
import com.example.accountingsystem.entity.ReconciliationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BankStatementRepository extends JpaRepository<BankStatement, Long> {

    /**
     * Finds all bank statements for a given account with a specific status.
     * @param accountId The ID of the bank account.
     * @param status The reconciliation status to filter by.
     * @return A list of matching bank statements.
     */
    List<BankStatement> findByAccountIdAndStatus(Long accountId, ReconciliationStatus status);

}

