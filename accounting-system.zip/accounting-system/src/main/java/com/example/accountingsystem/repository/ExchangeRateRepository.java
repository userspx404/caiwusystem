package com.example.accountingsystem.repository;

import com.example.accountingsystem.entity.ExchangeRate;
import com.example.accountingsystem.entity.ExchangeRateId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public interface ExchangeRateRepository extends JpaRepository<ExchangeRate, ExchangeRateId> {

    /**
     * Finds the latest exchange rate for a given currency on or before a specific date.
     * This is useful for finding the most recent applicable rate.
     * @param currencyCode The currency code.
     * @param date The date to find the rate for.
     * @return An Optional containing the most recent exchange rate.
     */
    Optional<ExchangeRate> findTopByIdCurrencyCodeAndIdRateDateLessThanEqualOrderByIdRateDateDesc(String currencyCode, LocalDate date);
}

