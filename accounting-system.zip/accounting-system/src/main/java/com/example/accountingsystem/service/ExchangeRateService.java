package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.ExchangeRateDto;
import com.example.accountingsystem.entity.ExchangeRate;
import com.example.accountingsystem.entity.ExchangeRateId;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.CurrencyRepository;
import com.example.accountingsystem.repository.ExchangeRateRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExchangeRateService {

    private final ExchangeRateRepository exchangeRateRepository;
    private final CurrencyRepository currencyRepository;

    @Autowired
    public ExchangeRateService(ExchangeRateRepository exchangeRateRepository, CurrencyRepository currencyRepository) {
        this.exchangeRateRepository = exchangeRateRepository;
        this.currencyRepository = currencyRepository;
    }

    @Transactional
    public ExchangeRateDto createOrUpdateExchangeRate(ExchangeRateDto dto) {
        currencyRepository.findById(dto.getCurrencyCode())
                .orElseThrow(() -> new ResourceNotFoundException("Currency not found with code: " + dto.getCurrencyCode()));

        ExchangeRate exchangeRate = convertToEntity(dto);
        ExchangeRate savedRate = exchangeRateRepository.save(exchangeRate);
        return convertToDto(savedRate);
    }

    @Transactional(readOnly = true)
    public List<ExchangeRateDto> getAllExchangeRates() {
        return exchangeRateRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ExchangeRateDto getExchangeRate(String currencyCode, LocalDate date) {
        ExchangeRateId id = new ExchangeRateId(currencyCode, date);
        return exchangeRateRepository.findById(id)
                .map(this::convertToDto)
                .orElseThrow(() -> new ResourceNotFoundException("Exchange rate not found for " + currencyCode + " on " + date));
    }

    @Transactional(readOnly = true)
    public ExchangeRateDto findLatestRate(String currencyCode, LocalDate date) {
        return exchangeRateRepository.findTopByIdCurrencyCodeAndIdRateDateLessThanEqualOrderByIdRateDateDesc(currencyCode, date)
                .map(this::convertToDto)
                .orElseThrow(() -> new ResourceNotFoundException("No applicable exchange rate found for " + currencyCode + " on or before " + date));
    }

    public void deleteExchangeRate(String currencyCode, LocalDate date) {
        ExchangeRateId id = new ExchangeRateId(currencyCode, date);
        if (!exchangeRateRepository.existsById(id)) {
            throw new ResourceNotFoundException("Exchange rate not found for " + currencyCode + " on " + date);
        }
        exchangeRateRepository.deleteById(id);
    }

    private ExchangeRateDto convertToDto(ExchangeRate rate) {
        ExchangeRateDto dto = new ExchangeRateDto();
        dto.setCurrencyCode(rate.getId().getCurrencyCode());
        dto.setRateDate(rate.getId().getRateDate());
        dto.setRateToBase(rate.getRateToBase());
        return dto;
    }

    private ExchangeRate convertToEntity(ExchangeRateDto dto) {
        ExchangeRate rate = new ExchangeRate();
        rate.setId(new ExchangeRateId(dto.getCurrencyCode(), dto.getRateDate()));
        rate.setRateToBase(dto.getRateToBase());
        return rate;
    }
}

