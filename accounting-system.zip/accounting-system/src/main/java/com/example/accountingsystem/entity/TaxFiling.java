package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "tax_filings")
@Data
public class TaxFiling {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tax_filing_id")
    private Long id;

    @Column(name = "filing_period", nullable = false, length = 50)
    private String filingPeriod; // e.g., "2025-Q4"

    @Column(name = "tax_type", nullable = false, length = 50)
    private String taxType; // e.g., "Corporate Income Tax"

    @Column(name = "payable_amount", nullable = false, precision = 19, scale = 4)
    private BigDecimal payableAmount;

    @Enumerated(EnumType.STRING)
    @Column(name = "filing_status", nullable = false, length = 20)
    private FilingStatus filingStatus = FilingStatus.DRAFT;

    @Lob
    @Column(name = "tax_system_receipt")
    private String taxSystemReceipt; // 稅務系統回執原文

    // 關聯到自動生成的待付款項
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payment_request_id")
    private PaymentRequest paymentRequest;
}



