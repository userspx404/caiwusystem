package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "currencies")
@Data
public class Currency {

    @Id
    @Column(name = "currency_code", length = 10)
    private String code;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(name = "is_base_currency", nullable = false)
    private boolean isBaseCurrency = false;
}

