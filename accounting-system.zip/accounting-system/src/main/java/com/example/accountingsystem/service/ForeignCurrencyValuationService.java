package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.TransactionDto;
import com.example.accountingsystem.entity.*;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.AccountRepository;
import com.example.accountingsystem.repository.SplitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class ForeignCurrencyValuationService {

    private final AccountRepository accountRepository;
    private final SplitRepository splitRepository;
    private final ExchangeRateService exchangeRateService;
    private final TransactionService transactionService;

    private static final String FX_GAIN_LOSS_ACCOUNT_CODE = "6051"; // 匯兌損益科目代碼

    @Autowired
    public ForeignCurrencyValuationService(AccountRepository accountRepository, SplitRepository splitRepository, ExchangeRateService exchangeRateService, TransactionService transactionService) {
        this.accountRepository = accountRepository;
        this.splitRepository = splitRepository;
        this.exchangeRateService = exchangeRateService;
        this.transactionService = transactionService;
    }

    /**
     * Performs foreign currency valuation for a given date.
     * It calculates unrealized gains/losses for all foreign currency asset and liability accounts
     * and creates a draft adjustment transaction.
     *
     * @param valuationDate The date for the valuation.
     * @return The created adjustment transaction.
     */
    @Transactional
    public TransactionDto performValuation(LocalDate valuationDate) {
        // 1. 找到所有需要評估的科目 (外幣計價的資產或負債科目)
        List<Account> accountsToValue = accountRepository.findByCurrencyIsNotNullAndTypeIn(List.of(AccountType.ASSET, AccountType.LIABILITY));

        // 2. 找到匯兌損益科目
        Account fxGainLossAccount = accountRepository.findByCode(FX_GAIN_LOSS_ACCOUNT_CODE)
                .orElseThrow(() -> new ResourceNotFoundException("Foreign exchange gain/loss account not found: " + FX_GAIN_LOSS_ACCOUNT_CODE));

        Transaction valuationTransaction = new Transaction();
        valuationTransaction.setDate(valuationDate);
        valuationTransaction.setDescription("Foreign Currency Valuation on " + valuationDate);
        valuationTransaction.setStatus(TransactionStatus.DRAFT); // 根據 UC004，憑證為草稿狀態

        BigDecimal totalGain = BigDecimal.ZERO;
        BigDecimal totalLoss = BigDecimal.ZERO;

        for (Account account : accountsToValue) {
            // 3. 計算每個科目的餘額
            BigDecimal foreignCurrencyBalance = splitRepository.sumForeignCurrencyAmountByAccountId(account.getId());
            if (foreignCurrencyBalance.compareTo(BigDecimal.ZERO) == 0) {
                continue; // 餘額為零，無需評估
            }

            BigDecimal currentBaseBalance = splitRepository.sumBaseAmountByAccountId(account.getId());

            // 4. 獲取最新匯率並計算新的本位幣價值
            BigDecimal latestRate = exchangeRateService.findLatestRate(account.getCurrency(), valuationDate).getRateToBase();
            BigDecimal newBaseBalance = foreignCurrencyBalance.multiply(latestRate).setScale(2, RoundingMode.HALF_UP);

            // 5. 計算差異 (未實現損益)
            BigDecimal difference = newBaseBalance.subtract(currentBaseBalance);

            if (difference.compareTo(BigDecimal.ZERO) != 0) {
                Split adjustmentSplit = new Split();
                adjustmentSplit.setAccount(account);
                adjustmentSplit.setAmountBase(difference.abs());
                
                // 確定調整分錄的借貸方向
                if (difference.compareTo(BigDecimal.ZERO) > 0) { // 產生了收益 (資產增值或負債減少)
                    adjustmentSplit.setBalanceDirection(account.getBalanceDirection()); // 與科目餘額方向相同
                    totalGain = totalGain.add(difference.abs());
                } else { // 產生了損失 (資產減值或負債增加)
                    adjustmentSplit.setBalanceDirection(account.getBalanceDirection() == BalanceDirection.DEBIT ? BalanceDirection.CREDIT : BalanceDirection.DEBIT);
                    totalLoss = totalLoss.add(difference.abs());
                }
                valuationTransaction.addSplit(adjustmentSplit);
            }
        }

        // 6. 建立匯兌損益的對應分錄
        BigDecimal netDifference = totalGain.subtract(totalLoss);
        if (netDifference.compareTo(BigDecimal.ZERO) != 0) {
            Split fxSplit = new Split();
            fxSplit.setAccount(fxGainLossAccount);
            fxSplit.setAmountBase(netDifference.abs());
            // 淨收益計入貸方，淨損失計入借方
            fxSplit.setBalanceDirection(netDifference.compareTo(BigDecimal.ZERO) > 0 ? BalanceDirection.CREDIT : BalanceDirection.DEBIT);
            valuationTransaction.addSplit(fxSplit);
        }

        // 7. 如果有產生任何損益，則儲存憑證
        if (!valuationTransaction.getSplits().isEmpty()) {
            return transactionService.toDto(transactionService.createTransaction(valuationTransaction));
        }

        return null; // 沒有任何需要調整的科目
    }
}

