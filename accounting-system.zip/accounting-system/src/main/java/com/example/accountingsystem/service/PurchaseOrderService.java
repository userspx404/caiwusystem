package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.PurchaseOrderDto;
import com.example.accountingsystem.entity.*;
import com.example.accountingsystem.exception.InvalidRequestException;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.AccountRepository;
import com.example.accountingsystem.repository.PurchaseOrderRepository;
import com.example.accountingsystem.repository.VendorRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PurchaseOrderService {

    private final PurchaseOrderRepository purchaseOrderRepository;
    private final VendorRepository vendorRepository;
    private final AccountRepository accountRepository;
    private final TransactionService transactionService;

    private static final String GOODS_IN_TRANSIT_ACCOUNT_CODE = "1405";
    private static final String ACCRUED_PAYABLES_ACCOUNT_CODE = "2203";

    @Autowired
    public PurchaseOrderService(PurchaseOrderRepository purchaseOrderRepository, VendorRepository vendorRepository, AccountRepository accountRepository, TransactionService transactionService) {
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.vendorRepository = vendorRepository;
        this.accountRepository = accountRepository;
        this.transactionService = transactionService;
    }

    @Transactional
    public PurchaseOrderDto createPurchaseOrder(PurchaseOrderDto purchaseOrderDto) {
        Vendor vendor = vendorRepository.findById(purchaseOrderDto.getVendorId())
                .orElseThrow(() -> new ResourceNotFoundException("Vendor not found with id: " + purchaseOrderDto.getVendorId()));

        PurchaseOrder purchaseOrder = new PurchaseOrder();
        purchaseOrder.setVendor(vendor);
        purchaseOrder.setOrderDate(purchaseOrderDto.getOrderDate());
        purchaseOrder.setTotalAmount(purchaseOrderDto.getTotalAmount());
        purchaseOrder.setStatus(PurchaseOrderStatus.DRAFT);

        PurchaseOrder savedOrder = purchaseOrderRepository.save(purchaseOrder);
        return convertToDto(savedOrder);
    }

    @Transactional(readOnly = true)
    public PurchaseOrderDto getPurchaseOrderById(Long id) {
        PurchaseOrder order = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PurchaseOrder not found with id: " + id));
        return convertToDto(order);
    }

    @Transactional(readOnly = true)
    public List<PurchaseOrderDto> getAllPurchaseOrders() {
        return purchaseOrderRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public PurchaseOrderDto receivePurchaseOrder(Long orderId, BigDecimal actualAmount, LocalDate receiptDate) {
        PurchaseOrder order = purchaseOrderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("PurchaseOrder not found with id: " + orderId));

        if (order.getStatus() == PurchaseOrderStatus.RECEIVED) {
            throw new InvalidRequestException("Order is already received.");
        }

        Transaction accrualTransaction = createAccrualTransaction(order, actualAmount, receiptDate);
        Transaction savedTransaction = transactionService.createTransaction(accrualTransaction);

        order.setStatus(PurchaseOrderStatus.RECEIVED);
        order.setReceiptDate(receiptDate);
        order.setAutoTransaction(savedTransaction);

        PurchaseOrder updatedOrder = purchaseOrderRepository.save(order);
        return convertToDto(updatedOrder);
    }

    private Transaction createAccrualTransaction(PurchaseOrder order, BigDecimal amount, LocalDate date) {
        Account goodsInTransitAccount = accountRepository.findByCode(GOODS_IN_TRANSIT_ACCOUNT_CODE)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + GOODS_IN_TRANSIT_ACCOUNT_CODE));
        Account accruedPayablesAccount = accountRepository.findByCode(ACCRUED_PAYABLES_ACCOUNT_CODE)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + ACCRUED_PAYABLES_ACCOUNT_CODE));

        Transaction transaction = new Transaction();
        transaction.setDate(date);
        transaction.setDescription("Accrual for PO " + order.getId());
        transaction.setStatus(TransactionStatus.AUDITED);

        Split debitSplit = new Split();
        debitSplit.setAccount(goodsInTransitAccount);
        debitSplit.setAmountBase(amount);
        debitSplit.setBalanceDirection(BalanceDirection.DEBIT);
        debitSplit.setDescription("Debit Goods in Transit");

        Split creditSplit = new Split();
        creditSplit.setAccount(accruedPayablesAccount);
        creditSplit.setAmountBase(amount);
        creditSplit.setBalanceDirection(BalanceDirection.CREDIT);
        creditSplit.setDescription("Credit Accrued Payables");

        transaction.addSplit(debitSplit);
        transaction.addSplit(creditSplit);

        return transaction;
    }

    private PurchaseOrderDto convertToDto(PurchaseOrder order) {
        PurchaseOrderDto dto = new PurchaseOrderDto();
        BeanUtils.copyProperties(order, dto);
        if (order.getVendor() != null) {
            dto.setVendorId(order.getVendor().getId());
            dto.setVendorName(order.getVendor().getVendorName());
        }
        if (order.getAutoTransaction() != null) {
            dto.setAutoTransactionId(order.getAutoTransaction().getId());
        }
        return dto;
    }
}
