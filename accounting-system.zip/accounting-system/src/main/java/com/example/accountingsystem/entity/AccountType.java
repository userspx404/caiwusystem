package com.example.accountingsystem.entity;

public enum AccountType {
    ASSET,      // 資產
    LIABILITY,  // 負債
    EQUITY,     // 權益
    INCOME,     // 收入
    EXPENSE     // 支出
}

