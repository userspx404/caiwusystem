package com.example.accountingsystem.dto;

import com.example.accountingsystem.entity.PurchaseOrderStatus;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PurchaseOrderDto {

    private Long id;
    private Long vendorId;
    private String vendorName; // For display purposes
    private LocalDate orderDate;
    private BigDecimal totalAmount;
    private LocalDate receiptDate;
    private Long autoTransactionId;
    private PurchaseOrderStatus status;

}

