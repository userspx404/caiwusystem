package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "splits")
@Data
public class Split {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "split_id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "transaction_id", nullable = false)
    private Transaction transaction;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;

    @Enumerated(EnumType.STRING)
    @Column(name = "balance_direction", nullable = false, length = 10)
    private BalanceDirection balanceDirection;

    @Column(name = "amount_base", nullable = false, precision = 19, scale = 4)
    private BigDecimal amountBase; // 以本位幣計價的金額

    @Column(name = "foreign_currency_amount", precision = 19, scale = 4)
    private BigDecimal foreignCurrencyAmount; // 原始外幣金額

    @Column(name = "currency", length = 10)
    private String currency; // 貨幣代碼 (e.g., USD)

    @Column(name = "exchange_rate", precision = 19, scale = 8)
    private BigDecimal exchangeRate; // 當時匯率

    @Column(length = 255)
    private String description;

    @Column(name = "is_reconciled", nullable = false)
    private boolean isReconciled = false;
}

