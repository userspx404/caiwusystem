package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.FinancialReportDto;
import com.example.accountingsystem.dto.ReportItemDto;
import com.example.accountingsystem.dto.ReportSectionDto;
import com.example.accountingsystem.entity.Account;
import com.example.accountingsystem.entity.AccountType;
import com.example.accountingsystem.entity.ReportType;
import com.example.accountingsystem.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class FinancialReportService {

    private final AccountRepository accountRepository;

    @Autowired
    public FinancialReportService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Transactional(readOnly = true)
    public FinancialReportDto generateReport(ReportType reportType, LocalDate reportDate) {
        if (reportType == ReportType.BALANCE_SHEET) {
            return generateBalanceSheet(reportDate);
        } else if (reportType == ReportType.INCOME_STATEMENT) {
            return generateIncomeStatement(reportDate);
        }
        return null;
    }

    private FinancialReportDto generateBalanceSheet(LocalDate reportDate) {
        FinancialReportDto report = new FinancialReportDto();
        report.setReportName("Balance Sheet");
        report.setReportDate(reportDate);

        // --- Assets ---
        List<Account> assets = accountRepository.findByTypeIn(List.of(AccountType.ASSET));
        ReportSectionDto assetSection = new ReportSectionDto("Assets");
        assets.forEach(acc -> assetSection.addItem(new ReportItemDto(acc.getCode(), acc.getName(), acc.getCurrentBalance())));
        report.getSections().put("Assets", assetSection);
        report.setTotalAssets(assetSection.getSubtotal());

        // --- Liabilities ---
        List<Account> liabilities = accountRepository.findByTypeIn(List.of(AccountType.LIABILITY));
        ReportSectionDto liabilitySection = new ReportSectionDto("Liabilities");
        liabilities.forEach(acc -> liabilitySection.addItem(new ReportItemDto(acc.getCode(), acc.getName(), acc.getCurrentBalance())));
        report.getSections().put("Liabilities", liabilitySection);

        // --- Equity ---
        List<Account> equity = accountRepository.findByTypeIn(List.of(AccountType.EQUITY));
        ReportSectionDto equitySection = new ReportSectionDto("Equity");
        equity.forEach(acc -> equitySection.addItem(new ReportItemDto(acc.getCode(), acc.getName(), acc.getCurrentBalance())));
        report.getSections().put("Equity", equitySection);

        BigDecimal totalLiabilitiesAndEquity = liabilitySection.getSubtotal().add(equitySection.getSubtotal());
        report.setTotalLiabilitiesAndEquity(totalLiabilitiesAndEquity);

        return report;
    }

    private FinancialReportDto generateIncomeStatement(LocalDate reportDate) {
        FinancialReportDto report = new FinancialReportDto();
        report.setReportName("Income Statement");
        report.setReportDate(reportDate);

        // --- Income ---
        List<Account> incomes = accountRepository.findByTypeIn(List.of(AccountType.INCOME));
        ReportSectionDto incomeSection = new ReportSectionDto("Income");
        // Income accounts have credit balances, so we negate them for standard reporting
        incomes.forEach(acc -> incomeSection.addItem(new ReportItemDto(acc.getCode(), acc.getName(), acc.getCurrentBalance().negate())));
        report.getSections().put("Income", incomeSection);

        // --- Expenses ---
        List<Account> expenses = accountRepository.findByTypeIn(List.of(AccountType.EXPENSE));
        ReportSectionDto expenseSection = new ReportSectionDto("Expenses");
        expenses.forEach(acc -> expenseSection.addItem(new ReportItemDto(acc.getCode(), acc.getName(), acc.getCurrentBalance())));
        report.getSections().put("Expenses", expenseSection);

        BigDecimal netIncome = incomeSection.getSubtotal().subtract(expenseSection.getSubtotal());
        report.setNetIncome(netIncome);

        return report;
    }
}
