package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.SalesOrderDto;
import com.example.accountingsystem.dto.SalesOrderViewDto;
import com.example.accountingsystem.service.SalesOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sales-orders")
public class SalesOrderController {

    private final SalesOrderService salesOrderService;

    @Autowired
    public SalesOrderController(SalesOrderService salesOrderService) {
        this.salesOrderService = salesOrderService;
    }

    @PostMapping
    public ResponseEntity<SalesOrderViewDto> createSalesOrder(@RequestBody SalesOrderDto salesOrderDto) {
        SalesOrderViewDto createdOrder = salesOrderService.createSalesOrder(salesOrderDto);
        return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<SalesOrderViewDto>> getAllSalesOrders() {
        return ResponseEntity.ok(salesOrderService.getAllSalesOrders());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SalesOrderViewDto> getSalesOrderById(@PathVariable Long id) {
        return ResponseEntity.ok(salesOrderService.getSalesOrderById(id));
    }

    /**
     * Triggers the shipping/invoicing process for a sales order.
     * This will perform a credit check and auto-generate the AR transaction.
     * @param id The ID of the sales order to process.
     * @return The updated sales order view.
     */
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyRole('ACCOUNTANT','AUDITOR')")
    @PostMapping("/{id}/ship-and-invoice")
    public ResponseEntity<SalesOrderViewDto> shipAndInvoiceOrder(@PathVariable Long id) {
        SalesOrderViewDto updatedOrder = salesOrderService.shipAndInvoiceOrder(id);
        return ResponseEntity.ok(updatedOrder);
    }
}



