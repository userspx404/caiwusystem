package com.example.accountingsystem.repository;

import com.example.accountingsystem.entity.Vendor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VendorRepository extends JpaRepository<Vendor, Long> {

    /**
     * Find a vendor by its tax ID.
     * As per UC001, TaxID must be unique.
     * @param taxId The unique tax identifier.
     * @return An Optional containing the vendor if found.
     */
    Optional<Vendor> findByTaxId(String taxId);
}

