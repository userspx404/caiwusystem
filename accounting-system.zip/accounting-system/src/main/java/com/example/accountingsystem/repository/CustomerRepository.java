package com.example.accountingsystem.repository;

import com.example.accountingsystem.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    /**
     * Finds a customer by its tax ID.
     * As per UC009, TaxID must be unique.
     * @param taxId The unique tax identifier.
     * @return An Optional containing the customer if found.
     */
    Optional<Customer> findByTaxId(String taxId);
}



