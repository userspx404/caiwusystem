package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.BatchPostResultDto;
import com.example.accountingsystem.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/postings")
public class PostingController {

    private final TransactionService transactionService;

    @Autowired
    public PostingController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    /**
     * Triggers the batch posting of all audited transactions.
     * @return A DTO with the summary of the posting process.
     */
    @org.springframework.security.access.prepost.PreAuthorize("hasRole('AUDITOR')")
    @PostMapping("/batch")
    public ResponseEntity<BatchPostResultDto> batchPostTransactions() {
        int postedCount = transactionService.batchPostTransactions();
        return ResponseEntity.ok(new BatchPostResultDto(postedCount));
    }
}

