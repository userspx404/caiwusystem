package com.example.accountingsystem.entity;

public enum PaymentStatus {
    PENDING,    // 待執行
    PAID,       // 已支付
    FAILED      // 支付失敗
}

