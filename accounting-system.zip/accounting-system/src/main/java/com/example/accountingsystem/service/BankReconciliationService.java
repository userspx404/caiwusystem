package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.ReconciliationResultDto;
import com.example.accountingsystem.entity.BankStatement;
import com.example.accountingsystem.entity.ReconciliationStatus;
import com.example.accountingsystem.entity.Split;
import com.example.accountingsystem.repository.BankStatementRepository;
import com.example.accountingsystem.repository.SplitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BankReconciliationService {

    private final BankStatementRepository bankStatementRepository;
    private final SplitRepository splitRepository;

    @Autowired
    public BankReconciliationService(BankStatementRepository bankStatementRepository, SplitRepository splitRepository) {
        this.bankStatementRepository = bankStatementRepository;
        this.splitRepository = splitRepository;
    }

    /**
     * Performs automatic reconciliation for a given bank account.
     *
     * @param accountId The ID of the bank account to reconcile.
     * @param tolerance The amount tolerance for matching.
     * @return A DTO containing the results of the reconciliation.
     */
    @Transactional
    public ReconciliationResultDto autoReconcile(Long accountId, BigDecimal tolerance) {
        // 1. 獲取所有未對帳的銀行流水和帳務分錄
        List<BankStatement> unreconciledStatements = bankStatementRepository.findByAccountIdAndStatus(accountId, ReconciliationStatus.UNMATCHED);
        List<Split> unreconciledSplits = splitRepository.findByAccountIdAndIsReconciledFalse(accountId);

        ReconciliationResultDto result = new ReconciliationResultDto();
        result.setTotalStatementsProcessed(unreconciledStatements.size());
        result.setMatchedStatementIds(new ArrayList<>());
        result.setMatchedSplitIds(new ArrayList<>());

        List<BankStatement> matchedStatements = new ArrayList<>();
        List<Split> matchedSplits = new ArrayList<>();

        // 2. 遍歷每一筆銀行流水，嘗試尋找匹配的帳務分錄
        for (BankStatement statement : unreconciledStatements) {
            List<Split> potentialMatches = unreconciledSplits.stream()
                    .filter(split -> !matchedSplits.contains(split)) // 過濾掉本輪已匹配的分錄
                    .filter(split -> {
                        // 檢查金額是否在容忍度範圍內
                        BigDecimal splitAmount = split.getBalanceDirection() == split.getAccount().getBalanceDirection() ? split.getAmountBase() : split.getAmountBase().negate();
                        return statement.getAmount().subtract(splitAmount).abs().compareTo(tolerance) <= 0;
                    })
                    .collect(Collectors.toList());

            // 3. 如果只找到唯一一個匹配項，則視為成功匹配
            if (potentialMatches.size() == 1) {
                Split matchedSplit = potentialMatches.get(0);

                // 更新狀態
                statement.setStatus(ReconciliationStatus.MATCHED);
                statement.setMatchedSplit(matchedSplit);
                matchedSplit.setReconciled(true);

                matchedStatements.add(statement);
                matchedSplits.add(matchedSplit);

                result.getMatchedStatementIds().add(statement.getId());
                result.getMatchedSplitIds().add(matchedSplit.getId());
            }
        }

        // 4. 批次儲存所有更新
        if (!matchedStatements.isEmpty()) {
            bankStatementRepository.saveAll(matchedStatements);
            splitRepository.saveAll(matchedSplits);
        }

        result.setMatchedCount(matchedStatements.size());
        return result;
    }
}

