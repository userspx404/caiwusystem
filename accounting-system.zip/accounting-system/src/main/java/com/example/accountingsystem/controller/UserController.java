package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.CreateUserRequest;
import com.example.accountingsystem.dto.RoleDto;
import com.example.accountingsystem.dto.UpdateUserRequest;
import com.example.accountingsystem.dto.UserDto;
import com.example.accountingsystem.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@PreAuthorize("hasRole('ADMIN')")
@Tag(name = "使用者管理", description = "使用者與角色管理相關 API，僅限管理員訪問")
@SecurityRequirement(name = "Bearer Authentication")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @Operation(summary = "獲取所有使用者", description = "獲取系統中所有使用者的列表")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "成功獲取使用者列表"),
            @ApiResponse(responseCode = "403", description = "無權限訪問")
    })
    @GetMapping
    public ResponseEntity<List<UserDto>> getAllUsers() {
        return ResponseEntity.ok(userService.findAll());
    }

    @Operation(summary = "根據 ID 獲取使用者", description = "根據使用者 ID 獲取單一使用者的詳細資訊")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "成功獲取使用者資訊"),
            @ApiResponse(responseCode = "404", description = "使用者不存在"),
            @ApiResponse(responseCode = "403", description = "無權限訪問")
    })
    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUserById(
            @Parameter(description = "使用者 ID", required = true) @PathVariable Long id) {
        return ResponseEntity.ok(userService.findById(id));
    }

    @Operation(summary = "創建新使用者", description = "創建一個新的使用者帳號")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "使用者創建成功"),
            @ApiResponse(responseCode = "400", description = "請求參數錯誤或使用者名稱已存在"),
            @ApiResponse(responseCode = "403", description = "無權限訪問")
    })
    @PostMapping
    public ResponseEntity<UserDto> createUser(@jakarta.validation.Valid @RequestBody CreateUserRequest request) {
        try {
            UserDto createdUser = userService.createUser(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @Operation(summary = "更新使用者資訊", description = "更新指定使用者的資訊（包括密碼、角色、狀態等）")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "使用者更新成功"),
            @ApiResponse(responseCode = "400", description = "請求參數錯誤"),
            @ApiResponse(responseCode = "404", description = "使用者不存在"),
            @ApiResponse(responseCode = "403", description = "無權限訪問")
    })
    @PutMapping("/{id}")
    public ResponseEntity<UserDto> updateUser(
            @Parameter(description = "使用者 ID", required = true) @PathVariable Long id, 
            @jakarta.validation.Valid @RequestBody UpdateUserRequest request) {
        try {
            UserDto updatedUser = userService.updateUser(id, request);
            return ResponseEntity.ok(updatedUser);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @Operation(summary = "刪除使用者", description = "刪除指定的使用者帳號")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "使用者刪除成功"),
            @ApiResponse(responseCode = "404", description = "使用者不存在"),
            @ApiResponse(responseCode = "403", description = "無權限訪問")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(
            @Parameter(description = "使用者 ID", required = true) @PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "獲取所有角色", description = "獲取系統中所有可用的角色列表")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "成功獲取角色列表"),
            @ApiResponse(responseCode = "403", description = "無權限訪問")
    })
    @GetMapping("/roles")
    public ResponseEntity<List<RoleDto>> getAllRoles() {
        return ResponseEntity.ok(userService.getAllRoles());
    }
}

