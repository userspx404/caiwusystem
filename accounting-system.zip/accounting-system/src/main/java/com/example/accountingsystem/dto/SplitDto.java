package com.example.accountingsystem.dto;

import com.example.accountingsystem.entity.BalanceDirection;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class SplitDto {

    private Long id;
    private Long accountId;
    private String accountCode;
    private String accountName;
    private BalanceDirection balanceDirection;
    private BigDecimal amount;
    private String description;
}

