package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.VendorDto;
import com.example.accountingsystem.entity.Vendor;
import com.example.accountingsystem.service.VendorService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/vendors")
public class VendorController {

    private final VendorService vendorService;

    @Autowired
    public VendorController(VendorService vendorService) {
        this.vendorService = vendorService;
    }

    @PostMapping
    public ResponseEntity<VendorDto> createVendor(@RequestBody VendorDto vendorDto) {
        Vendor vendor = convertToEntity(vendorDto);
        Vendor createdVendor = vendorService.createVendor(vendor);
        return new ResponseEntity<>(convertToDto(createdVendor), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<VendorDto> getVendorById(@PathVariable Long id) {
        Vendor vendor = vendorService.getVendorById(id);
        return ResponseEntity.ok(convertToDto(vendor));
    }

    @GetMapping
    public ResponseEntity<List<VendorDto>> getAllVendors() {
        List<Vendor> vendors = vendorService.getAllVendors();
        List<VendorDto> vendorDtos = vendors.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(vendorDtos);
    }

    @PutMapping("/{id}")
    public ResponseEntity<VendorDto> updateVendor(@PathVariable Long id, @RequestBody VendorDto vendorDto) {
        Vendor vendorDetails = convertToEntity(vendorDto);
        Vendor updatedVendor = vendorService.updateVendor(id, vendorDetails);
        return ResponseEntity.ok(convertToDto(updatedVendor));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVendor(@PathVariable Long id) {
        vendorService.deleteVendor(id);
        return ResponseEntity.noContent().build();
    }

    // --- Helper Methods for DTO conversion ---

    private VendorDto convertToDto(Vendor vendor) {
        VendorDto vendorDto = new VendorDto();
        BeanUtils.copyProperties(vendor, vendorDto);
        return vendorDto;
    }

    private Vendor convertToEntity(VendorDto vendorDto) {
        Vendor vendor = new Vendor();
        BeanUtils.copyProperties(vendorDto, vendor);
        return vendor;
    }
}

