package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.ReconciliationRequestDto;
import com.example.accountingsystem.dto.ReconciliationResultDto;
import com.example.accountingsystem.service.BankReconciliationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/reconciliations")
public class BankReconciliationController {

    private final BankReconciliationService reconciliationService;

    @Autowired
    public BankReconciliationController(BankReconciliationService reconciliationService) {
        this.reconciliationService = reconciliationService;
    }

    /**
     * Triggers the automatic bank reconciliation process.
     * @param requestDto DTO containing the account ID and tolerance.
     * @return A DTO with the summary of the reconciliation.
     */
    @PostMapping("/auto-reconcile")
    public ResponseEntity<ReconciliationResultDto> autoReconcile(@RequestBody ReconciliationRequestDto requestDto) {
        ReconciliationResultDto result = reconciliationService.autoReconcile(
                requestDto.getAccountId(),
                requestDto.getTolerance()
        );
        return ResponseEntity.ok(result);
    }

    // TODO: Add endpoints for uploading bank statements and manual reconciliation.
}

