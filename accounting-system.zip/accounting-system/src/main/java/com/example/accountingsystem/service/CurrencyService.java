package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.CurrencyDto;
import com.example.accountingsystem.entity.Currency;
import com.example.accountingsystem.exception.InvalidRequestException;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.CurrencyRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CurrencyService {

    private final CurrencyRepository currencyRepository;

    @Autowired
    public CurrencyService(CurrencyRepository currencyRepository) {
        this.currencyRepository = currencyRepository;
    }

    @Transactional
    public CurrencyDto createCurrency(CurrencyDto currencyDto) {
        if (currencyRepository.existsById(currencyDto.getCode())) {
            throw new InvalidRequestException("Currency with code '" + currencyDto.getCode() + "' already exists.");
        }
        if (currencyDto.isBaseCurrency()) {
            ensureNoOtherBaseCurrency(null);
        }
        Currency currency = convertToEntity(currencyDto);
        Currency savedCurrency = currencyRepository.save(currency);
        return convertToDto(savedCurrency);
    }

    @Transactional(readOnly = true)
    public List<CurrencyDto> getAllCurrencies() {
        return currencyRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public CurrencyDto getCurrencyByCode(String code) {
        return currencyRepository.findById(code)
                .map(this::convertToDto)
                .orElseThrow(() -> new ResourceNotFoundException("Currency not found with code: " + code));
    }

    @Transactional
    public CurrencyDto updateCurrency(String code, CurrencyDto currencyDto) {
        Currency existingCurrency = currencyRepository.findById(code)
                .orElseThrow(() -> new ResourceNotFoundException("Currency not found with code: " + code));

        if (currencyDto.isBaseCurrency()) {
            ensureNoOtherBaseCurrency(code);
        }

        existingCurrency.setName(currencyDto.getName());
        existingCurrency.setBaseCurrency(currencyDto.isBaseCurrency());

        Currency updatedCurrency = currencyRepository.save(existingCurrency);
        return convertToDto(updatedCurrency);
    }

    public void deleteCurrency(String code) {
        if (!currencyRepository.existsById(code)) {
            throw new ResourceNotFoundException("Currency not found with code: " + code);
        }
        // TODO: Add validation to prevent deletion if the currency is in use.
        currencyRepository.deleteById(code);
    }

    private void ensureNoOtherBaseCurrency(String currentCode) {
        Optional<Currency> baseCurrencyOpt = currencyRepository.findByIsBaseCurrencyTrue();
        if (baseCurrencyOpt.isPresent() && !baseCurrencyOpt.get().getCode().equals(currentCode)) {
            throw new InvalidRequestException("A base currency is already set ('" + baseCurrencyOpt.get().getCode() + "'). Only one currency can be the base currency.");
        }
    }

    private CurrencyDto convertToDto(Currency currency) {
        CurrencyDto dto = new CurrencyDto();
        BeanUtils.copyProperties(currency, dto);
        return dto;
    }

    private Currency convertToEntity(CurrencyDto dto) {
        Currency currency = new Currency();
        BeanUtils.copyProperties(dto, currency);
        return currency;
    }
}

