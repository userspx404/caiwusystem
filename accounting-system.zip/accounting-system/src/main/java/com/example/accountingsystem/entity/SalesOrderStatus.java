package com.example.accountingsystem.entity;

public enum SalesOrderStatus {
    DRAFT,          // 草稿
    CONFIRMED,      // 已確認
    SHIPPED,        // 已發貨
    INVOICED,       // 已開票
    CANCELLED       // 已取消
}



