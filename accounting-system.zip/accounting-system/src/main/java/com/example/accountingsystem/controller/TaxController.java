package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.TaxCalculationRequestDto;
import com.example.accountingsystem.dto.TaxFilingDto;
import com.example.accountingsystem.service.TaxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/taxes")
public class TaxController {

    private final TaxService taxService;

    @Autowired
    public TaxController(TaxService taxService) {
        this.taxService = taxService;
    }

    /**
     * Calculates taxes for a given period and creates a tax filing record
     * along with a corresponding payment request.
     * @param requestDto DTO containing period, dates, rate, and bank account ID.
     * @return The created TaxFiling record.
     */
    @PostMapping("/calculate-and-file")
    public ResponseEntity<TaxFilingDto> calculateAndFile(@RequestBody TaxCalculationRequestDto requestDto) {
        TaxFilingDto result = taxService.calculateAndCreateTaxFiling(requestDto);
        if (result != null) {
            return ResponseEntity.ok(result);
        } else {
            // No tax payable, so no filing was created.
            return ResponseEntity.noContent().build();
        }
    }
}



