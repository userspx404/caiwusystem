package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.CreateUserRequest;
import com.example.accountingsystem.dto.RoleDto;
import com.example.accountingsystem.dto.UpdateUserRequest;
import com.example.accountingsystem.dto.UserDto;
import com.example.accountingsystem.entity.Role;
import com.example.accountingsystem.entity.User;
import com.example.accountingsystem.repository.RoleRepository;
import com.example.accountingsystem.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional(readOnly = true)
    public List<UserDto> findAll() {
        // 使用 JOIN FETCH 來避免懶加載問題
        return userRepository.findAllWithRoles().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public UserDto findById(Long id) {
        return userRepository.findByIdWithRoles(id)
                .map(this::toDto)
                .orElseThrow(() -> new RuntimeException("找不到使用者 ID: " + id));
    }

    @Transactional
    public UserDto createUser(CreateUserRequest request) {
        // 檢查使用者名稱是否已存在
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new RuntimeException("使用者名稱已存在: " + request.getUsername());
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setEnabled(request.isEnabled());

        // 分配角色
        if (request.getRoleIds() != null && !request.getRoleIds().isEmpty()) {
            Set<Role> roles = request.getRoleIds().stream()
                    .map(roleId -> roleRepository.findById(roleId)
                            .orElseThrow(() -> new RuntimeException("找不到角色 ID: " + roleId)))
                    .collect(Collectors.toSet());
            user.setRoles(roles);
        }

        User savedUser = userRepository.save(user);
        // 重新載入以獲取完整的實體（包括角色）
        return toDto(userRepository.findByIdWithRoles(savedUser.getId())
                .orElseThrow(() -> new RuntimeException("無法找到剛建立的使用者")));
    }

    @Transactional
    public UserDto updateUser(Long id, UpdateUserRequest request) {
        User user = userRepository.findByIdWithRoles(id)
                .orElseThrow(() -> new RuntimeException("找不到使用者 ID: " + id));

        // 更新使用者名稱（如果提供）
        if (request.getUsername() != null && !request.getUsername().isEmpty()) {
            // 檢查新使用者名稱是否與其他使用者衝突
            userRepository.findByUsername(request.getUsername())
                    .ifPresent(existingUser -> {
                        if (!existingUser.getId().equals(id)) {
                            throw new RuntimeException("使用者名稱已存在: " + request.getUsername());
                        }
                    });
            user.setUsername(request.getUsername());
        }

        // 更新密碼（如果提供）
        if (request.getPassword() != null && !request.getPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(request.getPassword()));
        }

        // 更新啟用狀態（如果提供）
        if (request.getEnabled() != null) {
            user.setEnabled(request.getEnabled());
        }

        // 更新角色（如果提供）
        if (request.getRoleIds() != null) {
            Set<Role> roles = new HashSet<>();
            if (!request.getRoleIds().isEmpty()) {
                roles = request.getRoleIds().stream()
                        .map(roleId -> roleRepository.findById(roleId)
                                .orElseThrow(() -> new RuntimeException("找不到角色 ID: " + roleId)))
                        .collect(Collectors.toSet());
            }
            user.setRoles(roles);
        }

        User savedUser = userRepository.save(user);
        // 重新載入以獲取完整的實體（包括角色）
        return toDto(userRepository.findByIdWithRoles(savedUser.getId())
                .orElseThrow(() -> new RuntimeException("無法找到更新後的使用者")));
    }

    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("找不到使用者 ID: " + id));
        userRepository.delete(user);
    }

    @Transactional(readOnly = true)
    public List<RoleDto> getAllRoles() {
        return roleRepository.findAll().stream()
                .map(this::roleToDto)
                .collect(Collectors.toList());
    }

    private UserDto toDto(User user) {
        UserDto dto = new UserDto();
        dto.setId(user.getId());
        dto.setUsername(user.getUsername());
        dto.setEnabled(user.isEnabled());
        // 轉換角色
        Set<RoleDto> roleDtos = user.getRoles().stream()
                .map(this::roleToDto)
                .collect(Collectors.toSet());
        dto.setRoles(roleDtos);
        return dto;
    }

    private RoleDto roleToDto(Role role) {
        RoleDto dto = new RoleDto();
        dto.setId(role.getId());
        dto.setName(role.getName());
        return dto;
    }
}

