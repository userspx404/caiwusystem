package com.example.accountingsystem.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
public class ReportSectionDto {

    private String sectionName;
    private List<ReportItemDto> items = new ArrayList<>();
    private BigDecimal subtotal = BigDecimal.ZERO;

    public ReportSectionDto(String sectionName) {
        this.sectionName = sectionName;
    }

    public void addItem(ReportItemDto item) {
        this.items.add(item);
        this.subtotal = this.subtotal.add(item.getBalance());
    }
}
