package com.example.accountingsystem.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ReceiveOrderRequestDto {

    private BigDecimal actualAmount;
    private LocalDate receiptDate;

}

