package com.example.accountingsystem.repository;

import com.example.accountingsystem.entity.Account;
import com.example.accountingsystem.entity.AccountType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

    List<Account> findByCurrencyIsNotNullAndTypeIn(List<AccountType> types);

    List<Account> findByTypeIn(List<AccountType> types);

    /**
     * 根據科目代碼查詢帳戶。
     * 科目代碼是唯一的。
     * @param code 科目代碼
     * @return 可能包含帳戶的 Optional
     */
    Optional<Account> findByCode(String code);
}
