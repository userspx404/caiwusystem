package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.AuditRequestDto;
import com.example.accountingsystem.dto.TransactionDto;
import com.example.accountingsystem.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping
    public ResponseEntity<TransactionDto> createTransaction(@RequestBody TransactionDto transactionDto) {
        TransactionDto createdTransaction = transactionService.createTransaction(transactionDto);
        return new ResponseEntity<>(createdTransaction, HttpStatus.CREATED);
    }

    // RBAC: 僅 AUDITOR 可審核（預置註解，尚未啟用方法級安全）
    // @PreAuthorize("hasRole('AUDITOR')")
    @org.springframework.security.access.prepost.PreAuthorize("hasRole('AUDITOR')")
    @PostMapping("/{id}/audit")
    public ResponseEntity<TransactionDto> auditTransaction(@PathVariable Long id, @RequestBody(required = false) AuditRequestDto auditRequestDto) {
        try {
            Long auditorId = (auditRequestDto != null && auditRequestDto.getAuditorId() != null) 
                ? auditRequestDto.getAuditorId() 
                : 1L; // 默认审核人ID
            TransactionDto auditedTransaction = transactionService.auditTransaction(id, auditorId);
            return ResponseEntity.ok(auditedTransaction);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // RBAC: 僅 AUDITOR 可作廢（預置註解，尚未啟用方法級安全）
    // @PreAuthorize("hasRole('AUDITOR')")
    @org.springframework.security.access.prepost.PreAuthorize("hasRole('AUDITOR')")
    @PostMapping("/{id}/cancel")
    public ResponseEntity<TransactionDto> cancelTransaction(@PathVariable Long id) {
        try {
            TransactionDto cancelledTransaction = transactionService.cancelTransaction(id);
            return ResponseEntity.ok(cancelledTransaction);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping
    public ResponseEntity<List<TransactionDto>> getAllTransactions() {
        List<TransactionDto> transactions = transactionService.getAllTransactions();
        return ResponseEntity.ok(transactions);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TransactionDto> getTransactionById(@PathVariable Long id) {
        TransactionDto transaction = transactionService.getTransactionById(id);
        return ResponseEntity.ok(transaction);
    }
}
