package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.CustomerDto;
import com.example.accountingsystem.entity.Customer;
import com.example.accountingsystem.exception.InvalidRequestException;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.CustomerRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    @Autowired
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Transactional
    public CustomerDto createCustomer(CustomerDto customerDto) {
        if (customerDto.getTaxId() != null && !customerDto.getTaxId().isBlank()) {
            customerRepository.findByTaxId(customerDto.getTaxId()).ifPresent(c -> {
                throw new InvalidRequestException("Tax ID '" + customerDto.getTaxId() + "' already exists.");
            });
        }

        // Manual mapping to avoid overwriting defaults with nulls
        Customer customer = new Customer();
        customer.setCustomerName(customerDto.getCustomerName());
        customer.setTaxId(customerDto.getTaxId());
        customer.setSettlementCurrency(customerDto.getSettlementCurrency());
        
        // Use provided value or default to ZERO
        customer.setCreditLimit(customerDto.getCreditLimit() != null ? customerDto.getCreditLimit() : BigDecimal.ZERO);
        
        // Ensure status and balance have default values
        customer.setStatus("有效");
        customer.setCurrentBalance(BigDecimal.ZERO);

        Customer savedCustomer = customerRepository.save(customer);
        return convertToDto(savedCustomer);
    }

    @Transactional(readOnly = true)
    public List<CustomerDto> getAllCustomers() {
        return customerRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public CustomerDto getCustomerById(Long id) {
        return customerRepository.findById(id)
                .map(this::convertToDto)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + id));
    }

    @Transactional
    public CustomerDto updateCustomer(Long id, CustomerDto customerDto) {
        Customer existingCustomer = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + id));

        if (customerDto.getTaxId() != null && !customerDto.getTaxId().isBlank() && !customerDto.getTaxId().equals(existingCustomer.getTaxId())) {
            Optional<Customer> customerWithNewTaxId = customerRepository.findByTaxId(customerDto.getTaxId());
            if (customerWithNewTaxId.isPresent() && !customerWithNewTaxId.get().getId().equals(id)) {
                throw new InvalidRequestException("Tax ID '" + customerDto.getTaxId() + "' is already in use by another customer.");
            }
            existingCustomer.setTaxId(customerDto.getTaxId());
        }

        existingCustomer.setCustomerName(customerDto.getCustomerName());
        existingCustomer.setCreditLimit(customerDto.getCreditLimit());
        existingCustomer.setSettlementCurrency(customerDto.getSettlementCurrency());
        existingCustomer.setStatus(customerDto.getStatus());

        Customer updatedCustomer = customerRepository.save(existingCustomer);
        return convertToDto(updatedCustomer);
    }

    public void deleteCustomer(Long id) {
        if (!customerRepository.existsById(id)) {
            throw new ResourceNotFoundException("Customer not found with id: " + id);
        }
        // Note: Add validation to prevent deletion if the customer is linked to sales orders.
        customerRepository.deleteById(id);
    }

    private CustomerDto convertToDto(Customer customer) {
        CustomerDto dto = new CustomerDto();
        BeanUtils.copyProperties(customer, dto);
        return dto;
    }

    // This method is no longer used for creation to avoid null issues.
    private Customer convertToEntity(CustomerDto dto) {
        Customer customer = new Customer();
        BeanUtils.copyProperties(dto, customer);
        return customer;
    }
}
