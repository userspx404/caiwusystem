package com.example.accountingsystem.dto;

import com.example.accountingsystem.entity.AccountType;
import com.example.accountingsystem.entity.BalanceDirection;
import lombok.Data;

@Data
public class AccountDto {

    private Long id;
    private String code;
    private String name;
    private AccountType type;
    private Long parentId; // 只傳輸父級ID，而非整個物件
    private String parentCode;
    private String parentName;
    private BalanceDirection balanceDirection;
    private String auxiliaryManagement;
    private boolean isActive;
}

