package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "transactions")
@Data
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "transaction_id")
    private Long id;

    @Column(name = "voucher_no", unique = true, nullable = false, length = 50)
    private String voucherNo;

    @Column(nullable = false)
    private LocalDate date;

    @Column(length = 255)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TransactionStatus status = TransactionStatus.DRAFT;

    // 關聯到分錄，設定級聯操作，並在移除 transaction 時一併移除其下的 splits
    @OneToMany(mappedBy = "transaction", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Split> splits = new ArrayList<>();

    // 建立人/審核人/過帳批次ID，暫存為 Long，未來可關聯到 User 或 Batch 實體
    @Column(name = "creator_id")
    private Long creatorId;

    @Column(name = "auditor_id")
    private Long auditorId;

    @Column(name = "posting_batch_id")
    private Long postingBatchId;

    @Column(name = "posting_date")
    private LocalDateTime postingDate;

    // 方便地添加分錄並設置雙向關聯
    public void addSplit(Split split) {
        splits.add(split);
        split.setTransaction(this);
    }
}

