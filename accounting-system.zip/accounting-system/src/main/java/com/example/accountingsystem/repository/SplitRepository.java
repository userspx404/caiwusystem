package com.example.accountingsystem.repository;

import com.example.accountingsystem.entity.Split;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.example.accountingsystem.entity.AccountType;
import com.example.accountingsystem.entity.AccountType;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;

import java.time.LocalDate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface SplitRepository extends JpaRepository<Split, Long> {

    /**
     * Checks if any split exists for a given account ID.
     * This is used to determine if an account has any transactions.
     * @param accountId The ID of the account.
     * @return true if splits exist, false otherwise.
     */
        boolean existsByAccountId(Long accountId);

    /**
     * Finds all unreconciled splits for a given account.
     * @param accountId The ID of the bank account.
     * @return A list of unreconciled splits.
     */
        List<Split> findByAccountIdAndIsReconciledFalse(Long accountId);

    /**
     * Calculates the net balance change for accounts of specific types within a date range.
     * @param types List of account types (e.g., INCOME, EXPENSE).
     * @param startDate The start of the period (inclusive).
     * @param endDate The end of the period (inclusive).
     * @return The net balance change.
     */
    @Query("SELECT COALESCE(SUM(CASE WHEN s.balanceDirection = 'DEBIT' THEN s.amountBase ELSE -s.amountBase END), 0) " +
           "FROM Split s JOIN s.account a " +
           "WHERE a.type IN :types AND s.transaction.date BETWEEN :startDate AND :endDate")
    BigDecimal sumAmountByAccountTypeInDateRange(@Param("types") List<AccountType> types, 
                                                 @Param("startDate") LocalDate startDate, 
                                                 @Param("endDate") LocalDate endDate);

    /**
     * Calculates the sum of the base currency amount for a given account.
     * Debits are added, credits are subtracted.
     * @param accountId The ID of the account.
     * @return The total balance in the base currency.
     */
    @Query("SELECT COALESCE(SUM(CASE WHEN s.balanceDirection = 'DEBIT' THEN s.amountBase ELSE -s.amountBase END), 0) FROM Split s WHERE s.account.id = :accountId")
    BigDecimal sumBaseAmountByAccountId(@Param("accountId") Long accountId);

    /**
     * Calculates the sum of the foreign currency amount for a given account.
     * Debits are added, credits are subtracted.
     * @param accountId The ID of the account.
     * @return The total balance in the foreign currency.
     */
    @Query("SELECT COALESCE(SUM(CASE WHEN s.balanceDirection = 'DEBIT' THEN s.foreignCurrencyAmount ELSE -s.foreignCurrencyAmount END), 0) FROM Split s WHERE s.account.id = :accountId")
    BigDecimal sumForeignCurrencyAmountByAccountId(@Param("accountId") Long accountId);
}
