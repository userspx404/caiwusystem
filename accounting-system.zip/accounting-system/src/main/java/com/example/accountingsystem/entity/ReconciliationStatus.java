package com.example.accountingsystem.entity;

public enum ReconciliationStatus {
    UNMATCHED,      // 未對平
    MATCHED,        // 已對平
    MANUALLY_ADDED  // 手工創建的未達帳項
}

