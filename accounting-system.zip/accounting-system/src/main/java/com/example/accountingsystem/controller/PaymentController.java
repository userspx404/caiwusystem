package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.PaymentExecuteDto;
import com.example.accountingsystem.dto.PaymentRequestDto;
import com.example.accountingsystem.dto.PaymentRequestViewDto;
import com.example.accountingsystem.entity.PaymentStatus;
import com.example.accountingsystem.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // 建立付款申請
    @PostMapping
    public ResponseEntity<PaymentRequestViewDto> createRequest(@RequestBody PaymentRequestDto dto) {
        PaymentRequestViewDto created = paymentService.createRequest(dto);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    // 依狀態查詢付款申請（未傳狀態則回傳全部 PENDING）
    @GetMapping
    public ResponseEntity<List<PaymentRequestViewDto>> listByStatus(@RequestParam(required = false) PaymentStatus status) {
        PaymentStatus effective = status == null ? PaymentStatus.PENDING : status;
        return ResponseEntity.ok(paymentService.listByStatus(effective));
    }

    // 查詢單筆付款申請
    @GetMapping("/{id}")
    public ResponseEntity<PaymentRequestViewDto> getById(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.getById(id));
    }

    // 執行付款（模擬銀企直連）
    @org.springframework.security.access.prepost.PreAuthorize("hasRole('CASHIER')")
    @PostMapping("/{id}/execute")
    public ResponseEntity<PaymentRequestViewDto> execute(@PathVariable Long id, @RequestBody PaymentExecuteDto execDto) {
        PaymentRequestViewDto result = paymentService.executePayment(id, execDto);
        return ResponseEntity.ok(result);
    }
}
