package com.example.accountingsystem.service;

import com.example.accountingsystem.dto.PaymentExecuteDto;
import com.example.accountingsystem.dto.PaymentRequestDto;
import com.example.accountingsystem.dto.PaymentRequestViewDto;
import com.example.accountingsystem.entity.*;
import com.example.accountingsystem.exception.InvalidRequestException;
import com.example.accountingsystem.exception.ResourceNotFoundException;
import com.example.accountingsystem.repository.AccountRepository;
import com.example.accountingsystem.repository.PaymentRequestRepository;
import com.example.accountingsystem.repository.VendorRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PaymentService {

    private final PaymentRequestRepository paymentRequestRepository;
    private final VendorRepository vendorRepository;
    private final AccountRepository accountRepository;
    private final TransactionService transactionService;

    // 應付帳款總帳科目（需存在）
    private static final String ACCOUNTS_PAYABLE_CODE = "2202";

    @Autowired
    public PaymentService(PaymentRequestRepository paymentRequestRepository,
                          VendorRepository vendorRepository,
                          AccountRepository accountRepository,
                          TransactionService transactionService) {
        this.paymentRequestRepository = paymentRequestRepository;
        this.vendorRepository = vendorRepository;
        this.accountRepository = accountRepository;
        this.transactionService = transactionService;
    }

    @Transactional
    public PaymentRequestViewDto createRequest(PaymentRequestDto dto) {
        PaymentRequest saved = createRequestAndReturnEntity(dto);
        return toView(saved);
    }

    /**
     * Creates a payment request and returns the saved entity.
     * Intended for internal use by other services like TaxService.
     * @param dto The payment request data.
     * @return The saved PaymentRequest entity.
     */
    @Transactional
    public PaymentRequest createRequestAndReturnEntity(PaymentRequestDto dto) {
        Vendor vendor = vendorRepository.findById(dto.getVendorId())
                .orElseThrow(() -> new ResourceNotFoundException("Vendor not found: " + dto.getVendorId()));
        Account bankAccount = accountRepository.findById(dto.getBankAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("Bank account not found: " + dto.getBankAccountId()));

        if (bankAccount.getType() != AccountType.ASSET) {
            throw new InvalidRequestException("Payment can only be made from an ASSET type account.");
        }

        PaymentRequest pr = new PaymentRequest();
        pr.setVendor(vendor);
        pr.setBankAccount(bankAccount);
        pr.setAmount(dto.getAmount());
        pr.setRequestDate(dto.getRequestDate() != null ? dto.getRequestDate() : LocalDate.now());
        pr.setStatus(PaymentStatus.PENDING);

        return paymentRequestRepository.save(pr);
    }

    @Transactional(readOnly = true)
    public List<PaymentRequestViewDto> listByStatus(PaymentStatus status) {
        return paymentRequestRepository.findByStatus(status).stream()
                .map(this::toView)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public PaymentRequestViewDto getById(Long id) {
        PaymentRequest pr = paymentRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment request not found: " + id));
        return toView(pr);
    }

    @Transactional
    public PaymentRequestViewDto executePayment(Long id, PaymentExecuteDto dto) {
        PaymentRequest pr = paymentRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment request not found: " + id));
        if (pr.getStatus() != PaymentStatus.PENDING) {
            throw new InvalidRequestException("Payment request already processed. Current status: " + pr.getStatus());
        }

        // 記錄銀行回執
        pr.setBankReceiptId(dto.getBankReceiptId());
        pr.setBankReceiptRaw(dto.getBankReceiptRaw());

        if (!dto.isSuccess()) {
            pr.setStatus(PaymentStatus.FAILED);
            PaymentRequest saved = paymentRequestRepository.save(pr);
            return toView(saved);
        }

        // 成功：自動生成付款記帳憑證（已審核）
        Account apAccount = accountRepository.findByCode(ACCOUNTS_PAYABLE_CODE)
                .orElseThrow(() -> new ResourceNotFoundException("Accounts Payable account not found: " + ACCOUNTS_PAYABLE_CODE));

        Transaction t = new Transaction();
        t.setDate(LocalDate.now());
        t.setDescription("Payment to Vendor " + pr.getVendor().getVendorName() + " (PR#" + pr.getId() + ")");
        t.setStatus(TransactionStatus.AUDITED);

        // 借：應付帳款  貸：銀行存款
        Split dr = new Split();
        dr.setAccount(apAccount);
        dr.setAmountBase(pr.getAmount());
        dr.setBalanceDirection(BalanceDirection.DEBIT);
        dr.setDescription("Debit Accounts Payable");

        Split cr = new Split();
        cr.setAccount(pr.getBankAccount());
        cr.setAmountBase(pr.getAmount());
        cr.setBalanceDirection(BalanceDirection.CREDIT);
        cr.setDescription("Credit Bank");

        t.addSplit(dr);
        t.addSplit(cr);

        Transaction savedTx = transactionService.createTransaction(t);

        pr.setAutoTransaction(savedTx);
        pr.setStatus(PaymentStatus.PAID);
        PaymentRequest saved = paymentRequestRepository.save(pr);

        return toView(saved);
    }

    private PaymentRequestViewDto toView(PaymentRequest pr) {
        PaymentRequestViewDto view = new PaymentRequestViewDto();
        BeanUtils.copyProperties(pr, view);
        if (pr.getVendor() != null) {
            view.setVendorId(pr.getVendor().getId());
            view.setVendorName(pr.getVendor().getVendorName());
        }
        if (pr.getBankAccount() != null) {
            view.setBankAccountId(pr.getBankAccount().getId());
        }
        if (pr.getAutoTransaction() != null) {
            view.setAutoTransactionId(pr.getAutoTransaction().getId());
        }
        return view;
    }
}
