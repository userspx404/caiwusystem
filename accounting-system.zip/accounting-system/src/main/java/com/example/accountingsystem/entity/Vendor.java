package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "vendors")
@Data
public class Vendor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vendor_id")
    private Long id;

    @Column(name = "vendor_name", nullable = false, length = 150)
    private String vendorName;

    @Column(name = "tax_id", unique = true, nullable = false, length = 50)
    private String taxId;

    @Column(name = "contact_person", length = 100)
    private String contactPerson;

    @Column(name = "bank_acct_no", length = 50)
    private String bankAcctNo;

    @Column(name = "settlement_currency", length = 10)
    private String settlementCurrency;

    @Column(nullable = false, length = 20)
    private String status = "有效"; // Default status as per UC001
}

