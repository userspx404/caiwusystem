package com.example.accountingsystem.dto;

import com.example.accountingsystem.entity.FilingStatus;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class TaxFilingDto {

    private Long id;
    private String filingPeriod;
    private String taxType;
    private BigDecimal payableAmount;
    private FilingStatus filingStatus;
    private Long paymentRequestId;

}



