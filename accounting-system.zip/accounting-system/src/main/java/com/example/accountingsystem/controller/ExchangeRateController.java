package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.ExchangeRateDto;
import com.example.accountingsystem.service.ExchangeRateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/exchange-rates")
public class ExchangeRateController {

    private final ExchangeRateService exchangeRateService;

    @Autowired
    public ExchangeRateController(ExchangeRateService exchangeRateService) {
        this.exchangeRateService = exchangeRateService;
    }

    @PostMapping
    public ResponseEntity<ExchangeRateDto> createOrUpdateExchangeRate(@RequestBody ExchangeRateDto exchangeRateDto) {
        ExchangeRateDto savedRate = exchangeRateService.createOrUpdateExchangeRate(exchangeRateDto);
        return new ResponseEntity<>(savedRate, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<ExchangeRateDto>> getAllExchangeRates() {
        return ResponseEntity.ok(exchangeRateService.getAllExchangeRates());
    }

    @GetMapping("/{currencyCode}/{date}")
    public ResponseEntity<ExchangeRateDto> getExchangeRate(
            @PathVariable String currencyCode,
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(exchangeRateService.getExchangeRate(currencyCode.toUpperCase(), date));
    }

    @GetMapping("/latest/{currencyCode}")
    public ResponseEntity<ExchangeRateDto> getLatestExchangeRate(
            @PathVariable String currencyCode,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        LocalDate effectiveDate = (date == null) ? LocalDate.now() : date;
        return ResponseEntity.ok(exchangeRateService.findLatestRate(currencyCode.toUpperCase(), effectiveDate));
    }

    @DeleteMapping("/{currencyCode}/{date}")
    public ResponseEntity<Void> deleteExchangeRate(
            @PathVariable String currencyCode,
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        exchangeRateService.deleteExchangeRate(currencyCode.toUpperCase(), date);
        return ResponseEntity.noContent().build();
    }
}

