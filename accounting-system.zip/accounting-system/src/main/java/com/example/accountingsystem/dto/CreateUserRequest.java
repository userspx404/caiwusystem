package com.example.accountingsystem.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.Set;

@Data
public class CreateUserRequest {
    @NotBlank(message = "使用者名稱不能為空")
    @Size(min = 3, max = 50, message = "使用者名稱長度應在 3 到 50 個字符之間")
    private String username;

    @NotBlank(message = "密碼不能為空")
    @Size(min = 6, max = 100, message = "密碼長度應在 6 到 100 個字符之間")
    private String password;

    private boolean enabled = true;
    
    private Set<Integer> roleIds; // 角色ID列表
}

