package com.example.accountingsystem.entity;

public enum PurchaseOrderStatus {
    DRAFT,      // 草稿
    CONFIRMED,  // 已確認
    RECEIVED,   // 已入庫
    CANCELLED   // 已取消
}

