package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.PurchaseOrderDto;
import com.example.accountingsystem.dto.ReceiveOrderRequestDto;
import com.example.accountingsystem.service.PurchaseOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/purchase-orders")
public class PurchaseOrderController {

    private final PurchaseOrderService purchaseOrderService;

    @Autowired
    public PurchaseOrderController(PurchaseOrderService purchaseOrderService) {
        this.purchaseOrderService = purchaseOrderService;
    }

    @PostMapping
    public ResponseEntity<PurchaseOrderDto> createPurchaseOrder(@RequestBody PurchaseOrderDto purchaseOrderDto) {
        PurchaseOrderDto createdOrderDto = purchaseOrderService.createPurchaseOrder(purchaseOrderDto);
        return new ResponseEntity<>(createdOrderDto, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PurchaseOrderDto> getPurchaseOrderById(@PathVariable Long id) {
        return ResponseEntity.ok(purchaseOrderService.getPurchaseOrderById(id));
    }

    @GetMapping
    public ResponseEntity<List<PurchaseOrderDto>> getAllPurchaseOrders() {
        return ResponseEntity.ok(purchaseOrderService.getAllPurchaseOrders());
    }

    @PostMapping("/{id}/receive")
    public ResponseEntity<PurchaseOrderDto> receiveOrder(
            @PathVariable Long id,
            @RequestBody ReceiveOrderRequestDto receiveDto) {
        PurchaseOrderDto updatedOrderDto = purchaseOrderService.receivePurchaseOrder(
                id,
                receiveDto.getActualAmount(),
                receiveDto.getReceiptDate()
        );
        return ResponseEntity.ok(updatedOrderDto);
    }
}
