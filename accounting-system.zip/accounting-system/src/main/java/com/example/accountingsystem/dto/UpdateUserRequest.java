package com.example.accountingsystem.dto;

import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.Set;

@Data
public class UpdateUserRequest {
    @Size(min = 3, max = 50, message = "使用者名稱長度應在 3 到 50 個字符之間")
    private String username;

    @Size(min = 6, max = 100, message = "密碼長度應在 6 到 100 個字符之間")
    private String password; // 可選，如果為空則不更新密碼

    private Boolean enabled;
    
    private Set<Integer> roleIds; // 角色ID列表
}

