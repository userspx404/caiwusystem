package com.example.accountingsystem.repository;

import com.example.accountingsystem.entity.Currency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CurrencyRepository extends JpaRepository<Currency, String> {

    /**
     * Finds the base currency for the system.
     * There should be only one.
     * @return An Optional containing the base currency if set.
     */
    Optional<Currency> findByIsBaseCurrencyTrue();
}

