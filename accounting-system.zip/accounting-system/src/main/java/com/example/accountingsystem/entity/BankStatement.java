package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "bank_statements")
@Data
public class BankStatement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bank_statement_id")
    private Long id;

    // 關聯到對應的銀行存款科目
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;

    @Column(name = "statement_date", nullable = false)
    private LocalDate statementDate;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal amount;

    @Column(name = "reference_no", length = 100)
    private String referenceNo;

    @Column(length = 255)
    private String description;

    // 關聯到已匹配的帳務分錄
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "matched_split_id")
    private Split matchedSplit;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ReconciliationStatus status = ReconciliationStatus.UNMATCHED;

    // 對帳批次ID，暫存為 Long
    @Column(name = "reconciliation_id")
    private Long reconciliationId;
}

