package com.example.accountingsystem.controller;

import com.example.accountingsystem.dto.TransactionDto;
import com.example.accountingsystem.dto.ValuationRequestDto;
import com.example.accountingsystem.service.ForeignCurrencyValuationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/valuations")
public class ValuationController {

    private final ForeignCurrencyValuationService valuationService;

    @Autowired
    public ValuationController(ForeignCurrencyValuationService valuationService) {
        this.valuationService = valuationService;
    }

    /**
     * Triggers the foreign currency valuation process for a given date.
     * @param requestDto DTO containing the valuation date.
     * @return The adjustment transaction if created, otherwise no content.
     */
    @PostMapping
    public ResponseEntity<TransactionDto> performValuation(@RequestBody ValuationRequestDto requestDto) {
        TransactionDto resultTransaction = valuationService.performValuation(requestDto.getValuationDate());
        if (resultTransaction != null) {
            return ResponseEntity.ok(resultTransaction);
        } else {
            // No valuation was needed (e.g., no balances to adjust)
            return ResponseEntity.noContent().build();
        }
    }
}

