package com.example.accountingsystem.dto;

import com.example.accountingsystem.entity.TransactionStatus;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class TransactionDto {

    private Long id;
    private String voucherNo;
    private LocalDate date;
    private String description;
    private TransactionStatus status;
    private List<SplitDto> splits;
    private Long creatorId;
    private Long auditorId;
}

