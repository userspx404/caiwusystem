package com.example.accountingsystem.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        
        // 允許所有來源（開發環境）
        // 使用 addAllowedOriginPattern 支持通配符，但需要 setAllowCredentials(false)
        config.addAllowedOriginPattern("*");
        
        // 或者明確指定前端地址（推薦用於生產環境）
        // config.addAllowedOrigin("http://localhost:5173");
        // config.addAllowedOrigin("http://localhost:3000");
        
        // 允許所有請求方法
        config.addAllowedMethod("*");
        
        // 允許所有請求頭
        config.addAllowedHeader("*");
        
        // 允許發送憑證
        // 注意：當使用 addAllowedOriginPattern("*") 時，setAllowCredentials 必須為 false
        // 如果需要憑證，請明確指定允許的來源並設為 true
        config.setAllowCredentials(false);
        
        // 預檢請求的緩存時間（秒）
        config.setMaxAge(3600L);
        
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }
}




