package com.example.accountingsystem.dto;

import com.example.accountingsystem.entity.PaymentStatus;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PaymentRequestViewDto {
    private Long id;
    private LocalDate requestDate;
    private BigDecimal amount;
    private PaymentStatus status;

    private Long vendorId;
    private String vendorName;

    private Long bankAccountId;

    private String bankReceiptId;
    private Long autoTransactionId;
}

