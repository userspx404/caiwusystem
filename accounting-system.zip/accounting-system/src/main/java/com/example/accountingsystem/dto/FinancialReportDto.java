package com.example.accountingsystem.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

@Data
public class FinancialReportDto {

    private String reportName;
    private LocalDate reportDate;
    private Map<String, ReportSectionDto> sections = new LinkedHashMap<>();
    private BigDecimal totalAssets;
    private BigDecimal totalLiabilitiesAndEquity;
    private BigDecimal netIncome;

}
