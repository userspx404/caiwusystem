package com.example.accountingsystem.entity;

public enum ReportType {
    BALANCE_SHEET,  // 資產負債表
    INCOME_STATEMENT // 利潤表
}
