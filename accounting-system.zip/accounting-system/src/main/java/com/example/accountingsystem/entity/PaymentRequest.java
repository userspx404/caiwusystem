package com.example.accountingsystem.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "payment_requests")
@Data
public class PaymentRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_request_id")
    private Long id;

    @Column(name = "request_date", nullable = false)
    private LocalDate requestDate;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal amount;

    // 供應商
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "vendor_id", nullable = false)
    private Vendor vendor;

    // 付款所使用的銀行存款科目（資產科目）
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bank_account_id", nullable = false)
    private Account bankAccount;

    // 銀行回執ID與原文
    @Column(name = "bank_receipt_id", length = 100)
    private String bankReceiptId;

    @Lob
    @Column(name = "bank_receipt_raw")
    private String bankReceiptRaw;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PaymentStatus status = PaymentStatus.PENDING;

    // 自動生成的會計憑證（付款記帳憑證）
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auto_transaction_id")
    private Transaction autoTransaction;
}

