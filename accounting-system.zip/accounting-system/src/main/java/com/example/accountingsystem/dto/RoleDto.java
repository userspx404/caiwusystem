package com.example.accountingsystem.dto;

import lombok.Data;

@Data
public class RoleDto {
    private Integer id;
    private String name;
}




