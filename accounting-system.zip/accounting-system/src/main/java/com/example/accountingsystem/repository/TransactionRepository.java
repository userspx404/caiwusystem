package com.example.accountingsystem.repository;

import com.example.accountingsystem.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.accountingsystem.entity.TransactionStatus;

import java.util.List;
import java.util.Optional;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    /**
     * 根據狀態查詢交易並立即加載 splits 集合（解決懶加載問題）
     */
    @Query("SELECT DISTINCT t FROM Transaction t LEFT JOIN FETCH t.splits s LEFT JOIN FETCH s.account WHERE t.status = :status")
    List<Transaction> findByStatus(@Param("status") TransactionStatus status);

    /**
     * 根據憑證號查詢交易。
     * 憑證號是唯一的。
     * @param voucherNo 憑證號
     * @return 可能包含交易的 Optional
     */
    Optional<Transaction> findByVoucherNo(String voucherNo);

    /**
     * 查詢所有交易並立即加載 splits 集合（解決懶加載問題）
     */
    @Query("SELECT DISTINCT t FROM Transaction t LEFT JOIN FETCH t.splits s LEFT JOIN FETCH s.account")
    List<Transaction> findAllWithSplits();

    /**
     * 根據 ID 查詢交易並立即加載 splits 集合（解決懶加載問題）
     */
    @Query("SELECT DISTINCT t FROM Transaction t LEFT JOIN FETCH t.splits s LEFT JOIN FETCH s.account WHERE t.id = :id")
    Optional<Transaction> findByIdWithSplits(@Param("id") Long id);
}

