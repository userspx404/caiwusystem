-- 插入角色 (如果不存在)
-- 注意：使用者數據將由 DataInitializer 類自動創建和更新
INSERT INTO roles (id, name) VALUES (1, 'ADMIN') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO roles (id, name) VALUES (2, 'ACCOUNTANT') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO roles (id, name) VALUES (3, 'AUDITOR') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO roles (id, name) VALUES (4, 'CASHIER') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO roles (id, name) VALUES (5, 'VIEWER') ON DUPLICATE KEY UPDATE name=name;
